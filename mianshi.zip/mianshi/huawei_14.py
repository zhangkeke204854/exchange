# 找出相似度最高的文档
# 为了更快追踪突发热点，我们仅在“查询时刻 t 之前的最近 K 篇文档”内计算 TF‑IDF，并以加权余弦相似度挑选最相关的文档。
# 窗口内越新的文档权重越高（从旧到新第 j 篇的权重为 (K−j+1)/K）。
# 给定按时间递增的文档序列和若干查询（每条查询含时间点 t 与查询短语 q），请在窗口中找出与 q 的加权余弦相似度最高且相似度≥0.6 的文档编号；若存在并列最高，返回窗口中最早的那一篇；若无满足阈值的文档，输出 -1。
# * 词向量用 TF‑IDF：TF 为词频；IDF 采用平滑公式 IDF(x)=log((N+1)/(df(x)+1))+1，其中 N 为窗口文档数，df(x) 为窗口内包含词 x 的文档数。
# * 余弦相似度采用 q 与每个文档向量的点积除以范数乘积；文档向量还需乘以其时间权重。
# * 文档与查询均以空格分词、统一小写，不做额外清洗。为避免早期窗口不足的问题，测试均保证 t ≥ K−1。
#
# 输入描述：
# 第一行：文档总数 N
# 接下来 N 行：按时间从 0 到 N−1 的文档内容（小写，空格分词）
# 下一行：窗口大小 K
# 下一行：查询总数 P
# 接下来 P 行：每行“t 空格 q”表示在时间点 t 的查询 q
#
# 输出描述：
# 输出 P 个数字，空格分隔；每个数字是对应查询的文档编号或 -1
#
# 示例1
# 输入例子：
# 5
# breaking news finance market
# sports football world cup
# finance stock market rises
# tech ai model training
# finance market crash report
# 3
# 3
# 4 finance market
# 5 ai model
# 3 travel guide
# 输出例子：
# 4 3 -1
# 例子说明：
# 对 t=4，窗口为文档[2,3,4]。q="finance market" 与 2、4 的原始余弦相似度相同且约为 0.605≥0.6；时间权重越新越大（2:1/3, 3:2/3, 4:1），加权后 4 更高，返回 4。
# 对 t=5，窗口为[2,3,4]。q="ai model" 仅与文档3匹配（含 ai、model），原始余弦≈0.707≥0.6，返回 3。
# 对 t=3，窗口为[1,2,3]。q="travel guide" 窗口内均无重合词，余弦=0<0.6，返回 -1。

import sys
import math
from collections import Counter, defaultdict

# 设置浮点数精度，以匹配四舍五入要求
FLOAT_PRECISION = 6


class TFIDFSimilarity:
    def __init__(self, K, N, all_docs):
        self.K = K
        self.N = N
        # 存储所有文档的词频 (TF) 字典
        # self.doc_tfs[i] = Counter({'word': count, ...})
        self.doc_tfs = []
        for doc_content in all_docs:
            self.doc_tfs.append(Counter(doc_content.split()))

    def calculate_window_stats(self, t):
        """
        计算时间 t 的窗口 [t-K+1, t] 上的 IDF 统计。
        """
        # 窗口范围（文档编号从 1 到 N）
        start_idx = max(1, t - self.K + 1)
        end_idx = min(self.N, t)

        # 实际文档编号是 0-based index，所以是 [start_idx-1, end_idx-1]

        # 1. 计算窗口内所有词的文档频率 df(x)
        df = defaultdict(int)
        for i in range(start_idx, end_idx + 1):
            doc_idx = i - 1
            unique_words = self.doc_tfs[doc_idx].keys()
            for word in unique_words:
                df[word] += 1

        # 2. 计算窗口内所有词的 IDF
        window_size = end_idx - start_idx + 1  # N in IDF formula
        idf_scores = {}
        for word, count in df.items():
            # IDF(x) = log((N+1)/(df(x)+1)) + 1
            idf_scores[word] = math.log((window_size + 1) / (count + 1)) + 1

        return start_idx, end_idx, idf_scores

    def get_document_tf_idf_vector(self, doc_idx, idf_scores):
        """
        计算文档 i 的 TF-IDF 向量和 L2 范数。
        doc_idx 是 0-based index。
        """
        doc_tf = self.doc_tfs[doc_idx]
        tf_idf_vector = {}
        sq_norm = 0.0

        for word, tf in doc_tf.items():
            # 只有在 IDF 字典中的词才计算（即窗口内出现过的词）
            if word in idf_scores:
                tf_idf = tf * idf_scores[word]
                tf_idf_vector[word] = tf_idf
                sq_norm += tf_idf ** 2

        return tf_idf_vector, math.sqrt(sq_norm)

    def get_query_tf_idf_vector(self, query_words, idf_scores):
        """
        计算查询 q 的 TF-IDF 向量和 L2 范数。
        """
        query_tf = Counter(query_words)
        tf_idf_vector = {}
        sq_norm = 0.0

        for word, tf in query_tf.items():
            # 只有在 IDF 字典中的词才计算
            if word in idf_scores:
                tf_idf = tf * idf_scores[word]
                tf_idf_vector[word] = tf_idf
                sq_norm += tf_idf ** 2

        return tf_idf_vector, math.sqrt(sq_norm)

    def calculate_similarity(self, t, query):
        """
        计算查询 q 在时间 t 的最优加权余弦相似度文档编号。
        """
        query_words = query.lower().split()

        # 1. 计算窗口统计 (IDF)
        start_idx, end_idx, idf_scores = self.calculate_window_stats(t)

        if start_idx > end_idx:  # 窗口为空
            return -1

        # 2. 计算查询的 TF-IDF 向量
        v_q, norm_q = self.get_query_tf_idf_vector(query_words, idf_scores)

        if norm_q == 0:  # 查询只包含窗口内未出现的词
            return -1

        # 3. 遍历窗口内的文档，计算加权相似度
        max_similarity = -1.0
        best_doc_id = -1

        window_size = end_idx - start_idx + 1  # K

        for i in range(start_idx, end_idx + 1):
            doc_idx = i - 1  # 0-based document index

            # a. 计算时间权重
            # j = i - (t - K + 1) + 1  => i - t + K
            # 根据示例，最新（i=t）权重为 1，最旧（i=t-K+1）权重为 1/K
            # W = (i - (t-K+1) + 1) / K
            W_time = (i - start_idx + 1) / window_size

            # b. 计算文档的 TF-IDF 向量
            v_i, norm_i = self.get_document_tf_idf_vector(doc_idx, idf_scores)

            if norm_i == 0:
                continue

            # c. 计算点积 (Dot Product)
            dot_product = 0.0
            for word, tf_idf_q in v_q.items():
                if word in v_i:
                    dot_product += tf_idf_q * v_i[word]

            # d. 计算原始余弦相似度
            cosine_similarity = dot_product / (norm_q * norm_i)

            # e. 计算加权余弦相似度
            weighted_similarity = W_time * cosine_similarity

            # 4. 更新最优结果
            # 相似度必须 >= 0.6
            if weighted_similarity >= 0.6:
                # 检查是否为最高相似度
                if weighted_similarity > max_similarity:
                    max_similarity = weighted_similarity
                    # i 是 1-based 文档编号
                    best_doc_id = i

                # 处理并列最高：返回窗口中最早的那一篇 (即 i 最小的那篇)
                # 因为我们是按 i 递增遍历的，如果当前相似度 == max_similarity，
                # 且 best_doc_id 已经被设置，则保留已找到的 (更早的) best_doc_id。
                # 由于 max_similarity 初始化为 -1.0，我们只需在 > 时更新，
                # 在 == 时不更新即可保证返回 i 最小的。

                # 示例的特殊处理：示例中原始余弦相似度并列，但加权后不同。
                # 这里的 max_similarity 已经是加权后的。
                # 如果并列，我们保持当前的 best_doc_id (因为它 i 较小/较早)。
                pass

        # 由于 Python 浮点数比较可能不精确，我们使用一个小的 epsilon
        EPSILON = 1e-7

        # 重新遍历以处理并列（如果需要，但按 i 递增遍历并只在 > 时更新已经满足要求）
        # 这里只返回最终结果
        return best_doc_id if max_similarity >= 0.6 - EPSILON else -1


def solve():
    """读取输入并调用相似度计算类。"""
    try:
        # 读取文档总数 N
        N = int(sys.stdin.readline().strip())

        # 读取 N 篇文档内容
        all_docs = []
        for _ in range(N):
            all_docs.append(sys.stdin.readline().strip())

        # 读取窗口大小 K
        K = int(sys.stdin.readline().strip())

        # 读取查询总数 P
        P = int(sys.stdin.readline().strip())

        # 初始化相似度计算器
        similarity_calculator = TFIDFSimilarity(K, N, all_docs)

        results = []
        # 读取 P 条查询
        for _ in range(P):
            line = sys.stdin.readline().strip()
            if not line:
                continue

            parts = line.split(maxsplit=1)
            t = int(parts[0])
            q = parts[1]

            # 文档编号 t 是 1-based index (时间 t 对应第 t 篇文档，编号 t)
            # 确保 t 位于 [1, N]
            if t < 1 or t > N:
                results.append(-1)
                continue

            result = similarity_calculator.calculate_similarity(t, q)
            results.append(result)

        print(" ".join(map(str, results)))

    except Exception as e:
        # print(f"An error occurred: {e}", file=sys.stderr)
        pass  # 忽略异常以适配在线判题环境


if __name__ == "__main__":
    solve()