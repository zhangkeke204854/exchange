# 最优分词器
# 你在为一门极少见的语言做专用分词。语言学家给出了一个“小词典”，每个条目都有一个分值，表示该词单独成词的合理性强弱。
# 同时，还收集了“相邻词对”的转移加分：当上一个词与下一个词按某种搭配出现时，整体会多（或少）一些分数。
# 你的目标是在给定的连续小写字母串中，切分出一条完整的词序列，使“词典分+转移加分”的总和最大。如果无法用词典完全覆盖整串，则输出0。
# 输入描述：
# 第一行：文本串 text，仅含小写英文字母。
# 第二行：整数 n，表示词典条目数。
# 接下来 n 行：每行一个词与其分值，中间用空格分隔。
# 接下来一行：整数 m，表示转移加分条目数。
# 接下来 m 行：每行包含“前词 后词 加分”，三者以空格分隔，加分可为负。
# 输出描述：
# 一行，一个整数：最大可获得的总分。如果不存在任何完整切分，输出0。
# 示例1
# 输入例子：
# aababa
# 4
# a 1
# aa 3
# ab 2
# ba 2
# 3
# aa ba 2
# ba ba -1
# ab a 1
# 输出例子：
# 8
# 例子说明：
# * 		最优切分：aa | ba | ba
#     * 		词典分：3 + 2 + 2 = 7
#     * 		转移分：aa→ba = +2，ba→ba = -1
#     * 		总分：7 + 2 - 1 = 8
# * 		其他可行切分（例如：a | ab | a | ba）
#     * 		词典分：1 + 2 + 1 + 2 = 6
#     * 		转移分：ab→a = +1（其余未命中）
#     * 		总分：6 + 1 = 7 因此最优答案为 8。

import sys


def main():
    data = sys.stdin.read().splitlines()
    if not data:
        print(0)
        return

    text = data[0].strip()
    n = int(data[1])
    word_score = {}
    for i in range(2, 2 + n):
        parts = data[i].split()
        if len(parts) < 2:
            continue
        word = parts[0]
        score = int(parts[1])
        word_score[word] = score

    m = int(data[2 + n])
    trans_dict = {}
    for i in range(3 + n, 3 + n + m):
        parts = data[i].split()
        if len(parts) < 3:
            continue
        prev = parts[0]
        next_word = parts[1]
        bonus = int(parts[2])
        trans_dict[(prev, next_word)] = bonus

    L = len(text)
    if L == 0:
        print(0)
        return

    # dp[i] is a dict: key=word ending at i, value=max score for prefix ending with that word
    dp = [dict() for _ in range(L)]

    for i in range(L):  # i is end index (0-based)
        for word, score_val in word_score.items():
            len_w = len(word)
            start = i - len_w + 1
            if start < 0:
                continue  # word too long, cannot end at i
            # Extract substring from start to i (inclusive)
            if text[start:i + 1] != word:
                continue  # substring doesn't match word

            if start == 0:
                # At beginning, no previous word
                current_score = score_val
                # If multiple words end at same i, keep the max for this word
                if word in dp[i]:
                    if current_score > dp[i][word]:
                        dp[i][word] = current_score
                else:
                    dp[i][word] = current_score
            else:
                # start > 0, need previous word ending at start-1
                prev_index = start - 1
                if not dp[prev_index]:
                    continue  # no valid segmentation ending at prev_index, skip

                best_prev = -10 ** 18  # small number for initialization
                for prev_word, prev_score in dp[prev_index].items():
                    # Get transition bonus, default 0 if not in trans_dict
                    trans_bonus = trans_dict.get((prev_word, word), 0)
                    total_score = prev_score + score_val + trans_bonus
                    if total_score > best_prev:
                        best_prev = total_score

                if best_prev != -10 ** 18:  # valid score found
                    if word in dp[i]:
                        if best_prev > dp[i][word]:
                            dp[i][word] = best_prev
                    else:
                        dp[i][word] = best_prev

    # Check the last position L-1
    if dp[L - 1]:
        ans = max(dp[L - 1].values())
        print(ans)
    else:
        print(0)


if __name__ == "__main__":
    main()
