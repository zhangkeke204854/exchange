# 算法配置
# 一个系统支持多种算法，每种算法使用一个正整数 ID 来唯一标识。管理员可以分批次地启用或禁用这些算法。
# 您需要编写一个程序，根据一份操作日志，计算出最终处于“启用”状态的所有算法 ID。
# 输入描述：
# -   第一行是一个整数 N，代表操作日志中的记录总数。
# -   接下来的N行，每行是一条操作记录。
# -   操作记录分为两种：
#     1.  `algorithm <ranges>`：表示 **启用** 指定范围内的所有算法。
#     2.  `undo algorithm <ranges>`：表示 **禁用** 指定范围内的所有算法。
# -   `<ranges>` 是一个由逗号 `,` 分隔的字符串，用于描述算法 ID 的范围。
#     -   范围可以是一个单独的 ID，如 `8`。
#     -   也可以是一个闭区间，如 `1-100`。
#     -   也可以是两者的混合，如 `1-10,15-20` 或 `6,7,8,9-10`。
# -   所有算法 ID 均为正整数。
# 输出描述：
# -   输出一行，代表经过所有操作后，最终处于“启用”状态的算法 ID 集合。
# -   输出结果需要被合并为最简的、无重叠的、升序排列的区间。
# -   格式与输入的 `<ranges>` 部分相同。
# -   如果最终没有启用的算法，则输出一个空行。
# 示例1
# 输入例子：
# 5
# undo algorithm 59,99-99
# algorithm 10,15-37,35
# algorithm 73
# undo algorithm 72,56-94,62-71
# undo algorithm 70,37-90
# 输出例子：
# 10,15-36


import sys


def parse_ranges(s):
    """解析区间字符串为区间列表"""
    ranges = []
    parts = s.split(',')
    for part in parts:
        if '-' in part:
            a, b = part.split('-')
            ranges.append([int(a), int(b)])
        else:
            num = int(part)
            ranges.append([num, num])
    return ranges


def merge_intervals(intervals):
    """合并重叠或连续的区间"""
    if not intervals:
        return []
    intervals.sort(key=lambda x: x[0])
    merged = []
    start, end = intervals[0]
    for i in range(1, len(intervals)):
        if intervals[i][0] <= end + 1:
            end = max(end, intervals[i][1])
        else:
            merged.append([start, end])
            start, end = intervals[i]
    merged.append([start, end])
    return merged


def remove_interval_from_list(intervals, to_remove):
    """从区间列表中移除指定区间（可能拆分现有区间）"""
    new_intervals = []
    a, b = to_remove
    for interval in intervals:
        s, e = interval
        if e < a or s > b:
            new_intervals.append(interval)
        else:
            if s < a:
                new_intervals.append([s, a - 1])
            if e > b:
                new_intervals.append([b + 1, e])
    return new_intervals


def main():
    data = sys.stdin.read().splitlines()
    if not data:
        return

    N = int(data[0].strip())
    enabled_intervals = []

    index = 1
    for _ in range(N):
        line = data[index].strip()
        index += 1

        if line.startswith("undo algorithm"):
            s = line[14:].strip()
            intervals = parse_ranges(s)
            remove_list = merge_intervals(intervals)
            remove_list.sort(key=lambda x: x[0])
            for r in remove_list:
                enabled_intervals = remove_interval_from_list(enabled_intervals, r)
        else:
            s = line[9:].strip()
            intervals = parse_ranges(s)
            new_intervals = merge_intervals(intervals)
            all_intervals = enabled_intervals + new_intervals
            enabled_intervals = merge_intervals(all_intervals)

    if not enabled_intervals:
        print()
    else:
        parts = []
        for interval in enabled_intervals:
            s, e = interval
            if s == e:
                parts.append(str(s))
            else:
                parts.append(f"{s}-{e}")
        print(','.join(parts))


if __name__ == "__main__":
    main()
