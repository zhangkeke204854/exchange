# 星际跃迁的稳定信标
# 在浩瀚无垠的宇宙中，为了实现安全的超光速“星际跃迁”，星际舰队的导航系统必须锁定一个特定的“跃迁信标频率” f。该频率是一个正整数。
#
# 根据舰队旗舰“探索者号”的引擎限制，所选的信标频率 f 必须小于或等于引擎能承受的最大频率 F_max，即满足约束条件 f≤F_max。
#
# 此外，为了维持跃迁过程的绝对稳定，频率 f 必须是一个“和谐频率”。一个频率被称为“和谐”的，当且仅当它的各位数字从高位到低位是一个非递减序列。
# 例如，123、111、399 都是和谐频率，而 121 或 897 这种非和谐频率会导致跃迁通道的灾难性崩溃。
#
# 最后，一个至关重要的约束是，频率 f 的“能量签名” S(f) 必须为一个质数。能量签名 S(f) 定义为该频率 f 的各位数字之和。一个质数能量签名可以确保跃迁过程与宇宙背景辐射产生最佳共鸣，从而最小化能量消耗。
#
# 您的任务是编写一个程序，对于给定的最大频率 F_max，找出不大于 F_max 的、能量签名为质数的、值最大的和谐频率 f。
# 输入描述：
# 输入一个正整数 Fmax，代表引擎能承受的最大频率。
# 数据范围：1<=Fmax<=10**18。
# 输出描述：
# 返回一个整数，表示满足所有条件的最大和谐频率 f。如果不存在这样的频率，则返回-1。
# 示例1
# 输入例子：
# 888
# 输出例子：
# 788


def solve(Fmax):
    def is_prime(n):
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False
        i = 3
        while i * i <= n:
            if n % i == 0:
                return False
            i += 2
        return True

    best = -1
    Fmax_str = str(Fmax)
    len_F = len(Fmax_str)

    def dfs(pos, current, last_digit, is_tight):
        nonlocal best
        if pos == len_F:
            if current <= Fmax:
                digit_sum = sum(int(d) for d in str(current))
                if is_prime(digit_sum):
                    best = max(best, current)
            return

        # 确定当前位的上限
        upper = int(Fmax_str[pos]) if is_tight else 9

        for d in range(last_digit, upper + 1):
            new_current = current * 10 + d
            new_tight = is_tight and (d == upper)
            dfs(pos + 1, new_current, d, new_tight)

        # 还要考虑长度小于len_F的情况
        # 但我们在主函数中单独处理

    # 处理长度小于len_F的所有和谐频率
    def generate_shorter(length):
        nonlocal best

        def gen(pos, current, last_digit):
            nonlocal best
            if pos == length:
                digit_sum = sum(int(d) for d in str(current))
                if is_prime(digit_sum):
                    best = max(best, current)
                return
            for d in range(last_digit, 10):
                gen(pos + 1, current * 10 + d, d)

        for l in range(1, length):
            for first in range(1, 10):
                gen(1, first, first)

    generate_shorter(len_F)
    # 处理长度等于len_F的情况
    for first in range(1, int(Fmax_str[0]) + 1):
        tight = first == int(Fmax_str[0])
        dfs(1, first, first, tight)

    return best if best != -1 else -1

print(solve(int(input())))
