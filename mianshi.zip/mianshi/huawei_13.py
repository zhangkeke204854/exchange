# MOE Top‑k 路由
# 在一个稀疏 MOE 模型中，有 n 个专家顺序编号为 0…n-1，这些专家被平均分布到 m 张 NPU 卡上，每张卡上一组，且同组专家编号连续。为降低跨卡通信，现将路由目标限制在最多 p 张 NPU 上：
# 1) 先对每组求组内概率最大值及其专家编号，作为该组的代表值；
# 2) 把所有组按“代表概率”从高到低排序，若概率相同则组号小的在前，取前 p 个组；
# 3) 仅在上述 p 个组包含的所有专家里，按“概率降序、编号升序”挑选前 k 位的专家编号作为最终路由目标。
#
# 约束与异常
# - 若 n 不能被 m 整除，则无法平均分组，输出 error。
# - 若 p>m，输出 error。
# - 设每组大小 g=n/m，若可选专家总数 p·g<k，无法选够 k 人，输出 error。
#
# 输入描述：
# 第一行：四个整数 n m p k（1≤n,m,p,k≤10000）
# 第二行：n 个浮点数，依次为专家 0…n-1 的概率，均在 (0,1) 内
# 输出描述：
# 若发生异常，输出 error
# 否则输出 k 个专家编号，升序，空格分隔（行尾无空格）
#
# 示例1
# 输入例子：
# 6 3 2 2
# 0.3 0.1 0.05 0.6 0.4 0.2
# 输出例子：
# 3 4
# 例子说明：
# 分组：g=6/3=2。组0=[0,1]→代表(0.3,idx0)，组1=[2,3]→代表(0.6,idx3)，组2=[4,5]→代表(0.4,idx4)。
# 选组：按代表概率降序取前 p=2 个，得到组1与组2。
# 选专家：在{2,3,4,5}中按概率降序取前 k=2，依次为 idx3(0.6)、idx4(0.4)；最后升序输出 3 4。
# 示例2
# 输入例子：
# 6 4 2 2
# 0.1 0.2 0.3 0.4 0.5 0.6
# 输出例子：
# error
# 例子说明：
# 因为 n=6、m=4，n 必须能被 m 整除才能把专家平均分到每张 NPU 上（组大小 g=n/m 为整数）。这里 6%4≠0，g=1.5 不是整数，无法等分成 4 组，所以按规则直接输出 error。


def main():
    import sys
    data = sys.stdin.read().splitlines()
    if not data:
        return

    # 解析输入
    n, m, p, k = map(int, data[0].split())
    probs = list(map(float, data[1].split()))

    # 验证输入
    if n % m != 0:
        print("error")
        return
    if p > m:
        print("error")
        return

    g = n // m
    if p * g < k:
        print("error")
        return

    # 分组
    groups = []
    for i in range(m):
        start = i * g
        end = start + g
        group = []
        for j in range(start, end):
            group.append((j, probs[j]))
        groups.append(group)

    # 计算每组最大概率
    group_max = []
    for i, group in enumerate(groups):
        max_prob = max(group, key=lambda x: x[1])[1]
        group_max.append((max_prob, i))

    # 组排序
    group_max.sort(key=lambda x: (-x[0], x[1]))
    selected_groups_idx = [idx for _, idx in group_max[:p]]

    # 合并选中的组
    candidates = []
    for idx in selected_groups_idx:
        candidates.extend(groups[idx])

    # 专家排序
    candidates.sort(key=lambda x: (-x[1], x[0]))
    selected_experts = [expert[0] for expert in candidates[:k]]
    selected_experts.sort()

    # 输出结果
    print(" ".join(map(str, selected_experts)))


if __name__ == "__main__":
    main()
