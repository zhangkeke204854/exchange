# 命令行解析与出现次数统计
# 在一种复杂的命令行系统中，命令的格式由一个模板字符串定义。模板由关键字、抉择结构 `{...}` 和可选结构 `[...]` 组成，元素间由空格分隔。
# 您的任务是解析这个模板，找出所有在顶层定义的固定关键字，并计算出每一个固定关键字在任意合法的命令中保证会出现的最小次数。
# 定义:
# 1. 关键字: 仅由小写字母组成的字符串。
# 2. 固定关键字: 在模板的顶层，不被任何括号包裹的关键字。它们是命令的根基。
# 3. 抉择结构 `{ A | B | ... }`: 表示该位置必须从选项 `A`, `B`, ... 中选择一个。选项本身可以是复杂的子模板。
# 4. 可选结构 `[ C ]`: 表示 `C` 部分是可选的，可以出现 0 次或 1 次。
# 保证出现次数的计算规则:
# 一个关键字 K 的“保证出现次数” C(K)，是基于以下递归逻辑计算的：
# - 首先，统计 K 作为固定关键字出现的次数。
# - 然后，遍历模板中的所有抉择结构 `{ A | B | ... }`，如果 K 在每一个选项 A,B,… 中都保证会出现（即，递归计算出的保证次数都 ≥1），那么这个抉择结构就为 C(K) 贡献 `+1`。
# - 在可选结构 `[...]` 内部的任何关键字，都不被视为“保证出现”。
# 输入描述：
# -   输入为一行字符串，代表命令格式模板。
# -   字符串由关键字、`{`, `}`, `|`, `[`, `]` 和空格组成。
# -   输入字符串保证格式合法。
# 输出描述：
# -   输出共两行。
# -   第一行：按输入顺序，输出所有固定关键字，以单个空格分隔。
# -   第二行：对应第一行的每个关键字，输出其保证出现的最小次数以单个空格分隔。
# 示例1
# 输入例子：
# a b { c | d [ e ] } [ f { g | h } ]
# 输出例子：
# a b
# 1 1
#
#
import sys


def find_matching_bracket(s, start):
    """找到匹配的右括号位置"""
    stack = []
    for i in range(start, len(s)):
        if s[i] == '{' or s[i] == '[':
            stack.append(s[i])
        elif s[i] == '}' and stack and stack[-1] == '{':
            stack.pop()
            if not stack:
                return i
        elif s[i] == ']' and stack and stack[-1] == '[':
            stack.pop()
            if not stack:
                return i
    return -1


def split_options(s):
    """分割抉择结构的选项（忽略括号内的|）"""
    options = []
    start = 0
    stack = []
    for i, char in enumerate(s):
        if char == '{' or char == '[':
            stack.append(char)
        elif char == '}' and stack and stack[-1] == '{':
            stack.pop()
        elif char == ']' and stack and stack[-1] == '[':
            stack.pop()
        elif char == '|' and not stack:
            options.append(s[start:i].strip())
            start = i + 1
    options.append(s[start:].strip())
    return options


def parse_tokens(s):
    """解析字符串为令牌序列"""
    tokens = []
    i = 0
    n = len(s)
    while i < n:
        if s[i] == ' ':
            i += 1
            continue
        if s[i] == '{' or s[i] == '[':
            end = find_matching_bracket(s, i)
            if end == -1:
                break
            inner = s[i + 1:end].strip()
            if s[i] == '{':
                options = split_options(inner)
                tokens.append(('choice', options))
            else:
                tokens.append(('optional', inner))
            i = end + 1
        else:
            j = i
            while j < n and s[j] != ' ' and s[j] != '{' and s[j] != '[':
                j += 1
            token = s[i:j]
            tokens.append(token)
            i = j
    return tokens


def compute_guaranteed_occurrences(tokens):
    """递归计算关键字保证出现次数"""
    res = {}
    for token in tokens:
        if isinstance(token, str):
            res[token] = res.get(token, 0) + 1
        elif token[0] == 'choice':
            options = token[1]
            option_dicts = []
            for opt in options:
                opt_tokens = parse_tokens(opt)
                d = compute_guaranteed_occurrences(opt_tokens)
                option_dicts.append(d)
            if option_dicts:
                common_keys = set(option_dicts[0].keys())
                for d in option_dicts[1:]:
                    common_keys &= set(d.keys())
                for k in common_keys:
                    res[k] = res.get(k, 0) + 1
    return res


def main():
    s = sys.stdin.readline().strip()
    tokens = parse_tokens(s)
    fixed_keywords = [t for t in tokens if isinstance(t, str)]
    count_dict = compute_guaranteed_occurrences(tokens)

    print(" ".join(fixed_keywords))
    counts = [str(count_dict.get(k, 0)) for k in fixed_keywords]
    print(" ".join(counts))


if __name__ == "__main__":
    main()
