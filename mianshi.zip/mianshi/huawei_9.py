# 验证集可达到的最优F1值
# * 决策树若完全按训练集递归生长，往往能把训练样本分得很“细”，但一到未见过的数据就容易出错，即出现过拟合。为缓解这一问题，常用“剪枝”把某些子树整体替换成单个叶子，使模型更简单。
# * 现在有一棵用于二分类的二叉决策树（标签1表示正类，0表示负类）。对非叶节点，按“第fi个特征 ≤thi走左子树，否则走右子树”的规则继续判断；到达叶子时直接输出该节点自带的label。
# * 允许在整棵树上任选若干处进行剪枝（把某个内部节点整体替换为叶节点，其输出为该节点给定的label）。请在给定验证集上寻找使 F1 值最大的剪枝方案，输出最优 F1（四舍五入保留6位小数）。
#
# 输入描述：
# 第一行：N M K
# N 为节点数(1~100)，M 为验证集条数(1~300)，K 为每条验证样本的特征维数(1~100)。
#
# 接下来的 N 行：按节点编号1..N给出每个节点的信息：
#
# 接下来的 M 行：每行 K+1 个整数，前 K 个为该条验证样本的特征，最后一个为真实标签（0或1）。
#
# 输出描述：
# 输出单行浮点数：在验证集上能达到的最大 F1 值，四舍五入到小数点后 6 位。
#
# 示例1
# 输入例子：
# 5 5 2
# 2 3 1 50 0
# 0 0 0 0 1
# 4 5 2 70 0
# 0 0 0 0 0
# 0 0 0 0 1
# 40 80 1
# 55 60 0
# 55 90 1
# 55 85 0
# 20 10 0
# 输出例子：
# 0.666667
# 例子说明：
# 路由规则：特征1≤50 进左子树，否则进右子树；在右子树中再按特征2≤70 判到左叶（输出0），否则到右叶（输出1）。
# 若不剪枝，五条样本的预测与真实标签对比如下：命中两条正类，出现两次“将负类判为正类”，未漏判正类，计算得 F1=2*2/(2*2+2+0)=0.666667。
# 尝试将右子树整体剪为叶（输出0）或将根剪为叶（输出0/1）等方案，F1 反而更低。因此最优为 0.666667。
# 示例2
# 输入例子：
# 5 6 2
# 2 3 1 30 1
# 0 0 0 0 0
# 4 5 2 50 1
# 0 0 0 0 1
# 0 0 0 0 0
# 35 40 1
# 35 70 0
# 35 60 1
# 25 80 0
# 28 10 1
# 50 45 1
# 输出例子：
# 0.800000
# 例子说明：
# 路由规则：特征1≤30 走左子树（叶，输出0），否则进入右子树；在右子树内，特征2≤50 走左叶（输出1），否则走右叶（输出0）。
# 不剪枝时：TP=2（命中两条正类），FN=2（漏判两条正类），FP=0，F1=22/(4+0+2)=0.666667。
# 若把根节点直接剪成叶并输出1，则6条样本预测为1，其中TP=4（四条为正类），FP=2（两条为负类），FN=0，F1=24/(8+2+0)=0.800000。其他剪枝方案（如只剪右子树）得到的F1更低，因此最优为0.800000。

import sys
import math


# 设置递归深度以防栈溢出，N最大为100，默认深度可能不够
# sys.setrecursionlimit(2000)

def calculate_f1(TP, FP, FN):
    """计算F1值。"""
    # F1 = 2 * TP / (2 * TP + FP + FN)
    denominator = 2 * TP + FP + FN
    if denominator == 0:
        return 0.0
    return (2.0 * TP) / denominator


def solve():
    """主函数，处理输入和输出。"""
    try:
        # 读取 N, M, K
        line = sys.stdin.readline().split()
        if not line:
            return
        N, M, K = map(int, line)
    except EOFError:
        return
    except Exception:
        return

    # 1. 读取决策树节点信息
    # 节点ID从1开始，所以数组大小为 N+1
    nodes = [None] * (N + 1)
    for i in range(1, N + 1):
        # 节点格式：left right feature_idx threshold label
        line = list(map(int, sys.stdin.readline().split()))
        nodes[i] = {
            'L': line[0],  # left_id
            'R': line[1],  # right_id
            'f': line[2],  # feature_index (1-based)
            't': line[3],  # threshold
            'l': line[4]  # label (for original leaf or for pruning)
        }

    # 2. 读取验证集信息
    # 样本格式：feature_1 ... feature_K true_label
    val_data = []
    for _ in range(M):
        val_data.append(list(map(int, sys.stdin.readline().split())))

    # --- 预处理：计算落在每个节点子树中的正负样本数 P_u 和 N_u ---

    # 计数器，P[i]：落在节点i子树中的正样本数；N[i]：负样本数
    P = [0] * (N + 1)
    N_count = [0] * (N + 1)  # N_count 避免和 N (节点数) 混淆

    # 模拟每个样本的路由路径
    for sample_features in val_data:
        # 验证集标签在最后一维
        true_label = sample_features[-1]

        # 从根节点开始
        curr_node_id = 1
        while curr_node_id != 0:
            if curr_node_id > N:  # 异常情况，跳过
                break

            # 统计样本计数
            if true_label == 1:
                P[curr_node_id] += 1
            else:
                N_count[curr_node_id] += 1

            node = nodes[curr_node_id]

            # 如果是叶子节点，则停止
            if node['L'] == 0 and node['R'] == 0:
                break

            # 内部节点，根据规则路由
            feature_idx = node['f']
            threshold = node['t']

            # 注意特征索引是 1-based，需要减 1 访问
            feature_value = sample_features[feature_idx - 1]

            if feature_value <= threshold:
                curr_node_id = node['L']  # 走左子树
            else:
                curr_node_id = node['R']  # 走右子树

    # --- 动态规划：自底向上计算最优 (TP, FP, FN) ---

    # DP[i] 存储以节点i为根的最优剪枝方案的 (TP, FP, FN) 三元组
    # (max_TP, max_FP, max_FN)
    DP = [None] * (N + 1)

    def find_best_stats(u):
        """
        递归计算节点 u 的最优 (TP, FP, FN) 状态，并返回能达到最大 F1 的三元组。
        """
        if DP[u] is not None:
            return DP[u]

        # 落在当前子树中的总正样本数 P_u 和总负样本数 N_u
        P_u = P[u]
        N_u = N_count[u]

        # 初始化最优状态为 (TP=0, FP=0, FN=总正样本数) 对应的F1=0.0
        # 如果 P_u > 0，则最优 F1 至少可以从剪枝得到。

        max_f1 = -1.0
        best_stats = (0, 0, P_u)  # 默认：所有样本预测为0

        # 1. 方案：剪枝为叶子节点，输出 label = 1
        # TP = P_u, FP = N_u, FN = 0
        stats_cut_1 = (P_u, N_u, 0)
        f1_cut_1 = calculate_f1(*stats_cut_1)
        if f1_cut_1 > max_f1:
            max_f1 = f1_cut_1
            best_stats = stats_cut_1

        # 2. 方案：剪枝为叶子节点，输出 label = 0
        # TP = 0, FP = 0, FN = P_u
        stats_cut_0 = (0, 0, P_u)
        f1_cut_0 = calculate_f1(*stats_cut_0)
        if f1_cut_0 > max_f1:
            max_f1 = f1_cut_0
            best_stats = stats_cut_0

        # 3. 方案：不剪枝 (仅对内部节点)
        node = nodes[u]
        is_leaf = (node['L'] == 0 and node['R'] == 0)

        if not is_leaf:
            # 递归获取左右子树的最优状态
            # 注意：如果子节点是 0 (空)，表示它已经是叶子节点，不应再次递归
            # 但在我们的实现中，子节点为0时，while循环已经break，P和N_count不会增加
            # 这里只需判断 L/R > 0

            # 获取左子树的最优状态
            if node['L'] > 0:
                TP_L, FP_L, FN_L = find_best_stats(node['L'])
            else:  # 如果左子树为空，则它的贡献为 0
                TP_L, FP_L, FN_L = 0, 0, 0

                # 获取右子树的最优状态
            if node['R'] > 0:
                TP_R, FP_R, FN_R = find_best_stats(node['R'])
            else:  # 如果右子树为空，则它的贡献为 0
                TP_R, FP_R, FN_R = 0, 0, 0

            # 组合左右子树的最优结果
            TP_combined = TP_L + TP_R
            FP_combined = FP_L + FP_R
            FN_combined = FN_L + FN_R

            stats_combined = (TP_combined, FP_combined, FN_combined)
            f1_combined = calculate_f1(*stats_combined)

            if f1_combined > max_f1:
                max_f1 = f1_combined
                best_stats = stats_combined

        # 存储并返回当前节点的最优状态
        DP[u] = best_stats
        return best_stats

    # 从根节点开始计算最优状态
    if N > 0:
        root_stats = find_best_stats(1)
        # 根节点的最优F1值
        max_f1_result = calculate_f1(*root_stats)
    else:
        max_f1_result = 0.0

    # 输出结果，四舍五入保留6位小数
    print(f"{max_f1_result:.6f}")


# 执行函数
if __name__ == "__main__":
    solve()