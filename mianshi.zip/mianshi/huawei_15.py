# 统计量列表
#
# 给定一个整数序列与一个窗口大小列表。对每一行输入，固定一个公共右边界，对窗口列表中的每个窗口长度各取一个“右对齐”的子数组，分别计算5个统计量，并按窗口列表的顺序依次拼接成一行结果；沿着序列从左到右依次移动右边界，生成多行输出。
# 统计量与计算约定
# * 每个子数组输出5项（固定顺序）：mean、std、min、max、slope。
# * std: 样本标准差（ddof=1）。当窗口长度为1时，std=0。
# * slope: 最小二乘直线斜率，横坐标为 x=0..w−1。若分母为0或 w=1，则 slope=0。
# * 数值格式：若为整数则不带小数点；非整数最多保留3位小数，四舍五入，去掉末尾无意义的0（如 1.0→1，1.10→1.1，1.1116→1.112）。
# 窗口对齐与行数
# * 窗口对齐方式：右对齐。第 i 行的公共右边界为 R=i+max(window_array)−1。对窗口大小 w，取子数组 arr[R−w+1…R]。
# * 行数 n = len(input_array) − max(window_array) + 1。若 len(input_array) < 任一窗口大小，则输出为空。
#
# 输入描述：
# 支持多行输入；每行一组数据，格式为：
# [整数序列], [窗口大小序列]
# 例如：[1, 2, 3, 4, 5], [2, 3]
# 输出描述：
# 对每一行输入，按行输出多个结果行；每个结果行是该位置处按窗口列表顺序拼接的统计量列表。
# 若该行输入不满足条件（如数组过短），仅输出一行“[]”。
#
# 示例1
# 输入例子：
# [2, 4, 6, 8, 10, 12], [2, 4]
# 输出例子：
# [7, 1.414, 6, 8, 2, 5, 2.582, 2, 8, 2]
# [9, 1.414, 8, 10, 2, 7, 2.582, 4, 10, 2]
# [11, 1.414, 10, 12, 2, 9, 2.582, 6, 12, 2]
# 例子说明：
# 最长窗口为4，右对齐到各行的共同右边界 R，因此共有 6-4+1=3 行。
# 第1行：w=2 用 [6,8]，w=4 用 [2,4,6,8]；依序拼接5个特征后输出。其余行同理。
#
# 示例2
# 输入例子：
# [10, 20], [3, 4]
# 输出例子：
# []
# 例子说明：
# 输入序列长度为 2，最大窗口为 4，因 2 < 4 无法形成任何右对齐窗口，按规则该行仅输出“[]”。

import sys
import math


def format_num(x):
    """格式化数字：整数则无小数点，非整数最多保留3位小数，四舍五入，去除末尾无意义的0"""
    if isinstance(x, (int, float)):
        if x == int(x):
            return str(int(x))
        else:
            # 四舍五入到3位小数
            x_rounded = round(x, 3)
            # 格式化为字符串，保留3位小数
            s = format(x_rounded, ".3f")
            # 去除末尾的0和可能的小数点
            if "." in s:
                s = s.rstrip("0").rstrip(".")
            return s
    return str(x)


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        # 解析输入行，提取整数序列和窗口大小列表
        parts = line.split("], [", 1)  # 最多分割一次
        if len(parts) < 2:
            print("[]")
            continue

        # 处理字符串格式，确保可以解析为列表
        arr_str = parts[0] + "]"  # 第一部分补上右括号
        win_str = "[" + parts[1]  # 第二部分补上左括号

        try:
            import ast

            arr = ast.literal_eval(arr_str)
            windows = ast.literal_eval(win_str)
        except (SyntaxError, ValueError):
            print("[]")
            continue

        # 检查整数序列长度是否小于任一窗口大小
        max_win = max(windows) if windows else 0
        n = len(arr)
        if n < max_win or max_win == 0:  # 空窗口列表也输出[]
            print("[]")
            continue

        # 计算行数
        num_rows = n - max_win + 1

        # 处理每一行输出
        for i in range(num_rows):
            R = i + max_win - 1  # 公共右边界索引
            row_stats = []  # 存储当前行的所有统计量（字符串形式）

            for w in windows:  # 按窗口列表顺序处理每个窗口
                start = R - w + 1
                sub_arr = arr[start : start + w]  # 右对齐子数组

                # 计算统计量
                # 1. mean (平均值)
                mean_val = sum(sub_arr) / w

                # 2. std (样本标准差，ddof=1)
                if w == 1:
                    std_val = 0.0
                else:
                    sq_diff = sum((x - mean_val) ** 2 for x in sub_arr)
                    std_val = math.sqrt(sq_diff / (w - 1))

                # 3. min (最小值)
                min_val = min(sub_arr)
                # 4. max (最大值)
                max_val = max(sub_arr)

                # 5. slope (最小二乘斜率)
                if w == 1:
                    slope_val = 0.0
                else:
                    # x坐标: 0, 1, ..., w-1
                    sum_x = w * (w - 1) / 2.0  # Σx_i
                    sum_y = sum(sub_arr)  # Σy_i
                    sum_xy = sum(j * sub_arr[j] for j in range(w))  # Σ(x_i * y_i)
                    sum_x2 = (w - 1) * w * (2 * w - 1) / 6.0  # Σ(x_i^2)

                    # 计算分母和分子
                    denominator = sum_x2 - (sum_x ** 2) / w
                    if abs(denominator) < 1e-10:  # 处理浮点误差或分母为0
                        slope_val = 0.0
                    else:
                        numerator = sum_xy - (sum_x * sum_y) / w
                        slope_val = numerator / denominator

                # 格式化五个统计量并添加到当前行
                stats = [mean_val, std_val, min_val, max_val, slope_val]
                formatted_stats = [format_num(val) for val in stats]
                row_stats.extend(formatted_stats)

            # 生成当前行的输出字符串
            output_line = "[" + ", ".join(row_stats) + "]"
            print(output_line)


if __name__ == "__main__":
    main()
