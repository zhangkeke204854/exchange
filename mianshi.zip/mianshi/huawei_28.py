# 量子网络穿梭
# 在一个未来的量子计算中心，您需要引导一个数据包（Data Packet）通过一个复杂的量子网络。该网络可以被抽象为一个 m×n 的二维矩阵。网络中的每个节点都有其特定的功能：
# - 标准通道 (Standard Channel) : 用数字 0 表示，数据包可以在相邻的标准通道节点之间自由移动，每次移动消耗 1 个时间单位。
# - 防火墙 (Firewall) : 用数字 1 表示，这些节点是损坏的或被设置为不可通行，数据包无法进入。
# - 量子纠缠门 (Quantum Entanglement Gate) : 用数字 2 表示。网络中存在成对的纠缠门。当数据包进入一个纠缠门时，它可以瞬间、不耗费任何时间地传送到与之配对的另一个纠缠门所在的位置。
# - 起点 (Source) : 用符号 S 表示，是数据包的初始位置。
# - 终点 (Destination) : 用符号 E 表示，是数据包的目标位置。
# 您的任务是计算出数据包从起点 S 到达终点 E 所需的最短时间。数据包只能在网络的上下左右四个方向上移动，不能移出网络边界，也不能穿过防火墙。如果数据包无法到达终点，则返回 -1。
# 输入描述：
# 输入的第一行包含两个正整数m和 n (1<=m,n<=50)，分别代表量子网络的行数和列数。
# 接下来的 m 行，每行包含 n 个字符，描述了量子网络每个节点的类型。字符集为{‘0’, ‘1’, ‘2’, ‘S’ , ‘E’}。
# 输出描述：
# 输出一个整数，表示数据包从起点到终点所需的最短时间。如果无法到达，则输出-1。
# 示例1
# 输入例子：
# 4 9
# 001010000
# 00000000S
# 0100E0001
# 100000001
# 输出例子：
# 5


import heapq
from collections import defaultdict


def solve():
    m, n = map(int, input().split())
    grid = []
    for _ in range(m):
        grid.append(input().strip())

    # 找到起点、终点和所有纠缠门
    start = None
    end = None
    teleport_gates = []  # 存储所有纠缠门的位置

    for i in range(m):
        for j in range(n):
            if grid[i][j] == 'S':
                start = (i, j)
            elif grid[i][j] == 'E':
                end = (i, j)
            elif grid[i][j] == '2':
                teleport_gates.append((i, j))

    # 建立纠缠门配对关系
    # 假设纠缠门按输入顺序两两配对
    teleport_map = {}
    for i in range(0, len(teleport_gates), 2):
        if i + 1 < len(teleport_gates):
            gate1 = teleport_gates[i]
            gate2 = teleport_gates[i + 1]
            teleport_map[gate1] = gate2
            teleport_map[gate2] = gate1

    # Dijkstra算法
    # dist[i][j] 表示到达位置(i,j)的最短时间
    dist = [[float('inf')] * n for _ in range(m)]
    pq = []  # 优先队列 (time, row, col)

    dist[start[0]][start[1]] = 0
    heapq.heappush(pq, (0, start[0], start[1]))

    # 四个方向：上、下、左、右
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    while pq:
        time, row, col = heapq.heappop(pq)

        # 如果已经找到了更优解，跳过
        if time != dist[row][col]:
            continue

        # 如果到达终点
        if (row, col) == end:
            print(time)
            return

        # 普通移动：四个方向
        for dr, dc in directions:
            new_row, new_col = row + dr, col + dc

            # 检查边界
            if 0 <= new_row < m and 0 <= new_col < n:
                cell = grid[new_row][new_col]
                # 不能进入防火墙
                if cell != '1':
                    new_time = time + 1
                    if new_time < dist[new_row][new_col]:
                        dist[new_row][new_col] = new_time
                        heapq.heappush(pq, (new_time, new_row, new_col))

        # 量子传送：如果当前是纠缠门，可以传送到配对门
        if grid[row][col] == '2':
            if (row, col) in teleport_map:
                dest_row, dest_col = teleport_map[(row, col)]
                # 传送不消耗时间
                if time < dist[dest_row][dest_col]:
                    dist[dest_row][dest_col] = time
                    heapq.heappush(pq, (time, dest_row, dest_col))

    # 无法到达终点
    print(-1)


solve()
