# 量子门
# 在一个前沿的量子计算实验中，一组 n 个量子比特（qubit）被初始化到一个特定的纠缠态。
# 然而，为了进行下一步的计算，必须将所有量子比特精确地重置到基态，即 ∣0⟩ 态。
# 由于量子纠缠的复杂性，对单个量子比特施加操作门（quantum gate）不仅会改变其自身的状态，还可能同时翻转其他与之纠缠的量子比特的状态。
# 系统的状态可以用一个 n 维的二进制向量 S=(s_1,s_2,…,s_n) 来描述，其中 s_i∈{0,1}。s_i=1 表示第 i 个量子比特处于激发态 ∣1⟩，s_i=0 表示处于基态 ∣0⟩。
# 我们有 n 种量子门操作，记为 G_1,G_2,…,G_n。施加操作 G_i 的效果如下：
# 1. 必定会翻转第 i 个量子比特的状态，即 s_i→1-s_i。
# 2. 由于纠缠效应，施加 G_i 还会翻转一系列其他量子比特 s_j,s_k,… 的状态。
# 每次操作都是一个翻转操作（异或 1）。同一个操作施加两次会抵消其效果。我们的目标是找到一个操作序列，使得系统从初始状态 S_initial 演化到全零向量 S_final=(0,0,…,0)。
# 给定系统的初始状态和所有 n 种操作的纠缠影响关系，请找出一个解决方案。如果不存在任何解决方案，则输出 -1。若存在多种解决方案，您需要输出满足以下条件的最优解：
# 1. 施加的操作门数量最少。
# 2. 在数量最少的基础上，选择操作序列的字典序最小的方案（即操作的量子比特编号组成的序列）。
# 输入描述：
# 第一行包含两个整数 n 和 m，分别代表量子比特的数量和额外的纠缠关系数量。数据范围为 1<=n<=20，0<=m<=n.(n-1)。
# 第二行包含n个整数，表示初始状态向量 S_initial。第i个整数 s_i∈{0,1} 代表第   个量子比特的初始状态。
# 接下来的m行，每行包含两个整数 x,y(1<=x,y<=n,x!=y)，表示施加量子门G_x会额外翻转量子比特y的状态。
# 输出描述：
# 如果无解，输出一行 -1。
# 如果有解，输出一行升序排列的整数，代表最优操作序列中需要施加的量子门的编号。整数之间用单个空格分隔。
# 示例1
# 输入例子：
# 3 5
# 1 1 1
# 1 2
# 2 1
# 2 3
# 3 1
# 3 2
# 输出例子：
# 2
# 示例2
# 输入例子：
# 4 6
# 1 0 0 0
# 1 4
# 2 1
# 2 4
# 3 1
# 4 2
# 4 3
# 输出例子：
# -1


from itertools import combinations

def solve():
    n, m = map(int, input().split())
    initial = list(map(int, input().split()))

    # 构建每个操作的影响（位掩码）
    # effect[i] 表示操作i+1会影响的量子比特的位掩码
    effect = [0] * n

    # 每个操作必定影响自己
    for i in range(n):
        effect[i] = (1 << i)

    # 处理额外的纠缠关系
    for _ in range(m):
        x, y = map(int, input().split())
        # 操作x会影响量子比特y
        effect[ x -1] |= (1 << ( y -1))

    # 初始状态转换为位掩码
    initial_mask = 0
    for i in range(n):
        if initial[i] == 1:
            initial_mask |= (1 << i)

    # 如果初始状态已经是全0
    if initial_mask == 0:
        print("")
        return

    # 按操作数从小到大搜索
    for ops_count in range(1, n + 1):
        # 生成所有大小为ops_count的操作组合，按字典序
        for combo in combinations(range(n), ops_count):
            # 计算应用这些操作后的状态
            current_mask = initial_mask
            for op in combo:
                current_mask ^= effect[op]

            if current_mask == 0:
                # 找到解，输出操作编号（1-indexed）
                result = [str(op + 1) for op in combo]
                print(" ".join(result))
                return

    # 无解
    print(-1)

solve()
