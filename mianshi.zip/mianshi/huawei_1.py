# K-Means聚类下的Anchor优化输出
# 在目标检测任务中，常需为候选框选择一组代表性的 Anchor 尺寸。现给定 N 个矩形框的宽和高，使用基于 IOU 距离的 k-means 聚类得到 K 个 Anchor。
# 初始化时直接取前 K 个框作为初始中心；每轮迭代将每个样本分配给距离最近的中心；随后将每个簇内样本的宽、高分别取均值并向下取整作为新中心。
# 若达到最大迭代次数 T，或新旧中心之间的总“位移”小于 1e-4（用 d=1−IOU 作为中心间距离，并对 K 个中心求和），则停止。最终按 Anchor 面积（宽×高）从大到小输出 K 个中心。
#
# 说明与约束
# 1.距离度量：d = 1 − IOU，其中 IOU = 交集面积 / 并集面积，交集面积 = min(w1,w2) × min(h1,h2)，并集面积 = w1×h1 + w2×h2 − 交集面积。
# 2.所有距离与 IOU 的计算均用浮点；每轮更新后的中心宽、高先取均值再向下取整为整数。
# 3.若某簇在某轮为空，则该簇中心保持不变。
# 4.输出前按面积从大到小排序；若面积相同，可按宽、再按高降序作为次序规则。
# 输入描述：
# 第一行：N K T（以空格分隔）
# 接下来 N 行：每行两个整数 w h，表示一个检测框的宽与高。
# 输出描述：
# 输出 K 行：每行两个整数，依次为一个 Anchor 的宽与高，按面积从大到小排序。
# 示例1
# 输入例子：
# 9 3 10
# 100 50
# 30 20
# 10 10
# 102 49
# 98 52
# 29 21
# 31 19
# 11 9
# 9 11
# 输出例子：
# 100 50
# 30 20
# 10 10
# 例子说明：
# 初始中心为 (100,50)、(30,20)、(10,10)。
# 分配后每个簇的均值向下取整仍为 (100,50)、(30,20)、(10,10)，迭代收敛。
# 按面积排序的结果如上。


import sys


def iou(box1, box2):
    """
    计算两个矩形框的 IOU（交并比）。
    矩形框表示为 (w, h)，假设共享同一左上角（如 (0,0)）。
    """
    w1, h1 = box1
    w2, h2 = box2
    inter_w = min(w1, w2)
    inter_h = min(h1, h2)
    inter_area = inter_w * inter_h
    area1 = w1 * h1
    area2 = w2 * h2
    union_area = area1 + area2 - inter_area
    if union_area == 0:
        return 0.0  # 避免除以零
    iou_val = inter_area / union_area
    return iou_val


def main():
    data = sys.stdin.read().splitlines()
    print(data)
    if not data:
        return

    # 解析第一行：N, K, T
    parts = data[0].split()
    N = int(parts[0])
    K = int(parts[1])
    T = int(parts[2])

    # 解析 N 个矩形框的宽和高
    boxes = []
    for i in range(1, 1 + N):
        parts = data[i].split()
        if len(parts) < 2:
            continue
        w = int(parts[0])
        h = int(parts[1])
        boxes.append((w, h))

    # 确保 K <= N，防止无效输入
    if K > N:
        K = N

    # 初始化中心：取前 K 个框
    centers = boxes[:K]  # 列表，每个元素为 (w, h)

    # K-Means 迭代
    for _ in range(T):
        clusters = [[] for _ in range(K)]  # 初始化 K 个空簇

        # 分配步骤：将每个样本分配给距离最近的中心
        for box in boxes:
            min_d = float('inf')  # 最小距离初始化为无穷大
            min_idx = -1  # 最近中心的索引
            for idx, center in enumerate(centers):
                iou_val = iou(box, center)  # 计算 IOU
                d = 1 - iou_val  # 距离 d = 1 - IOU
                if d < min_d:
                    min_d = d
                    min_idx = idx
            if min_idx != -1:  # 确保找到中心
                clusters[min_idx].append(box)

        # 更新步骤：计算新中心
        new_centers = []
        for i in range(K):
            if len(clusters[i]) == 0:
                # 簇为空，中心保持不变
                new_centers.append(centers[i])
            else:
                # 计算簇内样本宽和高的平均值
                total_w = 0
                total_h = 0
                count = len(clusters[i])
                for w, h in clusters[i]:
                    total_w += w
                    total_h += h
                mean_w = total_w / count  # 浮点平均
                mean_h = total_h / count
                new_w = int(mean_w)  # 向下取整为整数
                new_h = int(mean_h)
                new_centers.append((new_w, new_h))

        # 计算总位移：新旧中心间的 d=1-IOU 之和
        total_disp = 0.0
        for j in range(K):
            iou_val = iou(new_centers[j], centers[j])
            d = 1 - iou_val
            total_disp += d

        # 检查停止条件：总位移 < 1e-4
        if total_disp < 1e-4:
            break
        else:
            centers = new_centers  # 更新中心，继续下一轮迭代

    # 输出前按面积排序：面积降序，面积相同则宽降序、再高降序
    sorted_centers = sorted(
        centers,
        key=lambda c: (c[0] * c[1], c[0], c[1]),  # 键为 (面积, 宽, 高)
        reverse=True  # 降序排序
    )

    # 输出 K 个 Anchor
    for w, h in sorted_centers:
        print(f"{w} {h}")


if __name__ == "__main__":
    main()
