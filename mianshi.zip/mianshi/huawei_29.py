# 特工身份识别系统
# 在一个高度机密的跨国情报机构中，为了确保信息安全，所有特工都配备了一个唯一的 48 位二进制身份代号。该代号通常以 6 个十六进制字节的形式表示，例如 `00-d8-61-ef-31-3e`。
# 为了管理庞大的特工网络并精确控制访问权限，机构采用了一种基于前缀匹配的授权体系。一个授权规则由基础代号和安全等级 M 共同定义，格式为 `xx-xx-xx-xx-xx-xx/M`。
# 安全等级 M 是一个介于 0 到 48 之间的整数，它定义了身份代号中需要匹配的前 M 位。
# - 当 M=48 时，要求身份代号完全匹配，这通常用于授权单个特工。
# - 当 M<48 时，只要求身份代号的前 M 位与基础代号的前 M 位相同，这通常用于授权一个小组或整个部门。
# 例如，一条规则 `00-e0-fc-01-01-01/32` 意味着所有身份代号以 `00-e0-fc-01` 开头的特工都将被授予权限，其代号范围从 `00-e0-fc-01-00-00` 到 `00-e0-fc-01-ff-ff`。
# - 特别地，当 M=0 时，不匹配任何位，意味着授权所有特工。
# 您的任务是开发一个高效的身份认证系统。给定一组授权规则，您需要快速判断前来访问的特工是否在授权列表中。
# 输入描述：
# 输入的第一行是一个整数 n (1<=n<=100000)，代表授权规则的总数。
# 接下来的 n 行，每行包含一条授权规则，格式为 `xx-xx-xx-xx-xx-xx/M`，其中 M 是一个整数（0<=M<=48），`xx` 是由小写字母 `a-f` 和数字 `0-9` 组成的两位十六进制数。
# 随后的一行是一个整数 m (1<=m<=100)，代表待验证的特工数量。
# 接下来的 m 行，每行包含一个待验证的特工身份代号，格式为 `xx-xx-xx-xx-xx-xx`。
# 输出描述：
# 对于m个待验证的身份代号，逐行输出认证结果。如果一个代号至少匹配授权列表中的一条规则，则输出 `YES`；否则输出 `NO`。
# 示例1
# 输入例子：
# 10
# 7e-01-22-50-24-03/24
# e0-6b-23-3f-23-15/10
# 58-7e-2a-50-e0-5f/19
# bc-09-f7-b2-b3-92/46
# e5-22-aa-f3-8c-8d/6
# f1-62-a1-b1-90-d3/34
# 77-c3-f0-60-cd-d5/31
# 1a-2b-14-85-11-f2/48
# a6-35-dc-ec-f8-fb/24
# ab-3e-94-df-cb-e8/9
# 8
# c2-94-58-13-76-28
# e5-22-aa-f3-8c-8d
# 98-7a-23-6f-e6-de
# e0-6b-23-3f-23-15
# 77-c3-f0-60-cd-d5
# b4-4a-ec-51-0a-fc
# 7e-01-22-50-24-03
# e0-6b-23-3f-23-15
# 输出例子：
# NO
# YES
# NO
# YES
# YES
# NO
# YES
# YES

def hex_to_int(hex_str):
    """将xx-xx-xx-xx-xx-xx格式的十六进制字符串转换为整数"""
    # 移除连字符并转换为整数
    clean_str = hex_str.replace("-", "")
    return int(clean_str, 16)


def match_prefix(id1, id2, prefix_len):
    """检查两个48位身份的前prefix_len位是否匹配"""
    if prefix_len == 0:
        return True

    # 创建掩码：高prefix_len位为1，其余为0
    # 48位总长度
    mask = ((1 << 48) - 1) ^ ((1 << (48 - prefix_len)) - 1)

    # 应用掩码并比较
    return (id1 & mask) == (id2 & mask)


def solve():
    n = int(input())

    # 存储所有规则 (身份整数, 前缀长度)
    rules = []
    for _ in range(n):
        line = input().strip()
        if "/" in line:
            hex_part, m_part = line.split("/")
            m = int(m_part)
            identity_int = hex_to_int(hex_part)
            rules.append((identity_int, m))

    m_queries = int(input())

    # 处理每个查询
    for _ in range(m_queries):
        query_hex = input().strip()
        query_int = hex_to_int(query_hex)

        matched = False
        for rule_identity, prefix_len in rules:
            if match_prefix(query_int, rule_identity, prefix_len):
                matched = True
                break

        print("YES" if matched else "NO")


solve()
