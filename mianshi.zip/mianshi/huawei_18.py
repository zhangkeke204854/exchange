# 基因序列相似度分析
# 在基因工程研究中，科学家们经常需要将一个新发现的基因片段与一个庞大的已知基因序列数据库进行比对，以寻找功能或来源上最相似的序列。这种相似度通常通过所谓的“突变距离”来衡量。
# 突变距离（即莱文斯坦距离）被定义为：将一个基因序列转换为另一个序列所需的最少“点突变”操作次数。允许的点突变操作有三种：
# 1. 替换 (Substitution)：将一个碱基替换成另一个碱基。
# 2. 插入 (Insertion)：在一个序列的任意位置插入一个碱基。
# 3. 删除 (Deletion)：从一个序列中删除任意一个碱基。
# 你的任务是编写一个程序，对于一个给定的待测基因片段，从数据库中找出所有与之足够相似的基因序列。
# 输入描述：
# 第一行是一个整数D，代表可接受的最大突变容忍度。
# 第二行是一个整数N，代表基因数据库中序列的总数。
# 接下来N行，每行是一个已知的基因序列。
# 最后一行是待测的基因片段。
#
# 约束条件：
# * 1<=D<=5
# * 1<=N<=30000
# * 单个基因序列的长度L满足 2<=L<=25
# * 为简化模型，所有基因序列只包含小写英文字母。
# 输出描述：
# 根据比对结果，分三种情况输出：
# 1. 精确匹配：如果待测基因片段与数据库中的某个序列完全相同，直接输出该序列。
# 2. 模糊匹配：如果不存在精确匹配，则找出所有与待测片段的突变距离小于或等于 D的序列。将这些序列首先按突变距离从小到大排序，若距离相同，则按字典序从小到大排序。最后将排序后的结果用空格隔开，在一行内输出。
# 3. 无匹配：如果不存在精确匹配，且数据库中没有任何序列满足突变距离小于或等于D的条件，则输出 None 。
# 示例1
# 输入例子：
# 2
# 10
# xomputer
# compter
# yomputerz
# comput
# aomputer
# pmrphtow
# qgktdywi
# hsgysjll
# sepmotrz
# cibmmdie
# computer
# 输出例子：
# aomputer compter xomputer comput yomputerz

import sys


def levenshtein(s1, s2):
    """计算两个字符串的莱文斯坦距离（编辑距离）"""
    m = len(s1)
    n = len(s2)
    if m == 0:
        return n
    if n == 0:
        return m

    # 使用两行DP数组节省空间
    prev_row = list(range(n + 1))  # 初始化第0行
    curr_row = [0] * (n + 1)

    for i in range(1, m + 1):
        curr_row[0] = i  # 初始化当前行的第一个元素
        for j in range(1, n + 1):
            if s1[i - 1] == s2[j - 1]:
                cost = 0
            else:
                cost = 1
            # 计算当前单元格：min(删除、插入、替换/匹配)
            curr_row[j] = min(
                prev_row[j] + 1,  # 删除操作
                curr_row[j - 1] + 1,  # 插入操作
                prev_row[j - 1] + cost  # 替换或匹配
            )
        # 行交换：当前行变为前一行
        prev_row, curr_row = curr_row, prev_row

    # 循环结束后，prev_row 存储最后一行
    return prev_row[n]


def main():
    data = sys.stdin.read().splitlines()
    if not data:
        return

    D = int(data[0].strip())
    N = int(data[1].strip())

    # 读取数据库序列
    database = []
    for i in range(2, 2 + N):
        seq = data[i].strip()
        database.append(seq)

    # 读取待测序列
    query = data[2 + N].strip()

    # 检查精确匹配
    if query in database:
        print(query)
        return

    # 模糊匹配：先过滤序列长度在 [len(query) - D, len(query) + D] 范围内
    min_len = len(query) - D
    max_len = len(query) + D
    candidates = [seq for seq in database if min_len <= len(seq) <= max_len]

    # 计算距离并收集匹配序列
    matches = []  # 存储 (序列, 距离) 元组
    for seq in candidates:
        dist = levenshtein(query, seq)
        if dist <= D:
            matches.append((seq, dist))

    # 处理输出
    if not matches:
        print("None")
    else:
        # 排序：先按距离升序，再按序列字典序升序
        matches.sort(key=lambda x: (x[1], x[0]))
        # 提取序列并输出
        output_seqs = [item[0] for item in matches]
        print(" ".join(output_seqs))


if __name__ == "__main__":
    main()
