# 探索宇宙中的星系联盟
# 在浩瀚无垠的宇宙中，散布着无数的星系。一部分星系之间通过稳定的“星际航道”紧密相连，形成一个个“星系联盟”。在本题的设定里，一个星系联盟由一个或多个通过星际航道直接或间接相连的星系构成，这在图论中被称为一个 无向图的连通分量 。
# 每个星系都拥有一个独一无二的“文明等级”，这是一个正整数，代表了该星系文明的繁荣程度。而一个星系联盟的总实力，则定义为该联盟内所有星系文明等级之和。
# 现在，作为星际探险家的您，得到了一份星图。这份星图包含了各个星系的文明等级信息，以及它们之间的星际航道连接情况。您的任务是：
# 1.  分析这份星图，找出其中所有独立的星系联盟。
# 2.  计算每个星系联盟的总实力。
# 3.  在所有联盟中，找到总实力最强的那一个。
# 4.  最终，请报告这个最强联盟中，文明等级最高的那个星系的名称，以及该联盟的总实力。
# 输入描述：
# 输入数据描述了一张包含n个星系和m条星际航道的星图。
# -   第一行是一个整数 n，代表星系的总数。n的取值范围为 [1,160]。
# -   接下来 n 行，每行描述一个星系。格式为 `星系名称 文明等级`。
# -   `星系名称` 是一个长度不超过32的字符串，仅由小写字母和数字组成。
# -   `文明等级` 是一个整数，其取值范围为 [1,10000]。
# -   之后的一行是一个整数 m，代表星际航道的总数。m 的取值范围为 [0,160]。
# -   随后的 m 行，每行描述一条星际航道，格式为 `星系A名称 星系B名称`，表示星系A与星系 B 之间存在一条双向航道。输入保证这里出现的星系名称都已在前文中定义过。
# -   特别地，当 m=0 时，表示星系之间没有任何航道，每个星系都是一个独立的联盟。
# 输出描述：
# 请输出一行，包含两项内容，以空格隔开：在总实力最强的星系联盟中，文明等级最高的星系的名称，以及该联盟的总实力。
# 题目保证所有星系的文明等级各不相同，并且总实力最强的星系联盟是唯一的。
# 示例1
# 输入例子：
# 10
# 21hjdgv0vj 6587
# 3j82e2tmk2 7928
# 43hhi7u8f8 6659
# 80htg9ud23 6957
# 8b96bgxl55 8524
# bf98w33f47 8692
# i1b09lbu79 5801
# nuy3c55lzm 9341
# r371vsjr84 7467
# wj7x829uc1 2438
# 8
# 3j82e2tmk2 80htg9ud23
# 43hhi7u8f8 80htg9ud23
# 43hhi7u8f8 bf98w33f47
# 43hhi7u8f8 r371vsjr84
# 80htg9ud23 r371vsjr84
# 8b96bgxl55 wj7x829uc1
# i1b09lbu79 nuy3c55lzm
# i1b09lbu79 r371vsjr84
# 输出例子：
# nuy3c55lzm 52845

from collections import deque
import sys


def main():
    data = sys.stdin.read().splitlines()
    if not data:
        return

    n = int(data[0].strip())
    civilization = {}
    graph = {}

    index = 1
    for _ in range(n):
        parts = data[index].split()
        galaxy = parts[0]
        level = int(parts[1])
        civilization[galaxy] = level
        graph[galaxy] = []
        index += 1

    m = int(data[index].strip())
    index += 1

    for _ in range(m):
        parts = data[index].split()
        a, b = parts[0], parts[1]
        graph[a].append(b)
        graph[b].append(a)
        index += 1

    visited = set()
    max_total = -1
    best_galaxy = None

    for galaxy in civilization:
        if galaxy in visited:
            continue

        # BFS 遍历连通分量
        component = []
        queue = deque([galaxy])
        visited.add(galaxy)
        while queue:
            node = queue.popleft()
            component.append(node)
            for neighbor in graph[node]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)

        # 计算联盟总实力和最高文明等级
        total = sum(civilization[node] for node in component)
        max_in_component = max(component, key=lambda x: civilization[x])

        # 更新最强联盟信息
        if total > max_total:
            max_total = total
            best_galaxy = max_in_component

    print(f"{best_galaxy} {max_total}")


if __name__ == "__main__":
    main()
