# 标签在前K个近邻中的出现次数
#
# * 你需要为一个简单的多分类识别器补上“K 近邻”判别模块。做法是：先度量待测样本与训练样本的距离，挑选出距离最近的 K 个样本，再用多数票决定最终类别。
# * 操作要点（按流程执行）：
#     * 先计算待测点到每个样本点的距离（为了效率，可直接用“平方欧氏距离”参与排序，结果等价）。
#     * 将样本按距离升序排列，截取前 K 个作为近邻。
#     * 统计这 K 个近邻的标签出现次数，频数最高的标签即为预测值。
#     * 如出现“最高频数并列”，只在并列标签对应的近邻里，按由近到远的顺序挑第一个的标签。
# * 约束与假设：
#     * 数据集已做归一化处理（不同维度量纲一致），特征保留两位小数。
#     * 每个类别在数据集中都至少有一个样本。
#     * 距离采用欧氏距离
#
# 输入描述：
# * 第 1 行：k m n s k 为最近邻个数（≤20），m 为样本数（≤200），n 为特征维度（不含标签，≤5），s 为类别个数（≤5）。
# * 第 2 行：待分类样本的 n 维特征。
# * 第 3 行至第 m+2 行：每行 n+1 列，前 n 列为特征，最后 1 列为类别标签（整数，以浮点给出）。
# 输出描述：
# 输出两项：预测标签 与 该标签在前 K 个近邻中的出现次数
# 格式：label count
#
# 示例1
# 输入例子：
# 3 6 2 2
# 0.00 0.00
# 0.20 0.10 0.0
# 0.30 0.00 0.0
# 0.00 0.40 1.0
# 0.60 0.60 1.0
# 0.05 0.02 0.0
# 0.90 0.90 1.0
# 输出例子：
# 0 3
# 例子说明：
# 距离最近的 3 个样本依次为 (0.05,0.02,0), (0.20,0.10,0), (0.30,0.00,0)。
# 多数票为标签 0，且在前 K=3 个邻居中出现 3 次，故输出“0 3”。


import sys


def main():
    data = sys.stdin.read().splitlines()
    if not data:
        return

    # 解析第一行参数
    k, m, n, s = map(int, data[0].split())

    # 解析待分类样本特征
    test_sample = list(map(float, data[1].split()))

    # 解析训练数据
    train_data = []
    for i in range(2, 2 + m):
        parts = list(map(float, data[i].split()))
        features = parts[:n]
        label = int(parts[-1])  # 将标签转换为整数
        train_data.append((features, label))

    # 计算平方欧氏距离并保留原始索引
    distances = []
    for idx, (features, label) in enumerate(train_data):
        dist_sq = 0.0
        for j in range(n):
            diff = features[j] - test_sample[j]
            dist_sq += diff * diff
        distances.append((dist_sq, idx, label))

    # 按距离排序（距离相同时保持原始顺序）
    distances.sort(key=lambda x: x[0])

    # 取前K个最近邻
    nearest = distances[:k]

    # 统计标签出现次数
    label_count = {}
    for _, _, label in nearest:
        label_count[label] = label_count.get(label, 0) + 1

    # 找出最高频次
    max_count = max(label_count.values()) if label_count else 0

    # 找出所有达到最高频次的标签
    candidates = [label for label, count in label_count.items() if count == max_count]

    # 处理平票情况：选择距离最近的标签
    if len(candidates) > 1:
        # 按距离顺序遍历，找到第一个候选标签
        for dist, _, label in nearest:
            if label in candidates:
                predicted_label = label
                break
    else:
        predicted_label = candidates[0] if candidates else None

    # 输出结果（如果无法分类则输出0）
    if predicted_label is not None:
        print(f"{predicted_label} {max_count}")
    else:
        print("0 0")


if __name__ == "__main__":
    main()
