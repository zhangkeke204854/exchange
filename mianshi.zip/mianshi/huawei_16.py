# 火星探测器稳定性分析
# “祝融号”火星探测器在火星表面执行一项精密科学探测任务。其搭载的科学仪器对工作环境的稳定性有非常严苛的要求。为了保证仪器的正常运行和数据的准确性，必须满足以下两个条件：
# 1. 仪器的“环境稳定性指数” S 必须维持在[18,24]的区间内，即 18≤S≤24。
# 2. 在任何一次连续的工作期间内，环境稳定性指数的最大波动范围（即该期间的 S_max-S_min）不得超过 4，即 S_max-S_min≤4。
# 现在，探测器沿一条预定路线行进，并按固定时间间隔连续采集了N次环境稳定性指数。这些数据按采集顺序（索引从0开始）记录下来。
# 为了最大化单次有效工作时长，请你找出满足上述两个稳定条件的、持续时间最长的一个或多个时间段。请输出这些时间段的起始和结束索引。如果存在多个长度相同的最长时间段，请按照起始索引从小到大的顺序，逐行输出。
# 输入描述：
# 第一行为连续采集的次数N，其中N的取值范围为 [1, 10**5]。
# 第二行为N个按顺序采集的环境稳定性指数，均为整数，数值范围为 [0,30]。数值之间以空格分隔。
# 输出描述：
# 输出持续时间最长且满足稳定条件的时间段的起始索引和结束索引，两者以空格分隔。如果存在多个这样的时间段，按起始索引升序逐行输出。
# 示例1
# 输入例子：
# 20
# 27 2 19 16 24 9 29 21 28 10 5 27 6 4 27 11 14 1 4 27
# 输出例子：
# 2 2
# 4 4
# 7 7


import sys
from collections import deque


def solve_stability_analysis():
    """
    Finds the longest time periods (subarrays) that satisfy the two stability conditions
    using the Sliding Window with Monotonic Deques technique.
    """
    try:
        # Read N (number of measurements)
        N = int(sys.stdin.readline().strip())
    except:
        # Handle empty input or conversion error
        return

    try:
        # Read the stability indices
        s_values = list(map(int, sys.stdin.readline().split()))
    except:
        # Handle missing second line
        s_values = []

    if N == 0 or not s_values:
        return

    # Constants from the problem
    MIN_S = 18
    MAX_S = 24
    MAX_FLUCTUATION = 4

    # 1. Pre-process and identify segments satisfying Constraint 1 (18 <= S <= 24)
    valid_indices_segments = []
    current_segment = []
    for i, s in enumerate(s_values):
        if MIN_S <= s <= MAX_S:
            current_segment.append(i)
        else:
            if current_segment:
                valid_indices_segments.append(current_segment)
            current_segment = []
    if current_segment:
        valid_indices_segments.append(current_segment)

    max_length = 0
    longest_periods = []

    # 2. Apply Sliding Window (Constraint 2: Smax - Smin <= 4) to each segment
    for segment in valid_indices_segments:
        # The segment contains the 0-based indices of the valid S values

        # Deques to maintain the indices of the max and min values in the window [L, R]
        # Deques store indices, not values, for quick removal from the left end.
        max_deque = deque()
        min_deque = deque()

        L = 0  # Left pointer for the current segment

        for R in range(len(segment)):
            current_index = segment[R]
            current_s = s_values[current_index]

            # Update max_deque: Maintain decreasing order of S values
            while max_deque and s_values[max_deque[-1]] <= current_s:
                max_deque.pop()
            max_deque.append(current_index)

            # Update min_deque: Maintain increasing order of S values
            while min_deque and s_values[min_deque[-1]] >= current_s:
                min_deque.pop()
            min_deque.append(current_index)

            # Check Constraint 2 (Smax - Smin <= 4)
            # max_s and min_s are at the front of their respective deques
            max_s_in_window = s_values[max_deque[0]]
            min_s_in_window = s_values[min_deque[0]]

            # Window shrinking loop (move L forward)
            while max_s_in_window - min_s_in_window > MAX_FLUCTUATION:
                # The index L corresponds to the index *in the segment*
                left_most_index = segment[L]

                # If the value being removed is the current max/min, remove it from the deque
                if max_deque[0] == left_most_index:
                    max_deque.popleft()
                if min_deque[0] == left_most_index:
                    min_deque.popleft()

                L += 1  # Shrink the window

                # Recalculate max/min after shrinking
                if max_deque:
                    max_s_in_window = s_values[max_deque[0]]
                if min_deque:
                    min_s_in_window = s_values[min_deque[0]]

            # Window expansion is complete (R is the right end, L is the left end)
            current_length = R - L + 1
            start_index = segment[L]
            end_index = segment[R]

            # Update the longest periods list
            if current_length > max_length:
                max_length = current_length
                longest_periods = [(start_index, end_index)]
            elif current_length == max_length:
                # If tied, we append the period. Since we process segments
                # and indices in ascending order, the resulting list of periods
                # will already be sorted by starting index.
                longest_periods.append((start_index, end_index))

    # 3. Output the results
    # The output format requires only the longest periods.
    # We remove duplicates in case the same max_length was achieved at multiple
    # R positions within the same shrinking loop (i.e., multiple windows [L, R]
    # of the same max length end at R).

    # We only care about the single longest period that ends at a given R.
    # The list 'longest_periods' contains all periods that *set* the max_length or *tied* it.

    # Since the problem asks for *all* longest time periods, we should ensure
    # that if a period [i, j] is the longest, and [i+1, j+1] is also the longest,
    # both are included. The current logic handles this.

    # Example 1 Check:
    # Segment 1 (19, 24, 21): indices 2, 4, 7. Values 19, 24, 21.
    # R=0 (idx 2, S=19): [2, 2], len 1. max_len=1. periods=[(2, 2)]
    # R=1 (idx 4, S=24): [2, 4]. max=24, min=19. diff=5 > 4. L->1.
    #   [4, 4]. max=24, min=24. diff=0. len 1. periods=[(2, 2), (4, 4)]
    # R=2 (idx 7, S=21): [4, 7]. max=24, min=21. diff=3 <= 4. len 2. max_len=2. periods=[(4, 7)] -> NO, mistake in analysis, index 4 is 24, index 7 is 21.

    # Corrected Segment 1 (indices 2, 4, 7): [19, 24, 21]
    # L=0, R=0 (idx 2, S=19). [2, 2]. len=1. max_len=1. periods=[(2, 2)]
    # L=0, R=1 (idx 4, S=24). max=24, min=19. diff=5. L becomes 1.
    #   L=1 (idx 4). [4, 4]. len=1. max=24, min=24. periods=[(2, 2), (4, 4)]
    # L=1, R=2 (idx 7, S=21). max=24, min=21. diff=3. len=2. max_len=2. periods=[(4, 7)]

    # Segment 2 (19, 24, 21): indices 15, 16. Values 11, 14. -> NO, values are 11, 14. The valid S values are in the range [18, 24].
    # Segment 2 (11, 14): indices 15, 16. S values 11, 14. -> These indices are outside [18, 24] and were filtered out.

    # Rerun logic with Example 1: 27 2 19 16 24 9 29 21 28 10 5 27 6 4 27 11 14 1 4 27
    # Indices 0 to 19.
    # Valid S: 19 (idx 2), 24 (idx 4), 21 (idx 7).
    # Segments: [[2], [4], [7]].
    # Segment [2]: len 1. (2, 2).
    # Segment [4]: len 1. (4, 4).
    # Segment [7]: len 1. (7, 7).
    # Max_length = 1. Periods: (2, 2), (4, 4), (7, 7).
    # This matches the sample output.

    # The output from the code:
    # 2 2
    # 4 4
    # 7 7

    # The output list `longest_periods` should contain only the unique periods of max length.
    # Using a set to ensure uniqueness, then sorting by start index.
    unique_longest_periods = sorted(list(set(longest_periods)), key=lambda x: x[0])

    for start, end in unique_longest_periods:
        print(f"{start} {end}")


# Execute the main function
solve_stability_analysis()
