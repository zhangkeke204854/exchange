# 任务批处理负载均衡
# 一个云计算中心接收到了一系列需要连续处理的微任务。现在有 n 个任务排成一队，每个任务都有一个已知的计算成本。为了高效利用服务器资源，系统需要将这 n 个连续的任务划分成 m 个“批次”进行处理。
# 划分的规则是：必须按照任务队列的顺序进行划分，不能打乱任务原有的先后次序。例如，第一个批次处理前 k_1 个任务，第二个批次处理接下来的 k_2 个任务，以此类推。
# 为了使服务器负载尽可能平稳，调控目标是：找到一种划分方案，使得这 m 个批次各自的“总计算成本”（即批次内所有任务的成本之和）的标准差达到最小。
# 你的任务就是找出这个最优的划分方案。
# 输入描述：
# 第一行输入两个整数，第一个是任务总数 n (2<n<=20)，第二个是需要划分的批次数目m(2<m<n)。
# 第二行输入一个包含n个正整数的序列 C={c0,c1………,cn-1}，其中第i个元素ci代表第i个任务的计算成本 (0<ci<100)。
# 输出描述：
# 输出一行，包含 m 个整数，代表最优划分方案中，每个批次依次包含的任务数量。
# 例如，输出 `3 3 2 2` 表示：第 1 批包含前 3 个任务，第 2 批包含接下来的 3 个任务，第 3 批包含再接下来的 2 个任务，第 4 批包含最后 2 个任务。
# 示例1
# 输入例子：
# 8 4
# 30 42 85 19 65 13 94 57
# 输出例子：
# 2 1 3 2


def main():
    import sys
    data = sys.stdin.read().splitlines()
    if not data:
        return
    n, m = map(int, data[0].split())
    costs = list(map(int, data[1].split()))

    prefix = [0] * (n + 1)
    for i in range(1, n + 1):
        prefix[i] = prefix[i - 1] + costs[i - 1]

    INF = float('inf')
    dp = [[INF] * (m + 1) for _ in range(n + 1)]
    path = [[-1] * (m + 1) for _ in range(n + 1)]

    dp[0][0] = 0
    for i in range(1, n + 1):
        dp[i][1] = prefix[i] ** 2
        path[i][1] = 0

    for k in range(2, m + 1):
        for i in range(k, n + 1):
            for j in range(k - 1, i):
                seg_sum = prefix[i] - prefix[j]
                cost = seg_sum ** 2
                total_cost = dp[j][k - 1] + cost
                if total_cost < dp[i][k]:
                    dp[i][k] = total_cost
                    path[i][k] = j

    i = n
    k = m
    lengths = []
    while k > 0:
        j = path[i][k]
        if j < 0:
            break
        lengths.append(i - j)
        i = j
        k -= 1

    lengths.reverse()
    print(" ".join(map(str, lengths)))


if __name__ == "__main__":
    main()
