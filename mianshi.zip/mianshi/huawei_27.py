# 虫洞网络
# 在遥远的未来，人类文明已经步入深空时代。广袤的宇宙中散布着数不尽的星系，而连接这些星系的，是由一个古老文明遗留下来的神秘“虫洞网络”（Wormhole
# Networks）。每个独立的虫洞网络都连接着一系列的星系。要进入任何一个虫洞网络，飞船都需要消耗特定的能量来激活跃迁引擎。一旦进入某个网络，飞船便可以在该网络所覆盖的所有星系之间进行无消耗的瞬时跳跃。
# 作为一名星际领航员，您的任务是规划一条从起点星系到目标星系的最优航线。
# 整个已知宇宙可以被看作一个图，其中的节点是星系，编号从
# 0
# 到
# 500。总共有
# M
# 个独立的虫洞网络。
# 虫洞网络
# i：这是一个由
# n_i
# 个星系组成的集合，记作
# W_i = {s_(i, 1), s_(i, 2),…, s_(i, n_i)}。
# 跃迁成本
# C_i：要使用虫洞网络
# i
# 进行旅行，必须首先支付
# C_i
# 的能量。支付后，您可以在
# W_i
# 集合内的任意两个星系之间自由、无限次地移动，无需额外花费。
# 您的飞船初始位于星系
# S_start，目标是抵达星系
# S_dest，并且飞船的总备用能量为
# E_total。您需要计算出从
# S_start
# 到
# S_dest
# 所需的最小总能量消耗。一次旅行可能需要穿越多个虫洞网络，当您从一个网络
# W_i
# 前往另一个网络
# W_j
# 时，您必须先通过一个共同的“中转星系” s_transfer（即
# s_transfer∈W_i∩W_j），然后支付网络
# W_j
# 的跃迁成本
# C_j。
# 如果无法抵达目标星系，或者最低能量消耗超出了您的总备用能量
# E_total，则视为任务失败。
# 输入描述：
# 第一行包含四个整数：
# ：虫洞网络的总数量。( )
# ：起始星系的编号。( )
# ：目标星系的编号。(,)
# ：飞船的总备用能量。( )
#
# 接下来的
# 行，每行描述一个虫洞网络，格式如下：
#
#
# ：进入该网络的跃迁成本。( )
# ：该网络连接的星系数量。( )
# ：该网络中的星系编号。( )
# 输出描述：
# 输出一个整数，代表从
# 到
# 的最小能量消耗。
#
# 如果无法抵达或能量不足，则输出  。
# 示例1
# 输入例子：
# 1
# 45
# 103
# 383
# 1
# 9
# 45
# 103
# 182
# 198
# 244
# 306
# 416
# 460
# 490
# 输出例子：
# 1
# 示例2
# 输入例子：
# 4
# 14
# 19
# 99
# 8
# 5
# 11
# 13
# 22
# 24
# 44
# 1
# 1
# 18
# 3
# 1
# 22
# 6
# 7
# 2
# 12
# 14
# 17
# 30
# 36
# 39
# 输出例子：
# -1


import heapq


def solve():
    N, S, T, E_total = map(int, input().split())

    if S == T:
        print(0)
        return

    networks = []
    start_networks = []
    target_networks = []

    for i in range(N):
        line = list(map(int, input().split()))
        cost = line[0]
        count = line[1]
        galaxies = set(line[2:2 + count])
        networks.append((cost, galaxies))

        if S in galaxies:
            start_networks.append(i)
        if T in galaxies:
            target_networks.append(i)

    if not start_networks or not target_networks:
        print(-1)
        return

    # 检查同一网络
    for i in start_networks:
        if i in target_networks:
            if networks[i][0] <= E_total:
                print(networks[i][0])
            else:
                print(-1)
            return

    # Dijkstra with dynamic connectivity check
    dist = [float('inf')] * N
    pq = []

    for i in start_networks:
        dist[i] = networks[i][0]
        heapq.heappush(pq, (dist[i], i))

    while pq:
        d, u = heapq.heappop(pq)
        if d != dist[u]:
            continue

        if u in target_networks:
            print(d if d <= E_total else -1)
            return

        # Check all other networks
        for v in range(N):
            if v == u:
                continue
            # Check if networks u and v are connected (have common galaxy)
            if networks[u][1] & networks[v][1]:
                new_cost = d + networks[v][0]
                if new_cost < dist[v]:
                    dist[v] = new_cost
                    heapq.heappush(pq, (new_cost, v))

    print(-1)


solve()
