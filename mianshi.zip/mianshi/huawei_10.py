# K-Means算法
# 【场景】为了优化城市基站布局，需要把给定的基站坐标用 K-Means 聚成 k 组，并用轮廓系数评估每个簇的好坏。我们把“平均轮廓系数最低”的簇视为覆盖质量最差的簇，计划在该簇“质心位置”新增一座基站。
# 请你输出这座新基站的坐标（四舍五入到两位小数，采用银行家舍入）。
# 【任务】
# * 使用前 k 个点作为初始中心执行 K-Means。
# * 轮廓系数定义：对样本 p，a(p) 是其与本簇其他样本的平均距离；b(p) 是其与“其他各簇”样本平均距离中的最小值；s(p)=(b(p)-a(p))/max(a(p), b(p))。若样本所在簇大小≤1，则该样本 s(p)=0。
# * 簇的得分为簇内样本 s(p) 的平均值。得分越低表示越差。
# * 输出平均轮廓系数最低簇的“质心”（各坐标均值）。
# 输入描述：
# 第一行：n k（n 为点数，k 为簇数）
# 接下来 n 行：每行两个整数 x y，表示一个基站的平面坐标
# 取值范围：1 ≤ n ≤ 500，1 ≤ k ≤ 120，0 ≤ x ≤ 5000，0 ≤ y ≤ 3000
# 输出描述：
# 一行：新增基站坐标，格式为 x,y（保留两位小数）
# 示例1
# 输入例子：
# 6 2
# 0 0
# 0 1
# 5 0
# 10 10
# 10 11
# 11 10
# 输出例子：
# 1.67,0.33
# 例子说明：
# 初始中心为(0,0)、(0,1)。K-Means 收敛后，簇A≈{(0,0),(0,1),(5,0)}，质心≈(1.666...,0.333...)；
# 簇B≈{(10,10),(10,11),(11,10)}，质心≈(10.333...,10.333...)。
# 簇A分散、与簇B距离也不算远，平均轮廓系数更低，因此选择簇A，其质心四舍五入（银行家舍入）为1.67,0.33。

import math
import sys


def main():
    data = sys.stdin.read().splitlines()
    if not data:
        return

    n, k = map(int, data[0].split())
    points = []
    for i in range(1, 1 + n):
        x, y = map(int, data[i].split())
        points.append((x, y))

    if k > n:
        k = n

    centroids = points[:k]
    cluster_assignment = [-1] * n
    changed = True
    max_iter = 100
    iter_count = 0

    while changed and iter_count < max_iter:
        iter_count += 1
        changed = False

        for i in range(n):
            p = points[i]
            min_dist_sq = float('inf')
            best_cluster = -1
            for c_idx, c in enumerate(centroids):
                dx = p[0] - c[0]
                dy = p[1] - c[1]
                dist_sq = dx * dx + dy * dy
                if dist_sq < min_dist_sq:
                    min_dist_sq = dist_sq
                    best_cluster = c_idx
            if cluster_assignment[i] != best_cluster:
                changed = True
                cluster_assignment[i] = best_cluster

        if not changed:
            break

        clusters = [[] for _ in range(k)]
        for i in range(n):
            c_idx = cluster_assignment[i]
            clusters[c_idx].append(points[i])

        new_centroids = []
        for j in range(k):
            if len(clusters[j]) == 0:
                c = centroids[j]
                max_dist_sq = -1
                farthest_point = None
                for p in points:
                    dx = p[0] - c[0]
                    dy = p[1] - c[1]
                    dist_sq = dx * dx + dy * dy
                    if dist_sq > max_dist_sq:
                        max_dist_sq = dist_sq
                        farthest_point = p
                new_centroids.append(farthest_point)
            else:
                sum_x = 0.0
                sum_y = 0.0
                for (x, y) in clusters[j]:
                    sum_x += x
                    sum_y += y
                mean_x = sum_x / len(clusters[j])
                mean_y = sum_y / len(clusters[j])
                new_centroids.append((mean_x, mean_y))

        centroids = new_centroids

    clusters = [[] for _ in range(k)]
    for i in range(n):
        c_idx = cluster_assignment[i]
        clusters[c_idx].append(points[i])

    n_points = len(points)
    dist_matrix = [[0.0] * n_points for _ in range(n_points)]
    for i in range(n_points):
        for j in range(n_points):
            if i == j:
                dist_matrix[i][j] = 0.0
            else:
                dx = points[i][0] - points[j][0]
                dy = points[i][1] - points[j][1]
                dist_matrix[i][j] = math.sqrt(dx * dx + dy * dy)

    s_values = [0.0] * n_points
    for i in range(n_points):
        cluster_i = cluster_assignment[i]
        cluster_points = clusters[cluster_i]
        size_i = len(cluster_points)
        if size_i <= 1:
            s_values[i] = 0.0
            continue

        sum_dist_same = 0.0
        count_same = 0
        for j in range(n_points):
            if cluster_assignment[j] == cluster_i and j != i:
                sum_dist_same += dist_matrix[i][j]
                count_same += 1
        a_p = sum_dist_same / count_same

        other_cluster_avgs = []
        for c in range(k):
            if c == cluster_i or len(clusters[c]) == 0:
                continue
            sum_dist_other = 0.0
            count_other = 0
            for j in range(n_points):
                if cluster_assignment[j] == c:
                    sum_dist_other += dist_matrix[i][j]
                    count_other += 1
            avg_dist = sum_dist_other / count_other
            other_cluster_avgs.append(avg_dist)

        if not other_cluster_avgs:
            b_p = a_p
        else:
            b_p = min(other_cluster_avgs)

        if max(a_p, b_p) == 0:
            s_p = 0.0
        else:
            s_p = (b_p - a_p) / max(a_p, b_p)
        s_values[i] = s_p

    cluster_scores = [0.0] * k
    cluster_sizes = [0] * k
    for i in range(n_points):
        c_idx = cluster_assignment[i]
        cluster_scores[c_idx] += s_values[i]
        cluster_sizes[c_idx] += 1

    for j in range(k):
        if cluster_sizes[j] > 0:
            cluster_scores[j] /= cluster_sizes[j]
        else:
            cluster_scores[j] = 0.0

    min_score = float('inf')
    worst_cluster = -1
    for j in range(k):
        if cluster_scores[j] < min_score:
            min_score = cluster_scores[j]
            worst_cluster = j

    if len(clusters[worst_cluster]) == 0:
        cx, cy = centroids[worst_cluster]
    else:
        sum_x = 0.0
        sum_y = 0.0
        for (x, y) in clusters[worst_cluster]:
            sum_x += x
            sum_y += y
        cx = sum_x / len(clusters[worst_cluster])
        cy = sum_y / len(clusters[worst_cluster])

    cx_rounded = round(cx, 2)
    cy_rounded = round(cy, 2)
    print(f"{cx_rounded:.2f},{cy_rounded:.2f}")


if __name__ == "__main__":
    main()
