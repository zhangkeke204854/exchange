# 设备故障预测程序
# 在一套对象存储集群中，运维同学希望根据设备运行日志，提前判断设备是否有故障风险，从而把数据在故障前迁移到其他节点。
# 每条日志包含以下字段：设备ID、写入次数、读取次数、平均写入延迟(ms)、平均读取延迟(ms)、使用年限(年)、设备状态(0 正常/1 故障)。
#
# 请你实现一个设备故障预测程序，基于训练数据学习一个逻辑回归模型，并对给定的待预测设备输出是否故障的判定结果。
#
#
# 数据清洗规则
# - 缺失值填充：数值字段出现字符串 NaN 时，用该字段在训练集中“有效数值”的均值进行填充。有效数值的含义见“异常值处理”。
#
# - 异常值处理：若出现以下越界值，则视为异常，用该字段在训练集“有效数值”的中位数替换。
# 1.写入/读取次数：小于 0
# 2.平均写入/读取延迟：小于 0 或 大于 1000
# 3.使用年限：小于 0 或 大于 20
#
# - 说明：计算均值/中位数时，只统计训练集中“有效数值”（即不含 NaN，且不越界）。若某字段在训练集没有任何有效数值，则该字段的均值与中位数都按 0 处理。
# - 标签缺失：训练样本若无状态字段或无法解析为 0/1，丢弃该行，不参与训练，也不参与统计均值/中位数。
#
# 模型与训练
# - 模型：二分类逻辑回归，带偏置项 w0。
# - 训练方法：批量梯度下降（Batch GD），每次迭代用全部训练样本，学习率 0.01，迭代 100 次，初始权重全 0。
# - 概率：
#
# - 判定阈值：若 P(y=1) ≥ 0.5 则输出 1，否则输出 0。
# 时间限制：C/C++ 1秒，其他语言2秒
# 空间限制：C/C++ 256M，其他语言512M
# 输入描述：
# 第一行：N（2 ≤ N ≤ 100）
# 接下来 N 行：每行一个训练样本
# device_id,writes,reads,avg_write_ms,avg_read_ms,years,status
# 第 N+1 行：M（1 ≤ M ≤ 10）
# 接下来 M 行：每行一个待预测样本（无状态）
# device_id,writes,reads,avg_write_ms,avg_read_ms,years
# 输出描述：
# 共 M 行，每行输出一个整数 0 或 1，对应各待预测设备是否判定为故障。
#
# 示例1
# 输入例子：
# 12
# n1,50,25,5,2,1,0
# n2,55,27,5.5,2.5,1.2,0
# n3,60,30,6,3,1.5,0
# n4,65,32,6.5,3.2,1.8,0
# n5,70,35,7,3.5,2,0
# n6,75,37,7.5,3.8,2.2,0
# n7,80,40,8,4,2.5,0
# n8,85,42,8.5,4.2,2.7,0
# n9,90,45,9,4.5,3,0
# n10,95,47,9.5,4.8,3.2,0
# p1,400,200,20,10,6,1
# p2,500,250,22,11,8,1
# 2
# q1,88,44,8.8,4.3,2.9
# q2,480,240,21.5,10.8,7.5
# 输出例子：
# 0
# 1
# 例子说明：
# 训练集中负类远多于正类，模型学到明显负偏置；但正类样本特征显著更大，使对应权重为正。
# q1落在负类量级附近，P<0.5 → 0；q2与正类量级接近，P≥0.5 → 1。


import math
import sys


def is_outlier(feature_idx, value):
    """检查给定特征值是否越界"""
    if feature_idx in [0, 1]:  # writes, reads
        return value < 0
    elif feature_idx in [2, 3]:  # avg_write_ms, avg_read_ms
        return value < 0 or value > 1000
    elif feature_idx == 4:  # years
        return value < 0 or value > 20
    return False


def sigmoid(x):
    """Sigmoid函数"""
    if x >= 0:
        return 1.0 / (1.0 + math.exp(-x))
    else:
        return math.exp(x) / (1.0 + math.exp(x))


def main():
    data = sys.stdin.read().splitlines()
    if not data:
        return

    # 解析训练数据
    n = int(data[0])
    train_lines = data[1:1 + n]

    # 初始化有效数值存储
    valid_values = [[] for _ in range(5)]  # 5个特征
    raw_samples = []  # 存储原始样本（特征值列表和标签）

    # 第一遍：收集有效数值并解析样本
    for line in train_lines:
        parts = line.split(',')
        if len(parts) < 7:
            continue

        # 解析标签
        try:
            status = int(parts[6].strip())
            if status not in [0, 1]:
                continue
        except:
            continue

        # 解析特征
        feat_vals = []
        for i in range(1, 6):  # 特征在1-5列
            s = parts[i].strip()
            try:
                val = float(s)
                # 检查是否越界
                if is_outlier(i - 1, val):
                    feat_vals.append(val)  # 记录原始值（稍后替换）
                else:
                    feat_vals.append(val)
                    valid_values[i - 1].append(val)  # 加入有效数值
            except:
                feat_vals.append(None)  # 标记为缺失

        raw_samples.append((feat_vals, status))

    # 计算每个特征的均值和中位数
    means = []
    medians = []
    for i in range(5):
        arr = valid_values[i]
        if not arr:
            means.append(0.0)
            medians.append(0.0)
        else:
            means.append(sum(arr) / len(arr))
            sorted_arr = sorted(arr)
            n_val = len(sorted_arr)
            if n_val % 2 == 1:
                medians.append(sorted_arr[n_val // 2])
            else:
                medians.append((sorted_arr[n_val // 2 - 1] + sorted_arr[n_val // 2]) / 2)

    # 第二遍：清洗训练数据
    X_train = []
    y_train = []
    for feat_vals, status in raw_samples:
        cleaned = []
        for i in range(5):
            val = feat_vals[i]
            if val is None:  # 缺失值
                cleaned.append(means[i])
            elif is_outlier(i, val):  # 越界值
                cleaned.append(medians[i])
            else:
                cleaned.append(val)
        X_train.append(cleaned)
        y_train.append(status)

    # 添加偏置项
    X_train_bias = [[1.0] + x for x in X_train]

    # 训练逻辑回归模型
    n_samples = len(y_train)
    n_features = len(X_train_bias[0])
    w = [0.0] * n_features  # 初始权重全0

    # 批量梯度下降
    learning_rate = 0.01
    n_iters = 100

    for _ in range(n_iters):
        # 计算预测概率
        probs = []
        for x in X_train_bias:
            z = sum(w_i * x_i for w_i, x_i in zip(w, x))
            probs.append(sigmoid(z))

        # 计算梯度
        grad = [0.0] * n_features
        for j in range(n_features):
            g = 0.0
            for i in range(n_samples):
                g += (probs[i] - y_train[i]) * X_train_bias[i][j]
            grad[j] = g / n_samples

        # 更新权重
        for j in range(n_features):
            w[j] -= learning_rate * grad[j]

    # 处理预测数据
    m = int(data[1 + n])
    test_lines = data[2 + n:2 + n + m]

    for line in test_lines:
        parts = line.split(',')
        if len(parts) < 6:
            print(0)  # 格式错误默认输出0
            continue

        # 解析特征
        feat_vals = []
        for i in range(1, 6):  # 特征在1-5列
            s = parts[i].strip()
            try:
                val = float(s)
                if is_outlier(i - 1, val):
                    feat_vals.append(medians[i - 1])
                else:
                    feat_vals.append(val)
            except:
                feat_vals.append(means[i - 1])  # 缺失值用均值填充

        # 添加偏置项并预测
        x_test = [1.0] + feat_vals
        z = sum(w_i * x_i for w_i, x_i in zip(w, x_test))
        prob = sigmoid(z)
        result = 1 if prob >= 0.5 else 0
        print(result)


if __name__ == "__main__":
    main()
