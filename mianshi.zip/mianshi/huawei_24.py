# 魔法信标网络
# 在一个古老的王国中，为了抵御来自暗影裂隙的侵蚀，魔法师们沿边境线建立了一排共 n 座哨兵塔。每座哨兵塔都配备有一定数量的“以太信标”，用于维持一个覆盖全境的魔法屏障。
# 我们用一个下标从 0 开始的整数数组 T 来表示这排哨兵塔，其中 T[i] 代表第 i 座哨兵塔当前已激活的以太信标数量。
# 每一个位于哨兵塔 i 的信标，都能投射出半径为 ρ 的保护辉光，为所有满足距离条件 ∣i-j∣≤ρ 的哨兵塔 j 贡献一份屏障能量。一座哨兵塔 j 的“屏障强度” S_j 定义为所有能覆盖到它的以太信标的总数。
# 现在，皇家魔法议会批准了一项紧急增援计划，允许你额外部署 κ 个新的以太信标。这些信标可以被自由地分配到任意一座或多座哨兵塔中（即，同一座哨兵塔可以增设多个信标）。
# 你的任务是，作为王国的首席战略家，设计一个最优的信标部署方案，使得所有哨兵塔中**最低的屏障强度**能够被**最大化**。你需要返回这个可以达到的、最大化的最低屏障强度值。
#
# 输入描述：
# 输入包含四行：
# 1.  第一行是一个整数ρ，代表信标的保护辉光半径。
# 2.  第二行是一个整数κ，代表可供部署的新信标总数。
# 3.  第三行是一个整数n，代表哨兵塔的总数。
# 4.  第四行是 n 个用空格分隔的整数，代表数组T，即每座哨兵塔初始的信标数量。
#
# 数据范围约束：
# 0<=ρ<= n
# 0<=κ<=10**9
# 0<=n<=10**5
# 0<=T[i]<=10**5
# 输出描述：
# 返回一个整数，该整数代表在最优部署方案下，整个哨兵塔网络中最低屏障强度的最大可能值。
# 示例1
# 输入例子：
# 19
# 100
# 20
# 10 2 5 8 12 1 1 20 4 3 15 6 9 7 11 18 13 14 17 16
# 输出例子：
# 292

def solve():
    r = int(input())
    k = int(input())
    n = int(input())
    A = list(map(int, input().split()))

    # 特殊情况：r >= n-1，所有信标覆盖全部
    if r >= n - 1:
        return sum(A) + k

    # 计算初始屏障强度S
    S = [0] * n
    window_sum = 0
    left = 0

    for right in range(n):
        window_sum += A[right]
        while left < right - 2 * r:
            window_sum -= A[left]
            left += 1

        # S[i] 应该是覆盖i的所有A[j]之和，其中|i-j| <= r
        # 重新计算更准确
    S = [0] * n
    for i in range(n):
        total = 0
        for j in range(max(0, i - r), min(n, i + r + 1)):
            total += A[j]
        S[i] = total

    def can_achieve(target):
        # 使用差分数组模拟
        diff = [0] * (n + 1)
        current_add = 0
        used = 0

        for i in range(n):
            current_add += diff[i]
            current_strength = S[i] + current_add

            if current_strength < target:
                need = target - current_strength
                used += need
                if used > k:
                    return False

                # 在最远能影响i的位置放置信标：pos = min(i + r, n-1)
                pos = min(i + r, n - 1)
                # 这个信标影响范围 [pos-r, pos+r]
                l = max(0, pos - r)
                r_bound = min(n - 1, pos + r)

                current_add += need
                if r_bound + 1 < n:
                    diff[r_bound + 1] -= need

        return True

    # 二分搜索
    left, right = min(S), min(S) + k + max(S)
    result = left

    while left <= right:
        mid = (left + right) // 2
        if can_achieve(mid):
            result = mid
            left = mid + 1
        else:
            right = mid - 1

    return result


print(solve())

