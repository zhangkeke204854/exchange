# 实现Masked Multi-Head Self-Attention
# 给定批量序列表示 X（形状：[batch, seq, d_model]）与权重矩阵 W_Q、W_K、W_V、W_O（均为 d_model×d_model），实现 Masked Multi-Head Self-Attention。
# 将最后一维按头数 num_heads 均分，每头维度 d_k = d_model / num_heads。  
# 计算步骤：  
#   1) Q = X @ W_Q，K = X @ W_K，V = X @ W_V。  
#   2) 将 Q、K、V reshape 为 [batch, num_heads, seq, d_k]。  
#   3) 计算注意力分数 scores = (Q @ K^T) / sqrt(d_k)，其中 K^T 表示每头在最后两维做转置得到 [batch, num_heads, seq, seq]。  
#   4) 使用下三角因果掩码（只能看见当前及更早位置）：掩掉上三角元素（置为一个很小的负数）。  
#   5) 在最后一维做 softmax 得到权重，注意数值稳定性（减去每行最大值再做 exp）。  
#   6) attention = softmax @ V（形状 [batch, num_heads, seq, d_k]）。  
#   7) 拼回 [batch, seq, d_model] 后，再右乘 W_O。  
# 输出保留两位小数，结果需转换为 Python List。
# 输入描述：
# 以分号分隔的 6 个参数：num_heads; X; W_Q; W_K; W_V; W_O  
# 其中 X、W_Q、W_K、W_V、W_O 用 Python 风格的嵌套列表表示。
# 输出描述：
# 最终输出张量（形状 [batch, seq, d_model]），四舍五入到小数点后两位，类型为 List。

# 输入例子：
# 2; [[[1, 1], [1, 1], [1, 1]]]; [[1, 0], [0, 1]]; [[1, 0], [0, 1]]; [[1, 0], [0, 1]]; [[1, 0], [0, 1]]
# 输出例子：
# [[[1.00, 1.00], [1.00, 1.00], [1.00, 1.00]]]
# 例子说明：
# 权重为单位矩阵，Q=K=V=X。因果掩码使第 i 个位置只看见前 i+1 个位置；由于各位置完全相同，softmax 权重在可见范围内均匀分布，输出与输入一致；乘 W_O（单位）后不变。

import numpy as np


def masked_multi_head_attention(params):
    # 解析输入参数
    parts = params.split(';')
    num_heads = int(parts[0].strip())
    X = eval(parts[1].strip())
    W_Q = eval(parts[2].strip())
    W_K = eval(parts[3].strip())
    W_V = eval(parts[4].strip())
    W_O = eval(parts[5].strip())

    # 转换为numpy数组
    X = np.array(X, dtype=np.float32)
    W_Q = np.array(W_Q, dtype=np.float32)
    W_K = np.array(W_K, dtype=np.float32)
    W_V = np.array(W_V, dtype=np.float32)
    W_O = np.array(W_O, dtype=np.float32)

    # 获取维度信息
    batch, seq, d_model = X.shape
    d_k = d_model // num_heads

    # 步骤1: 计算Q, K, V
    Q = np.matmul(X, W_Q)  # [batch, seq, d_model]
    K = np.matmul(X, W_K)  # [batch, seq, d_model]
    V = np.matmul(X, W_V)  # [batch, seq, d_model]

    # 步骤2: 重塑为多头格式
    Q = Q.reshape(batch, seq, num_heads, d_k).transpose(0, 2, 1, 3)  # [batch, num_heads, seq, d_k]
    K = K.reshape(batch, seq, num_heads, d_k).transpose(0, 2, 1, 3)  # [batch, num_heads, seq, d_k]
    V = V.reshape(batch, seq, num_heads, d_k).transpose(0, 2, 1, 3)  # [batch, num_heads, seq, d_k]

    # 步骤3: 计算注意力分数
    K_T = K.transpose(0, 1, 3, 2)  # [batch, num_heads, d_k, seq]
    scores = np.matmul(Q, K_T) / np.sqrt(d_k)  # [batch, num_heads, seq, seq]

    # 步骤4: 应用因果掩码
    mask = np.tril(np.ones((seq, seq)), k=0)  # 创建下三角掩码
    mask = np.where(mask == 0, -1e9, 0)  # 上三角置为极小值
    scores = scores + mask  # 应用掩码

    # 步骤5: 计算softmax（数值稳定版）
    max_vals = np.max(scores, axis=-1, keepdims=True)
    exp_scores = np.exp(scores - max_vals)
    sum_exp = np.sum(exp_scores, axis=-1, keepdims=True)
    softmax_scores = exp_scores / sum_exp

    # 步骤6: 计算注意力输出
    attention = np.matmul(softmax_scores, V)  # [batch, num_heads, seq, d_k]

    # 步骤7: 拼接多头输出
    attention = attention.transpose(0, 2, 1, 3)  # [batch, seq, num_heads, d_k]
    attention = attention.reshape(batch, seq, d_model)  # [batch, seq, d_model]

    # 应用输出权重
    output = np.matmul(attention, W_O)  # [batch, seq, d_model]

    # 四舍五入到两位小数并转换为Python列表
    output_rounded = np.round(output, 2)
    return output_rounded.tolist()


# 示例使用
if __name__ == "__main__":
    # 示例输入（根据实际输入格式调整）
    # input_str = "2; [[[1,2,3,4],[5,6,7,8]],[[9,10,11,12],[13,14,15,16]]]; [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]; [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]; [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]; [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]"
    input_str = '2; [[[1, 1], [1, 1], [1, 1]]]; [[1, 0], [0, 1]]; [[1, 0], [0, 1]]; [[1, 0], [0, 1]]; [[1, 0], [0, 1]]'
    result = masked_multi_head_attention(input_str)
    print(result)
