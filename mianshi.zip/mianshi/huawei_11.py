# ID3决策树训练
# 在运维中心收集到的一批样本中，每条样本包含 m 个二值特征与一个二分类标签（0=正常，1=劣化）。请基于 ID3 决策树训练一个二叉分类器，并对 q 条查询样本给出预测结果。
# 规则与细节
# * 划分准则：信息增益（Entropy + Information Gain）。在当前节点，从“尚未使用”的特征中选择信息增益最大的进行二分。
# * 并列处理：若多个特征增益相同，选择“特征下标更小”的那个。
# * 终止与叶子：
#     * 若当前样本标签全同，直接返回该标签；
#     * 若没有任何特征能带来正的增益（或特征已经用尽），返回“多数标签”；若平票，返回 0。
#     * 为保证可预测性，某次划分若一侧样本为空，该子结点直接作为“多数标签叶子”（平票仍为 0）。
# * 预测：从根出发，按节点记录的特征下标读取 0/1 向左/向右，直到叶子。
#
# 输入描述：
# 第一行：n m
# 接下来 n 行：每行 m+1 个整数，前 m 个为特征值（0/1），最后 1 个为标签（0/1）
# 下一行：q
# 接下来 q 行：每行 m 个整数，表示待预测样本的特征（0/1）
# 输出描述：
# 共 q 行，每行 1 个整数（0 或 1），为对应查询样本的预测值
# 示例1
# 输入例子：
# 6 2
# 0 0 0
# 0 1 0
# 1 0 1
# 1 1 1
# 0 0 0
# 1 1 1
# 3
# 0 1
# 1 0
# 1 1
# 输出例子：
# 0
# 1
# 1
# 例子说明：
# 在根节点，按信息增益选择特征1（与特征2并列时，因下标更小而被选中）；左支（特征1=0）标签几乎全为 0，右支（特征1=1）标签几乎全为 1；因此三个查询分别预测为 0、1、1。


import math
import sys


class Node:
    def __init__(self, feature_index=None, label=None):
        self.feature_index = feature_index  # 内部节点使用的特征索引
        self.label = label  # 叶子节点的预测标签
        self.left = None  # 特征值=0的分支
        self.right = None  # 特征值=1的分支


def entropy(labels):
    """计算标签列表的熵"""
    n = len(labels)
    if n == 0:
        return 0.0

    count0 = labels.count(0)
    count1 = n - count0
    p0 = count0 / n
    p1 = count1 / n

    ent = 0.0
    if p0 > 0:
        ent -= p0 * math.log2(p0)
    if p1 > 0:
        ent -= p1 * math.log2(p1)
    return ent


def information_gain(samples, feature_index):
    """计算使用指定特征划分的信息增益"""
    labels = [s[-1] for s in samples]
    total_entropy = entropy(labels)
    n = len(samples)

    # 按特征值划分样本
    left_samples = []  # 特征值=0
    right_samples = []  # 特征值=1
    for s in samples:
        if s[feature_index] == 0:
            left_samples.append(s)
        else:
            right_samples.append(s)

    # 计算加权条件熵
    left_entropy = entropy([s[-1] for s in left_samples])
    right_entropy = entropy([s[-1] for s in right_samples])
    cond_entropy = (len(left_samples) / n) * left_entropy + (len(right_samples) / n) * right_entropy

    return total_entropy - cond_entropy


def majority_label(labels):
    """返回多数标签，平票时返回0"""
    count0 = labels.count(0)
    count1 = len(labels) - count0
    return 0 if count0 >= count1 else 1


def build_tree(samples, features):
    """递归构建决策树"""
    # 获取当前节点的所有标签
    labels = [s[-1] for s in samples]

    # 终止条件1：所有样本标签相同
    if all(l == 0 for l in labels):
        return Node(label=0)
    if all(l == 1 for l in labels):
        return Node(label=1)

    # 终止条件2：没有可用特征
    if not features:
        return Node(label=majority_label(labels))

    # 计算每个特征的信息增益
    best_gain = -1
    best_feature = None
    for f in features:
        gain = information_gain(samples, f)
        if gain > best_gain or (gain == best_gain and f < best_feature):
            best_gain = gain
            best_feature = f

    # 终止条件3：没有正增益的特征
    if best_gain <= 0:
        return Node(label=majority_label(labels))

    # 根据最佳特征划分样本
    left_samples = []
    right_samples = []
    for s in samples:
        if s[best_feature] == 0:
            left_samples.append(s)
        else:
            right_samples.append(s)

    # 创建当前节点
    node = Node(feature_index=best_feature)

    # 更新可用特征（移除已用特征）
    new_features = [f for f in features if f != best_feature]

    # 递归构建子树（处理空分支情况）
    if not left_samples:
        node.left = Node(label=majority_label(labels))
    else:
        node.left = build_tree(left_samples, new_features)

    if not right_samples:
        node.right = Node(label=majority_label(labels))
    else:
        node.right = build_tree(right_samples, new_features)

    return node


def predict(tree, sample):
    """使用决策树预测样本标签"""
    if tree.label is not None:
        return tree.label

    if sample[tree.feature_index] == 0:
        return predict(tree.left, sample)
    else:
        return predict(tree.right, sample)


def main():
    data = sys.stdin.read().splitlines()
    if not data:
        return

    # 解析输入数据
    n, m = map(int, data[0].split())
    samples = []
    for i in range(1, 1 + n):
        samples.append(list(map(int, data[i].split())))

    q = int(data[1 + n])
    queries = []
    for i in range(2 + n, 2 + n + q):
        queries.append(list(map(int, data[i].split())))

    # 构建决策树
    features = list(range(m))  # 可用特征索引
    tree = build_tree(samples, features)

    # 预测查询样本
    for query in queries:
        print(predict(tree, query))


if __name__ == "__main__":
    main()
