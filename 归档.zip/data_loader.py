"""
数据加载模块
负责读取Word文档、Excel文件,并转换为JSON格式供Agent使用
"""
import json
import os
from typing import Dict, Any, Optional
import pandas as pd
from docx import Document


def load_config(config_path: str = "futures_config.json") -> Dict[str, Any]:
    """加载配置文件"""
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"配置文件 {config_path} 不存在,使用默认配置")
        return {
            "current_product": "螺纹钢",
            "products": {
                "螺纹钢": {
                    "name": "螺纹钢",
                    "contract_code": "RB2505",
                    "model_doc": "全息模型维度.docx",
                    "industry_doc": "螺纹钢产业模型.docx",
                    "data_file": "螺纹钢生产及期货价格情况.xlsx"
                }
            }
        }


def read_docx(file_path: str) -> Dict[str, Any]:
    """
    读取Word文档并提取内容
    返回包含段落和表格的结构化数据
    """
    if not os.path.exists(file_path):
        print(f"文档文件 {file_path} 不存在")
        return {"paragraphs": [], "tables": [], "error": f"文件不存在: {file_path}"}
    
    try:
        doc = Document(file_path)
        
        # 提取段落
        paragraphs = []
        for para in doc.paragraphs:
            text = para.text.strip()
            if text:  # 只保留非空段落
                paragraphs.append({
                    "text": text,
                    "style": para.style.name if para.style else "Normal"
                })
        
        # 提取表格
        tables = []
        for table in doc.tables:
            table_data = []
            for row in table.rows:
                row_data = [cell.text.strip() for cell in row.cells]
                table_data.append(row_data)
            tables.append(table_data)
        
        return {
            "file_name": os.path.basename(file_path),
            "paragraphs": paragraphs,
            "tables": tables,
            "total_paragraphs": len(paragraphs),
            "total_tables": len(tables)
        }
    except Exception as e:
        print(f"读取文档 {file_path} 时出错: {e}")
        return {"paragraphs": [], "tables": [], "error": str(e)}


def read_excel(file_path: str) -> Dict[str, Any]:
    """
    读取Excel文件并转换为JSON格式
    max_rows: 最多读取的行数,避免数据过大
    """
    if not os.path.exists(file_path):
        print(f"Excel文件 {file_path} 不存在")
        return {"sheets": {}, "error": f"文件不存在: {file_path}"}
    
    try:
        # 读取所有工作表
        sheets_data = {}

        df = pd.read_excel(file_path)
        df = df.fillna("")
        df_str = df.to_string(index=False)
        
        for sheet_name in excel_file.sheet_names:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            
            # 转换为字典格式,处理NaN值
            df_dict = df.fillna("").to_dict(orient='records')
            
            # 获取基本统计信息
            stats = {
                "row_count": len(df),
                "column_count": len(df.columns),
                "columns": list(df.columns)
            }
            
            # 对数值列计算统计信息
            numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
            if numeric_cols:
                stats["numeric_summary"] = df[numeric_cols].describe().to_dict()
            
            sheets_data[sheet_name] = {
                "data": df_dict[:100],  # 只保留前100行到JSON,避免过大
                "stats": stats,
                "total_rows": len(df)
            }
        
        return {
            "file_name": os.path.basename(file_path),
            "sheets": sheets_data,
            "sheet_names": excel_file.sheet_names
        }
    except Exception as e:
        print(f"读取Excel {file_path} 时出错: {e}")
        return {"sheets": {}, "error": str(e)}


def load_all_data(product_name: Optional[str] = None) -> Dict[str, Any]:
    """
    加载指定品种的所有数据
    包括: 配置、全息模型、产业模型、历史数据
    """
    # 加载配置
    config = load_config()
    
    # 确定要加载的品种
    if product_name is None:
        product_name = config.get("current_product", "螺纹钢")
    
    product_config = config.get("products", {}).get(product_name)
    if not product_config:
        return {
            "error": f"未找到品种 {product_name} 的配置",
            "available_products": list(config.get("products", {}).keys())
        }
    
    # 加载各类数据
    result = {
        "product_name": product_name,
        "product_config": product_config,
        "model_doc": None,
        "industry_doc": None,
        "historical_data": None
    }
    
    # 读取全息模型文档
    model_doc_path = product_config.get("model_doc")
    if model_doc_path and os.path.exists(model_doc_path):
        result["model_doc"] = read_docx(model_doc_path)
    
    # 读取产业模型文档
    industry_doc_path = product_config.get("industry_doc")
    if industry_doc_path and os.path.exists(industry_doc_path):
        result["industry_doc"] = read_docx(industry_doc_path)
    
    # 读取历史数据Excel
    data_file_path = product_config.get("data_file")
    if data_file_path and os.path.exists(data_file_path):
        result["historical_data"] = read_excel(data_file_path)
    
    return result


def format_data_for_prompt(data: Dict[str, Any], max_length: int = 10000) -> str:
    """
    将数据格式化为适合放入prompt的字符串
    max_length: 最大字符数,避免prompt过长
    """
    sections = []
    
    # 产品信息
    if "product_name" in data:
        sections.append(f"## 分析品种: {data['product_name']}")
        if "product_config" in data:
            sections.append(f"合约代码: {data['product_config'].get('contract_code', 'N/A')}")
            sections.append(f"交易所: {data['product_config'].get('exchange', 'N/A')}")
    
    # 全息模型维度
    if data.get("model_doc") and "paragraphs" in data["model_doc"]:
        sections.append("\n## 全息模型维度")
        for para in data["model_doc"]["paragraphs"][:20]:  # 限制段落数
            sections.append(para["text"])
    
    # 产业模型
    if data.get("industry_doc") and "paragraphs" in data["industry_doc"]:
        sections.append("\n## 产业模型分析")
        for para in data["industry_doc"]["paragraphs"][:20]:
            sections.append(para["text"])
    
    # 历史数据摘要
    if data.get("historical_data") and "sheets" in data["historical_data"]:
        sections.append("\n## 历史数据摘要")
        for sheet_name, sheet_data in data["historical_data"]["sheets"].items():
            sections.append(f"\n### {sheet_name}")
            if "stats" in sheet_data:
                stats = sheet_data["stats"]
                sections.append(f"数据行数: {stats.get('row_count', 0)}")
                sections.append(f"数据列: {', '.join(stats.get('columns', []))}")
    
    # 组合并截断
    full_text = "\n".join(sections)
    if len(full_text) > max_length:
        full_text = full_text[:max_length] + "\n...(数据已截断)"
    
    return full_text


if __name__ == "__main__":
    # 测试数据加载
    print("正在加载数据...")
    data = load_all_data("螺纹钢")
    
    # 简化输出,避免JSON序列化问题
    print(f"\n加载结果:")
    print(f"- 品种: {data.get('product_name')}")
    print(f"- 合约代码: {data.get('product_config', {}).get('contract_code')}")
    if data.get('model_doc'):
        print(f"- 全息模型段落数: {data['model_doc'].get('total_paragraphs', 0)}")
    if data.get('industry_doc'):
        print(f"- 产业模型段落数: {data['industry_doc'].get('total_paragraphs', 0)}")
    if data.get('historical_data'):
        print(f"- 历史数据工作表: {data['historical_data'].get('sheet_names', [])}")
    
    print("\n格式化后的prompt数据(前500字符):")
    prompt_data = format_data_for_prompt(data)
    print(prompt_data[:500])
