"""
测试期货分析系统的各个模块
"""
import sys

print("=" * 60)
print("期货分析系统模块测试")
print("=" * 60)

# 测试1: 数据加载模块
print("\n[测试1] 数据加载模块...")
try:
    from data_loader import load_config, load_all_data
    config = load_config()
    print(f"✅ 配置加载成功: 当前品种 = {config.get('current_product')}")
    
    data = load_all_data("螺纹钢")
    print(f"✅ 数据加载成功:")
    print(f"   - 品种: {data.get('product_name')}")
    print(f"   - 合约: {data.get('product_config', {}).get('contract_code')}")
    if data.get('model_doc'):
        print(f"   - 全息模型段落数: {data['model_doc'].get('total_paragraphs', 0)}")
    if data.get('industry_doc'):
        print(f"   - 产业模型段落数: {data['industry_doc'].get('total_paragraphs', 0)}")
except Exception as e:
    print(f"❌ 数据加载模块测试失败: {e}")
    sys.exit(1)

# 测试2: K线获取模块
print("\n[测试2] K线获取模块...")
try:
    from kline_fetcher import get_kline_fetcher
    fetcher = get_kline_fetcher(mode="mock")
    df = fetcher.get_kline_data("RB2505", bars=50)
    print(f"✅ K线获取成功: 获取到 {len(df)} 根K线")
    print(f"   - 最新价: {df.iloc[-1]['close']:.2f}")
    print(f"   - 日期: {df.iloc[-1]['datetime'].strftime('%Y-%m-%d')}")
except Exception as e:
    print(f"❌ K线获取模块测试失败: {e}")
    sys.exit(1)

# 测试3: 技术指标模块
print("\n[测试3] 技术指标模块...")
try:
    from technical_indicators import calculate_ma, calculate_rsi, calculate_macd
    
    # 准备测试数据
    close_prices = df['close'].tolist()
    
    # 测试MA
    ma_result = calculate_ma.invoke({"close_prices": close_prices, "period": 20})
    print(f"✅ MA指标计算成功: MA20 = {ma_result.get('current_ma')}")
    
    # 测试RSI
    rsi_result = calculate_rsi.invoke({"close_prices": close_prices, "period": 14})
    print(f"✅ RSI指标计算成功: RSI = {rsi_result.get('current_rsi')}, 状态 = {rsi_result.get('status')}")
    
    # 测试MACD
    macd_result = calculate_macd.invoke({"close_prices": close_prices})
    print(f"✅ MACD指标计算成功: 信号 = {macd_result.get('trade_signal')}")
    
except Exception as e:
    print(f"❌ 技术指标模块测试失败: {e}")
    sys.exit(1)

# 测试4: 主程序导入
print("\n[测试4] 主程序模块...")
try:
    from graph import build_system_prompt
    prompt = build_system_prompt("螺纹钢")
    print(f"✅ 系统提示词构建成功: 长度 = {len(prompt)} 字符")
except Exception as e:
    print(f"❌ 主程序模块测试失败: {e}")
    sys.exit(1)

print("\n" + "=" * 60)
print("✅ 所有模块测试通过!")
print("=" * 60)
print("\n系统已就绪,可以运行: python graph.py")
