import os
import datetime
import json
import requests
import pandas as pd
from typing import List, Dict, Any
from pathlib import Path
from dotenv import load_dotenv 
from langchain_deepseek import ChatDeepSeek
from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain.chat_models import init_chat_model
from langchain.agents import create_agent
from langchain_tavily import TavilySearch
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from langchain_core.documents import Document
from langchain_chroma import Chroma
from langchain_core.tools.retriever import create_retriever_tool
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
import openpyxl

# 加载环境变量
load_dotenv(override=True)

# 模型配置字典
MODEL_CONFIGS = {
    "qwen": {
        "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "api_key": 'sk-473528c9946246c9926cc677adf0fe09',
        "chat_model": "qwen-max",
        "embedding_model": "text-embedding-v1"
    }
}

llm_type = 'qwen'
config = MODEL_CONFIGS[llm_type]

llm_embedding = OpenAIEmbeddings(
    base_url=config["base_url"],
    api_key=config["api_key"],
    model=config["embedding_model"],
    deployment=config["embedding_model"],
    check_embedding_ctx_length=False
)

# 内置搜索工具
search_tool = TavilySearch(max_results=5, topic="general")

# 1030团队Outing知识库内容
OUTING_KNOWLEDGE = {
    "活动主题": "10月30日·周四 九溪十八涧团队outing",
    "活动时间": "2025年10月30日（周四）",
    "活动地点": "浙江省杭州市九溪十八涧景区",
    "集合信息": {
        "集合点": "杭州九溪公交站",
        "集合时间": "早上8:30",
        "联系人": "昕珵",
        "联系电话": "139-0000-1234"
    },
    "活动内容": "团队游戏、烧烤、徒步、晚会",
    "路线总览": "九溪公交站 → 九溪烟树 → 九溪十八涧 → 龙井村 → 十里琅珰 → 三分叉 → 真迹寺 → 云栖竹径 → 返回九溪公交站",
    "时间轴": [
        {"时间段": "08:30-09:00", "活动": "集合破冰", "地点": "九溪公交站"},
        {"时间段": "09:00-11:30", "活动": "徒步+定向任务", "地点": "九溪十八涧"},
        {"时间段": "11:30-13:30", "活动": "龙井村午餐+围炉煮茶", "地点": "茶人村餐厅"},
        {"时间段": "13:30-15:30", "活动": "十里琅珰轻徒步+飞盘", "地点": "茶园平台"},
        {"时间段": "15:30-17:30", "活动": "烧烤BBQ+晚会", "地点": "云栖竹径草坪营地"}
    ],
    "装备清单": {
        "服装": ["防滑运动鞋", "速干衣裤", "拒绝高跟鞋"],
        "防护": ["防晒霜", "驱蚊液", "雨衣"],
        "补给": ["1L水壶", "能量棒"],
        "团建道具": "公司统一发放飞盘、水枪、任务卡"
    },
    "费用说明": "公司承担，免费参加",
    "交通方式": "高铁自行前往，公司报销",
    "路线详情": {
        "总距离": "10km环线",
        "预计时间": "4-5小时",
        "难度": "零门槛轻徒步"
    },
    "注意事项": [
        "10月山区温差大，注意保暖",
        "穿防滑运动鞋，拒绝高跟鞋",
        "带好防晒和防蚊用品",
        "听从领队安排，注意安全"
    ]
}

# 时间查询工具
@tool
def get_current_time() -> str:
    """
    获取当前日期和时间
    :return: 当前时间的字符串表示
    """
    now = datetime.datetime.now()
    return now.strftime("当前时间：%Y年%m月%d日 %H:%M:%S %A")


# 计算器工具
class CalculatorInput(BaseModel):
    expression: str = Field(description="数学表达式，例如：2+3*4, (10+5)/3, sqrt(16)")

@tool(args_schema=CalculatorInput)
def calculate(expression: str) -> str:
    """
    计算数学表达式的结果
    :param expression: 数学表达式字符串
    :return: 计算结果
    """
    try:
        # 安全地计算数学表达式
        allowed_names = {
            "sqrt": lambda x: x**0.5,
            "abs": abs,
            "round": round,
            "min": min,
            "max": max
        }
        
        # 只允许数字和基本运算符
        result = eval(expression, {"__builtins__": {}}, allowed_names)
        return f"计算结果：{expression} = {result}"
    except Exception as e:
        return f"计算错误：{str(e)}"


# 基础工具 - 天气查询
class WeatherQuery(BaseModel):
    loc: str = Field(description="城市名称，如：杭州、北京、上海")
    date: str = Field(description="日期，格式：YYYY-MM-DD")

@tool(args_schema=WeatherQuery)
def get_weather_for_outing(loc: str, date: str) -> str:
    """
    获取outing活动天气信息，包括出行建议
    :param loc: 城市名称
    :param date: 日期
    :return: 天气信息和出行建议
    """
    try:
        # 模拟天气数据
        weather_data = {
            "杭州": {
                "2025-10-30": {
                    "weather": "晴转多云",
                    "temperature": "15-22°C",
                    "wind": "微风",
                    "humidity": "65%",
                    "advice": "天气适宜户外活动，建议穿长袖速干衣，带薄外套"
                }
            }
        }
        
        if loc in weather_data and date in weather_data[loc]:
            data = weather_data[loc][date]
            return json.dumps({
                "城市": loc,
                "日期": date,
                "天气": data["weather"],
                "温度": data["temperature"],
                "风力": data["wind"],
                "湿度": data["humidity"],
                "出行建议": data["advice"],
                "装备建议": ["速干衣裤", "防晒帽", "薄外套", "运动鞋"]
            }, ensure_ascii=False, indent=2)
        else:
            return json.dumps({
                "城市": loc,
                "日期": date,
                "天气": "晴",
                "温度": "15-25°C",
                "建议": "天气良好，适合户外活动"
            }, ensure_ascii=False)
    except Exception as e:
        return f"天气查询失败：{str(e)}"

# 高德地图相关工具
class GeoCodeQuery(BaseModel):
    address: str = Field(description="详细地址，例如：北京市朝阳区望京街道")
    city: str = Field(default=None, description="城市名称，可选参数")

@tool(args_schema=GeoCodeQuery)
def geocode_address(address: str, city: str = None) -> str:
    """
    高德地图地理编码 - 将地址转换为经纬度坐标
    :param address: 详细地址
    :param city: 城市名称（可选）
    :return: 包含经纬度信息的JSON字符串
    """
    api_key = os.getenv("GAODE_MAP_API_KEY")
    if not api_key:
        return "错误：未配置高德地图API密钥"
    
    url = "https://restapi.amap.com/v3/geocode/geo"
    params = {
        "key": api_key,
        "address": address,
        "output": "json"
    }
    
    if city:
        params["city"] = city
    
    try:
        response = requests.get(url, params=params)
        data = response.json()
        
        if data.get("status") == "1" and data.get("geocodes"):
            location = data["geocodes"][0].get("location", "")
            formatted_address = data["geocodes"][0].get("formatted_address", "")
            return json.dumps({
                "address": address,
                "formatted_address": formatted_address,
                "location": location,
                "longitude": location.split(",")[0] if location else None,
                "latitude": location.split(",")[1] if location else None
            }, ensure_ascii=False)
        else:
            return f"地址解析失败：{data.get('info', '未知错误')}"
    except Exception as e:
        return f"请求失败：{str(e)}"


class ReverseGeoCodeQuery(BaseModel):
    longitude: str = Field(description="经度，例如：116.481")
    latitude: str = Field(description="纬度，例如：39.990")

@tool(args_schema=ReverseGeoCodeQuery)
def reverse_geocode(longitude: str, latitude: str) -> str:
    """
    高德地图逆地理编码 - 将经纬度坐标转换为地址
    :param longitude: 经度
    :param latitude: 纬度
    :return: 包含详细地址信息的JSON字符串
    """
    api_key = os.getenv("GAODE_MAP_API_KEY")
    if not api_key:
        return "错误：未配置高德地图API密钥"
    
    url = "https://restapi.amap.com/v3/geocode/regeo"
    params = {
        "key": api_key,
        "location": f"{longitude},{latitude}",
        "output": "json",
        "extensions": "all"
    }
    
    try:
        response = requests.get(url, params=params)
        data = response.json()
        
        if data.get("status") == "1" and data.get("regeocode"):
            address = data["regeocode"].get("formatted_address", "")
            address_component = data["regeocode"].get("addressComponent", {})
            return json.dumps({
                "longitude": longitude,
                "latitude": latitude,
                "address": address,
                "province": address_component.get("province"),
                "city": address_component.get("city"),
                "district": address_component.get("district"),
                "township": address_component.get("township"),
                "street": address_component.get("streetNumber", {}).get("street"),
                "street_number": address_component.get("streetNumber", {}).get("number")
            }, ensure_ascii=False)
        else:
            return f"逆地理编码失败：{data.get('info', '未知错误')}"
    except Exception as e:
        return f"请求失败：{str(e)}"


class RoutePlanningQuery(BaseModel):
    origin: str = Field(description="起点，可以是地址或经纬度坐标，例如：116.481,39.990 或 北京市朝阳区望京街道")
    destination: str = Field(description="终点，可以是地址或经纬度坐标，例如：116.434,39.908 或 北京市海淀区中关村")
    strategy: str = Field(default="10", description="路径规划策略，10=速度优先，2=费用优先，3=距离优先，5=不走高速，7=少收费，8=躲避拥堵")

@tool(args_schema=RoutePlanningQuery)
def plan_route(origin: str, destination: str, strategy: str = "10") -> str:
    """
    高德地图路径规划 - 获取从起点到终点的路线信息
    :param origin: 起点地址或坐标
    :param destination: 终点地址或坐标
    :param strategy: 路径规划策略
    :return: 包含路线信息的JSON字符串
    """
    api_key = os.getenv("GAODE_MAP_API_KEY")
    if not api_key:
        return "错误：未配置高德地图API密钥"
    
    # 如果输入的是地址，先进行地理编码
    def get_coordinates(location):
        if "," in location and location.replace(",", "").replace(".", "").replace("-", "").replace(" ", "").isdigit():
            return location  # 已经是坐标格式
        else:
            # 进行地理编码
            geo_result = geocode_address(location)
            try:
                geo_data = json.loads(geo_result)
                return geo_data.get("location", "")
            except:
                return ""
    
    origin_coords = get_coordinates(origin)
    dest_coords = get_coordinates(destination)
    
    if not origin_coords or not dest_coords:
        return "地址解析失败，无法获取坐标信息"
    
    url = "https://restapi.amap.com/v3/direction/driving"
    params = {
        "key": api_key,
        "origin": origin_coords,
        "destination": dest_coords,
        "strategy": strategy,
        "output": "json"
    }
    
    try:
        response = requests.get(url, params=params)
        data = response.json()
        
        if data.get("status") == "1" and data.get("route"):
            route = data["route"]["paths"][0]
            return json.dumps({
                "origin": origin,
                "destination": destination,
                "origin_coordinates": origin_coords,
                "destination_coordinates": dest_coords,
                "distance": route.get("distance"),
                "duration": route.get("duration"),
                "strategy": strategy,
                "steps": [
                    {
                        "instruction": step.get("instruction"),
                        "distance": step.get("distance"),
                        "duration": step.get("duration"),
                        "action": step.get("action")
                    }
                    for step in route.get("steps", [])[:5]  # 只返回前5步
                ]
            }, ensure_ascii=False)
        else:
            return f"路径规划失败：{data.get('info', '未知错误')}"
    except Exception as e:
        return f"请求失败：{str(e)}"

class POISearchQuery(BaseModel):
    keywords: str = Field(description="搜索关键词，例如：餐厅、医院、加油站")
    city: str = Field(description="城市名称，例如：北京、上海")
    location: str = Field(default=None, description="中心点坐标，例如：116.481,39.990")
    radius: int = Field(default=3000, description="搜索半径，单位：米，默认3000米")

@tool(args_schema=POISearchQuery)
def search_poi(keywords: str, city: str, location: str = None, radius: int = 3000) -> str:
    """
    高德地图POI搜索 - 搜索周边兴趣点
    :param keywords: 搜索关键词
    :param city: 城市名称
    :param location: 中心点坐标（可选）
    :param radius: 搜索半径（米）
    :return: 包含POI信息的JSON字符串
    """
    api_key = os.getenv("GAODE_MAP_API_KEY")
    if not api_key:
        return "错误：未配置高德地图API密钥"
    
    url = "https://restapi.amap.com/v3/place/text"
    params = {
        "key": api_key,
        "keywords": keywords,
        "city": city,
        "citylimit": "true",
        "output": "json",
        "offset": 10  # 返回最多10个结果
    }
    
    if location:
        params["location"] = location
        params["radius"] = radius
    
    try:
        response = requests.get(url, params=params)
        data = response.json()
        
        if data.get("status") == "1" and data.get("pois"):
            pois = data["pois"]
            return json.dumps({
                "keywords": keywords,
                "city": city,
                "total_count": len(pois),
                "pois": [
                    {
                        "name": poi.get("name"),
                        "address": poi.get("address"),
                        "location": poi.get("location"),
                        "distance": poi.get("distance"),
                        "tel": poi.get("tel"),
                        "type": poi.get("type")
                    }
                    for poi in pois
                ]
            }, ensure_ascii=False)
        else:
            return f"POI搜索失败：{data.get('info', '未知错误')}"
    except Exception as e:
        return f"请求失败：{str(e)}"

# 团队outing专用工具
class TeamOutingQuery(BaseModel):
    question_type: str = Field(description="问题类型：basic/date/location/schedule/equipment/registration")

@tool(args_schema=TeamOutingQuery)
def answer_outing_question(question_type: str) -> str:
    """
    回答outing相关问题，基于1030团队Outing知识库
    :param question_type: 问题类型
    :return: 详细回答
    """
    
    if question_type == "basic":
        return json.dumps({
            "活动主题": OUTING_KNOWLEDGE["活动主题"],
            "活动时间": OUTING_KNOWLEDGE["活动时间"],
            "活动地点": OUTING_KNOWLEDGE["活动地点"],
            "集合信息": OUTING_KNOWLEDGE["集合信息"],
            "活动内容": OUTING_KNOWLEDGE["活动内容"]
        }, ensure_ascii=False, indent=2)
    
    elif question_type == "date":
        return json.dumps({
            "活动日期": OUTING_KNOWLEDGE["活动时间"],
            "集合时间": OUTING_KNOWLEDGE["集合信息"]["集合时间"],
            "星期": "周四",
            "建议": "请提前10分钟到达集合点"
        }, ensure_ascii=False, indent=2)
    
    elif question_type == "location":
        return json.dumps({
            "活动地点": OUTING_KNOWLEDGE["活动地点"],
            "集合点": OUTING_KNOWLEDGE["集合信息"]["集合点"],
            "交通方式": OUTING_KNOWLEDGE["交通方式"],
            "导航建议": "可导航至杭州九溪公交站"
        }, ensure_ascii=False, indent=2)
    
    elif question_type == "schedule":
        return json.dumps({
            "完整行程": OUTING_KNOWLEDGE["时间轴"],
            "总时长": "约9小时",
            "路线": OUTING_KNOWLEDGE["路线详情"]
        }, ensure_ascii=False, indent=2)
    
    elif question_type == "equipment":
        return json.dumps({
            "装备清单": OUTING_KNOWLEDGE["装备清单"],
            "特别提醒": OUTING_KNOWLEDGE["注意事项"]
        }, ensure_ascii=False, indent=2)
    
    elif question_type == "registration":
        return json.dumps({
            "报名方式": "通过智能体报名",
            "所需信息": ["姓名", "部门", "联系电话", "饮食禁忌", "紧急联系人"],
            "截止时间": "活动前一天",
            "确认方式": "报名成功后会收到确认信息"
        }, ensure_ascii=False, indent=2)
    
    else:
        return json.dumps(OUTING_KNOWLEDGE, ensure_ascii=False, indent=2)

# 高铁票查询工具（MCP接口）
class TrainTicketQuery(BaseModel):
    departure: str = Field(description="出发城市，如：北京、上海、广州")
    arrival: str = Field(description="到达城市，如：杭州、上海、广州")
    date: str = Field(description="出发日期，格式：YYYY-MM-DD")
    passenger_name: str = Field(default=None, description="乘客姓名，用于查询个人票务")

@tool(args_schema=TrainTicketQuery)
def query_train_tickets(departure: str, arrival: str, date: str, passenger_name: str = None) -> str:
    """
    查询高铁票信息，支持个人票务查询
    :param departure: 出发城市
    :param arrival: 到达城市
    :param date: 出发日期
    :param passenger_name: 乘客姓名（可选）
    :return: 票务信息
    """
    try:
        # 验证日期格式
        datetime.datetime.strptime(date, "%Y-%m-%d")
        
        # 模拟高铁票数据
        trains = [
            {
                "车次": "G1234",
                "出发": departure,
                "到达": arrival,
                "出发时间": "08:00",
                "到达时间": "12:30",
                "历时": "4小时30分钟",
                "二等座": 553.5,
                "一等座": 884.0,
                "商务座": 1748.0,
                "余票": {"二等座": 120, "一等座": 28, "商务座": 8}
            },
            {
                "车次": "G5678",
                "出发": departure,
                "到达": arrival,
                "出发时间": "14:15",
                "到达时间": "18:45",
                "历时": "4小时30分钟",
                "二等座": 553.5,
                "一等座": 884.0,
                "商务座": 1748.0,
                "余票": {"二等座": 85, "一等座": 15, "商务座": 3}
            }
        ]
        
        result = {
            "查询结果": "成功",
            "出发": departure,
            "到达": arrival,
            "日期": date,
            "推荐车次": trains,
            "温馨提示": [
                "建议提前30分钟到达车站",
                "携带身份证原件",
                "公司可报销车票费用"
            ]
        }
        
        if passenger_name:
            result["个人查询"] = f"{passenger_name}的票务信息已记录"
        
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except ValueError:
        return json.dumps({"error": "日期格式错误，请使用YYYY-MM-DD格式"}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": f"查询失败：{str(e)}"}, ensure_ascii=False)

# 报名信息收集和存储
class RegistrationForm(BaseModel):
    name: str = Field(description="姓名")
    department: str = Field(description="部门")
    phone: str = Field(description="手机号码")
    id_number: str = Field(description="身份证号")
    dietary_restrictions: str = Field(default="无", description="饮食禁忌")
    emergency_contact: str = Field(description="紧急联系人姓名")
    emergency_phone: str = Field(description="紧急联系人电话")
    special_needs: str = Field(default="无", description="特殊需求或备注")

@tool(args_schema=RegistrationForm)
def register_for_outing(name: str, department: str, phone: str, id_number: str,
                       dietary_restrictions: str = "无", emergency_contact: str = "",
                       emergency_phone: str = "", special_needs: str = "无") -> str:
    """
    员工outing报名登记，信息将保存到Excel文件
    :param name: 姓名
    :param department: 部门
    :param phone: 手机号码
    :param id_number: 身份证号
    :param dietary_restrictions: 饮食禁忌
    :param emergency_contact: 紧急联系人
    :param emergency_phone: 紧急联系电话
    :param special_needs: 特殊需求
    :return: 报名确认和文件下载信息
    """
    try:
        # 创建数据目录
        data_dir = Path("outing_registrations")
        data_dir.mkdir(exist_ok=True)
        
        # 文件名
        filename = data_dir / "outing_participants.xlsx"
        
        # 创建报名记录
        registration = {
            "姓名": name,
            "部门": department,
            "手机号码": phone,
            "身份证号": id_number,
            "饮食禁忌": dietary_restrictions,
            "紧急联系人": emergency_contact,
            "紧急联系电话": emergency_phone,
            "特殊需求": special_needs,
            "报名时间": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "活动状态": "已报名",
            "备注": "1030团队Outing"
        }
        
        # 保存到Excel文件
        if filename.exists():
            df = pd.read_excel(filename)
            df = pd.concat([df, pd.DataFrame([registration])], ignore_index=True)
        else:
            df = pd.DataFrame([registration])
        
        df.to_excel(filename, index=False, engine='openpyxl')
        
        # 生成确认信息
        confirmation = {
            "报名状态": "成功",
            "报名确认": f"{name}已成功报名1030团队Outing",
            "报名信息": registration,
            "重要提醒": [
                f"请于10月30日8:30前到达{OUTING_KNOWLEDGE['集合信息']['集合点']}",
                "穿着舒适的运动鞋和速干衣裤",
                "携带防晒霜、驱蚊液和雨衣",
                f"保持手机畅通，联系{OUTING_KNOWLEDGE['集合信息']['联系人']}：{OUTING_KNOWLEDGE['集合信息']['联系电话']}"
            ],
            "文件下载": f"打开命令行输入：scp keke@miserver8.alipay.net:{str(filename.absolute())} --本地路径",
            "总报名人数": len(df)
        }
        
        return json.dumps(confirmation, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "报名状态": "失败",
            "错误信息": str(e),
            "建议": "请检查输入信息是否正确"
        }, ensure_ascii=False)

# 报名查询工具
class RegistrationQuery(BaseModel):
    query_type: str = Field(description="查询类型：all=全部，by_dept=按部门，by_name=按姓名，by_phone=按电话")
    value: str = Field(default=None, description="查询值")

@tool(args_schema=RegistrationQuery)
def query_registrations(query_type: str, value: str = None) -> str:
    """
    查询outing报名情况
    :param query_type: 查询类型
    :param value: 查询值
    :return: 报名统计信息
    """
    try:
        filename = Path("outing_registrations") / "outing_participants.xlsx"
        
        if not filename.exists():
            return json.dumps({
                "查询结果": "暂无报名记录",
                "建议": "请先使用报名功能登记信息"
            }, ensure_ascii=False)
        
        df = pd.read_excel(filename)
        
        if query_type == "all":
            result = df.to_dict('records')
        elif query_type == "by_dept" and value:
            result = df[df['部门'] == value].to_dict('records')
        elif query_type == "by_name" and value:
            result = df[df['姓名'] == value].to_dict('records')
        elif query_type == "by_phone" and value:
            result = df[df['手机号码'] == value].to_dict('records')
        else:
            result = []
        
        # 统计信息
        stats = {
            "查询结果": "成功",
            "总报名人数": len(df),
            "部门分布": df['部门'].value_counts().to_dict(),
            "报名记录": result,
            "最新报名": df.iloc[-1].to_dict() if len(df) > 0 else None
        }
        
        return json.dumps(stats, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "查询结果": "失败",
            "错误信息": str(e)
        }, ensure_ascii=False)

# 装备和攻略生成工具
class OutfitGuideQuery(BaseModel):
    weather_condition: str = Field(description="天气状况")
    temperature: str = Field(description="温度范围")
    activity_type: str = Field(description="活动类型，如：徒步、烧烤、晚会")

@tool(args_schema=OutfitGuideQuery)
def generate_outfit_guide(weather_condition: str, temperature: str, activity_type: str) -> str:
    """
    根据天气和活动类型生成装备和出行攻略
    :param weather_condition: 天气状况
    :param temperature: 温度范围
    :param activity_type: 活动类型
    :return: 详细装备和攻略建议
    """
    
    guide = {
        "天气情况": f"{weather_condition}，{temperature}",
        "活动类型": activity_type,
        "装备建议": {
            "服装": ["速干长袖T恤", "运动长裤", "防风外套", "防滑运动鞋"],
            "配件": ["防晒帽", "太阳镜", "防晒霜SPF50+", "驱蚊液"],
            "装备": ["1L水壶", "能量棒", "小背包", "雨衣"],
            "电子设备": ["充电宝", "手机防水袋", "相机"]
        },
        "出行攻略": [
            "提前查看天气预报，准备相应装备",
            "建议穿防滑运动鞋，避免高跟鞋",
            "携带身份证和少量现金",
            "保持手机电量充足",
            "听从领队安排，注意安全"
        ],
        "特别提醒": [
            "10月山区早晚温差大，注意保暖",
            "户外活动注意防晒和补水",
            "团队活动保持通讯畅通"
        ]
    }
    
    return json.dumps(guide, ensure_ascii=False, indent=2)

def get_rag():
    """
    创建并返回1030团队Outing知识库
    """
    # 创建 Chroma 向量存储实例
    vectorstore = Chroma(
        persist_directory='chromaDB',
        collection_name='demo001',
        embedding_function=llm_embedding,
    )
    
    # 将知识库内容转换为文档
    
    documents = [Document(page_content=json.dumps(OUTING_KNOWLEDGE, ensure_ascii=False), metadata={"source": "1030团队Outing规划"})]
    
    # 添加文档到向量存储
    vectorstore.add_documents(documents)
    
    # 创建检索工具
    retriever = vectorstore.as_retriever()
    retriever_tool = create_retriever_tool(
        retriever,
        name="outing_knowledge",
        description="1030团队Outing完整知识库，包含活动详情、时间安排、装备清单等"
    )
    
    return retriever_tool

# 初始化聊天模型
model = ChatDeepSeek(model="deepseek-chat")

challenge_prompt = """
# 部门outing助手智能体

## 智能体身份
你是**1030团队Outing智能助手**，专门为员工提供outing活动全流程服务。基于官方提供的《1030团队Outing规划》文档，能够准确回答所有相关问题。

## 工具使用指南
### 知识库查询
- **outing_knowledge**: 回答所有关于1030团队Outing的基础问题
- 涵盖：活动详情、时间安排、路线规划、装备清单

### 天气服务
- **get_weather_for_outing**: 查询活动当天天气
- **generate_outfit_guide**: 根据天气生成装备建议

### 交通服务
- **query_train_tickets**: 高铁票查询
- **geocode_address**: 地址转坐标
- **plan_route**: 路线规划
- ** geocode_address**: 地理编码
- ** reverse_geocode**: 逆地理编码
- ** search_poi**: POI搜索

### 报名管理
- **register_for_outing**: 员工报名登记
- **query_registrations**: 报名情况查询
- **download_booking_excel**: 报名信息下载

## 交互示例
### 基础问答
**用户**: "outing什么时候举行？"
**回答**: 2025年10月30日（周四），早上8:30在杭州九溪公交站集合。

**用户**: "outing地点在哪里？"
**回答**: 浙江省杭州市九溪十八涧景区，集合点在九溪公交站。

### 天气查询
**用户**: "10月30日杭州天气如何？"
**回答**: 天气晴转多云，15-22°C，建议穿长袖速干衣，带薄外套。

### 装备建议
**用户**: "需要带什么装备？"
**回答**: 必备装备：防滑运动鞋、速干衣裤、防晒霜、驱蚊液、雨衣、1L水壶。

### 高铁票查询
**用户**: "从北京到杭州的高铁票有哪些？"
**回答**: 推荐G1234次（08:00-12:30）和G5678次（14:15-18:45），二等座553.5元。

### 报名登记
**用户**: "我要报名参加outing"
**回答**: 请提供以下信息：姓名、部门、手机号码、身份证号、饮食禁忌、紧急联系人。

## 重要提醒
- 所有回答必须基于**1030团队Outing规划**文档
- 报名信息会保存到Excel文件，支持下载
- 支持自然语言理解，不同表述但相同语义的问题都能正确回答
- 提供友好、准确、完整的响应

"""

# 创建知识库
retriever_tool = get_rag()

# 工具列表
challenge_tools = [
    retriever_tool,                    # 知识库使用
    answer_outing_question,            # 基础信息回答
    get_weather_for_outing,            # 天气查询
    generate_outfit_guide,             # 装备攻略
    query_train_tickets,               # 高铁票查询
    register_for_outing,               # 报名管理
    query_registrations,               # 报名查询
    get_current_time,                  # 时间查询
    calculate,                         # 计算工具
    geocode_address,                   # 地理编码
    reverse_geocode,                   # 逆地理编码
    plan_route,                        # 路线规划
    search_poi                         # POI搜索
]

# 创建智能体
graph = create_agent(model=model, tools=challenge_tools, system_prompt=challenge_prompt)
