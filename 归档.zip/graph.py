"""
期货交易分析系统
基于LangChain Agent和DeepSeek模型
支持技术指标分析、产业数据分析、多空方向判断
"""
import json
import os
from typing import Dict, Any

from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain_deepseek import ChatDeepSeek
from langgraph.checkpoint.memory import MemorySaver

# 导入自定义模块
from data_loader import load_all_data, format_data_for_prompt, load_config
from kline_fetcher import get_kline_fetcher
from technical_indicators import ALL_INDICATOR_TOOLS

# 加载环境变量
load_dotenv(override=True)


def build_system_prompt(product_name: str = None) -> str:
    """
    构建系统提示词
    包含: 角色定义、产业数据、历史K线、分析框架
    """
    # 加载配置
    config = load_config()
    if product_name is None:
        product_name = config.get("current_product", "螺纹钢")
    
    product_config = config.get("products", {}).get(product_name, {})
    contract_code = product_config.get("contract_code", "RB2505")
    
    # 加载产业数据
    print(f"正在加载 {product_name} 的产业数据...")
    industry_data = load_all_data(product_name)
    industry_text = format_data_for_prompt(industry_data, max_length=8000)
    
    # 加载K线数据
    print(f"正在加载 {contract_code} 的K线数据...")
    kline_fetcher = get_kline_fetcher(mode="mock")
    kline_df = kline_fetcher.get_kline_data(contract_code, bars=200)
    kline_text = kline_fetcher.format_kline_for_prompt(kline_df, recent_bars=30)
    
    # 构建完整prompt
    prompt = f"""# 角色定义
    你是一位资深的期货交易分析专家和系统动力学(SD)建模分析师，精通:
    - 金融工程、统计学、微分方程
    - 系统论、控制论、动态规划
    - 系统动力学、因果分析
    - 技术分析和基本面分析

    ## 核心能力
    1. **多维度分析**: 结合全息模型维度、产业模型、历史数据进行综合分析
    2. **技术指标解读**: 熟练使用MA、EMA、MACD、RSI、BOLL、ATR等技术指标
    3. **趋势判断**: 基于多重证据给出明确的多空方向建议
    4. **风险控制**: 提供止损止盈建议和仓位管理策略

    ---

    # 当前分析品种

    **品种**: {product_name}
    **合约代码**: {contract_code}
    **交易所**: {product_config.get('exchange', 'N/A')}

    ---

    # 产业数据和模型

    {industry_text}

    ---

    # 历史K线数据

    {kline_text}

    ---

    # 分析框架

    当用户提问时,请按照以下框架进行分析:

    ## 1. 技术面分析
    - 调用相关技术指标工具(MA、MACD、RSI、BOLL等)
    - 分析价格趋势和形态
    - 识别支撑位和阻力位
    - 判断超买超卖状态

    ## 2. 基本面分析
    - 结合产业模型和历史数据
    - 分析供需关系
    - 考虑宏观经济因素
    - 评估产业链上下游影响

    ## 3. 综合判断
    - 技术面和基本面的一致性分析
    - 给出明确的方向建议: **做多** 或 **做空**
    - 提供具体的入场点位、止损点位、目标点位
    - 评估风险收益比

    ## 4. 操作建议
    - 仓位管理建议(轻仓/中仓/重仓)
    - 持仓周期建议(短线/中线/长线)
    - 风险提示和注意事项

    ---

    # 工具使用指南

    你可以调用以下技术指标工具:
    - `calculate_ma`: 计算移动平均线
    - `calculate_ema`: 计算指数移动平均线
    - `calculate_macd`: 计算MACD指标
    - `calculate_rsi`: 计算RSI指标
    - `calculate_boll`: 计算布林带
    - `calculate_atr`: 计算平均真实波幅

    调用工具时,从上面的K线数据中提取对应的价格序列。

    ---

    # 输出要求

    1. **结构清晰**: 使用标题、列表、表格等格式
    2. **数据支撑**: 每个判断都要有数据和指标支撑
    3. **明确结论**: 避免模棱两可,给出明确的多空方向
    4. **风险提示**: 必须包含风险提示和应对策略
    5. **中文输出**: 所有分析和建议使用简体中文

    ---

    # 重要提醒

    - 当用户询问最新行情时,优先使用上面提供的K线数据
    - 技术指标分析时,必须调用相应的工具函数
    - 给出操作建议时,必须包含具体点位和止损
    - 保持客观理性,不做过度承诺
    """
    
    return prompt


def create_futures_agent():
    """创建期货分析Agent"""
    # 创建模型
    model = ChatDeepSeek(model="deepseek-chat")
    
    # 构建系统提示词
    system_prompt = build_system_prompt()
    
    # 创建Agent(带记忆功能)
    agent = create_agent(
        model=model,
        tools=ALL_INDICATOR_TOOLS,
        system_prompt=system_prompt,
        checkpointer=MemorySaver()
    )
    
    return agent


def chat_mode():
    """
    交互式聊天模式
    支持持续对话和增量K线更新
    """
    print("=" * 70)
    print("🚀 期货交易分析系统")
    print("=" * 70)
    
    # 加载配置
    config = load_config()
    current_product = config.get("current_product", "螺纹钢")
    product_config = config.get("products", {}).get(current_product, {})
    contract_code = product_config.get("contract_code", "RB2505")
    
    print(f"📊 当前分析品种: {current_product} ({contract_code})")
    print(f"💡 可用功能: 技术指标分析、趋势判断、操作建议")
    print(f"🔧 可调用工具: MA、EMA、MACD、RSI、BOLL、ATR")
    print(f"❓ 输入 'quit', 'exit' 或 'q' 退出")
    print(f"❓ 输入 'update' 更新K线数据")
    print("=" * 70)
    print()
    
    # 创建Agent
    print("正在初始化分析系统...")
    agent = create_futures_agent()
    print("✅ 系统初始化完成!\n")
    
    # K线获取器
    kline_fetcher = get_kline_fetcher(mode="mock")
    
    while True:
        try:
            # 获取用户输入
            user_input = input("您: ").strip()
            
            # 检查退出命令
            if user_input.lower() in ['quit', 'exit', 'q', '退出']:
                print("\n感谢使用期货交易分析系统,祝您交易顺利! 👋")
                break
            
            # 检查更新K线命令
            if user_input.lower() == 'update':
                print("\n正在更新K线数据...")
                kline_df = kline_fetcher.get_kline_data(contract_code, bars=200)
                latest_bar = kline_df.iloc[-1]
                print(f"✅ 最新K线: 日期={latest_bar['datetime'].strftime('%Y-%m-%d')}, "
                      f"收盘={latest_bar['close']:.2f}, "
                      f"成交量={latest_bar['volume']:,}")
                print("提示: K线数据已更新,您可以继续提问\n")
                continue
            
            # 跳过空输入
            if not user_input:
                continue
            
            # 获取最新K线并添加到用户消息中
            kline_df = kline_fetcher.get_kline_data(contract_code, bars=200)
            latest_bar = kline_df.iloc[-1]
            
            # 构建增强的用户消息
            enhanced_input = f"""{user_input}
            [系统自动附加的最新K线数据]
            最新收盘价: {latest_bar['close']:.2f}
            最新日期: {latest_bar['datetime'].strftime('%Y-%m-%d')}
            最高价: {latest_bar['high']:.2f}
            最低价: {latest_bar['low']:.2f}
            成交量: {latest_bar['volume']:,}
            """

            # 调用Agent处理
            print("\n🤖 分析师: ", end="", flush=True)
            response = agent.invoke(
                {"messages": [{"role": "user", "content": enhanced_input}]},
                config={"configurable": {"thread_id": f"{current_product}_session"}}
            )
            
            # 提取并打印回复
            if response and "messages" in response:
                last_message = response["messages"][-1]
                if hasattr(last_message, 'content'):
                    print(last_message.content)
                else:
                    print(last_message)
            else:
                print(response)
            
            print()  # 添加空行分隔
            
        except KeyboardInterrupt:
            print("\n\n检测到中断信号,退出系统...")
            break
        except Exception as e:
            print(f"\n❌ 发生错误: {e}")
            print("请重试或输入 'quit' 退出\n")


if __name__ == "__main__":
    # 启动聊天模式
    chat_mode()