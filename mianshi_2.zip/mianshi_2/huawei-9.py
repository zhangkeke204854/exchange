# 成绩排序
# 对于给出的
# n
# 条姓名和成绩信息，根据指定的排序方式按成绩升序或降序排列并输出。
# 特别的，成绩相同的同学需要保持输入的先后顺序进行排序。可能存在多条信息的学生姓名一致。
# 输入描述：
#
# 输出描述：
# 根据输入的排序方式，按照成绩升序或降序输出所有学生的姓名和成绩。对于每一名学生，新起一行。输出学生的姓名和成绩，用空格分隔。
# 补充说明：
# 本题已于下方时间节点更新，请注意题解时效性：
# 1.
# 2025 - 05 - 16
# 更新题面。
# 2.
# 2025 - 01 - 0
# 9
# 更新题面。
# 示例1
# 输入例子：
# 3
# 0
# fang
# 90
# yang
# 50
# ning
# 70
# 输出例子：
# fang
# 90
# ning
# 70
# yang
# 50
# 示例2
# 输入例子：
# 4
# 1
# fang
# 90
# yang
# 50
# ning
# 70
# yang
# 70
# 输出例子：
# yang
# 50
# ning
# 70
# yang
# 70
# fang
# 90

# # 读取学生数量
# n = int(input())
#
# # 读取排序方式：0表示降序，1表示升序
# mode = int(input())
#
# # 存储学生信息
# students = []
# for i in range(n):
#     line = input().split()
#     name = line[0]
#     score = int(line[1])
#     students.append((name, score))
#
# # 根据排序方式进行排序
# if mode == 0:  # 降序：成绩从高到低
#     sorted_students = sorted(students, key=lambda x: x[1], reverse=True)
# else:  # 升序：成绩从低到高
#     sorted_students = sorted(students, key=lambda x: x[1])
#
# # 输出结果
# for name, score in sorted_students:
#     print(name, score)


# kotori和素因子
# kotori 拿到 n 个互不相同的正整数 a_1,a_2,…,a_n。她要从每个 a_i 中选出一个素因子 p_i，要求所有选出的素因子两两不同，即 p_i≠p_j "  "(i≠j)。
# 若无法满足要求输出 -1；否则输出所有选出的素因子之和 ∑_(i=1)^n p_i 的最小可能值。
# 输入描述：
# 第一行输入整数 n(1<=n<=10)。
# 第二行输入 n 个两两不同的整数 ai(2<=ai<=1000)。
# 输出描述：
# 若存在合法选取方案，输出最小可能和；否则输出-1。
# 示例1
# 输入例子：
# 4
# 12 15 28 22
# 输出例子：
# 17
# 例子说明：
# 可取素因子[3,5,7,2]，和为 17；任意合法方案的和都不小于17。
# 示例2
# 输入例子：
# 5
# 4 5 6 7 8
# 输出例子：
# -1
#
# def get_prime_factors(num):
#     """获取一个数的所有不同素因子"""
#     factors = set()
#     d = 2
#     while d * d <= num:
#         while num % d == 0:
#             factors.add(d)
#             num //= d
#         d += 1
#     if num > 1:
#         factors.add(num)
#     return list(factors)
#
#
# def solve():
#     n = int(input())
#     numbers = list(map(int, input().split()))
#
#     # 获取每个数的素因子列表
#     prime_factors = []
#     for num in numbers:
#         factors = get_prime_factors(num)
#         prime_factors.append(factors)
#
#     # 检查是否有数没有素因子（理论上不会发生）
#     for factors in prime_factors:
#         if not factors:
#             return -1
#
#     min_sum = float('inf')
#     used_primes = set()
#
#     def backtrack(index, current_sum):
#         nonlocal min_sum
#
#         # 剪枝：如果当前和已经不小于最小和，不需要继续
#         if current_sum >= min_sum:
#             return
#
#         # 终止条件：处理完所有数
#         if index == n:
#             min_sum = current_sum
#             return
#
#         # 尝试当前数的每个素因子
#         for prime in prime_factors[index]:
#             if prime not in used_primes:
#                 used_primes.add(prime)
#                 backtrack(index + 1, current_sum + prime)
#                 used_primes.remove(prime)
#
#     backtrack(0, 0)
#
#     return min_sum if min_sum != float('inf') else -1
#
#
# # 主程序
# result = solve()
# print(result)
#
# 切割 01 串 2.0
# 给定一个长度为 n 的 01 串 s。一次切割操作如下：
# ∙" "  选择一个长度 ≥2 的子串，将其分成两个非空连续子串 a（左）和 b（右）；
# ∙" "  记 a 中字符 0 的出现次数为 C_0，b 中字符 1 的出现次数为 C_1；
# ∙" "  仅当 L≦∣C_0-C_1∣≦R 时，此次切割被视为合法。
# 每次合法切割产生的两个子串都可以继续被独立切割（若长度 ≥2 且满足切割条件）。问在最优策略下，最多可以执行多少次切割？
# 输入描述：
# 第一行输入三个整数n,L,R(1<=n<=500,0<=L<=R<=500) ——字符串长度与参数限制。第二行输入一个长度为n的01串 s。
# 输出描述：
# 输出一个整数，表示最多能执行的切割次数。
# 示例1
# 输入例子：
# 6 2 3
# 011011
# 输出例子：
# 3
#
# import sys
#
# # 设置递归限制以应对可能的深递归，虽然这里使用迭代 DP，但预防性设置
# # sys.setrecursionlimit(2000)
#
# def solve():
#     """
#     读取输入并使用动态规划解决切割 01 串 2.0 问题。
#     """
#     try:
#         # 读取 n, L, R
#         # 严格按照输入描述：第一行是 n, L, R
#         line1 = sys.stdin.readline().split()
#         if not line1:
#             return
#         n, L, R = map(int, line1)
#
#         # 读取 01 串 s
#         # 严格按照输入描述：第二行是 01 串 s
#         s = sys.stdin.readline().strip()
#
#     except EOFError:
#         return
#     except Exception:
#         # 处理可能的格式错误或空输入
#         return
#
#     # 长度小于2的串不能切割
#     if n < 2:
#         print(0)
#         return
#
#     # 1. 预处理：计算 0 和 1 的前缀和
#     # Zeros[i] 存储 s[0...i-1] 中 '0' 的数量
#     # Ones[i] 存储 s[0...i-1] 中 '1' 的数量
#     # 数组长度为 n+1
#     Zeros = [0] * (n + 1)
#     Ones = [0] * (n + 1)
#
#     for i in range(n):
#         Zeros[i + 1] = Zeros[i]
#         Ones[i + 1] = Ones[i]
#         if s[i] == '0':
#             Zeros[i + 1] += 1
#         elif s[i] == '1':
#             Ones[i + 1] += 1
#
#     # 定义辅助函数，计算子串中 0 和 1 的数量
#     def get_count_0(i, j):
#         """计算 s[i...j] 中 '0' 的数量 (i, j 均为闭区间，0-based)"""
#         # s[i...j] 的 0 数量 = Zeros[j+1] - Zeros[i]
#         return Zeros[j + 1] - Zeros[i]
#
#     def get_count_1(i, j):
#         """计算 s[i...j] 中 '1' 的数量 (i, j 均为闭区间，0-based)"""
#         # s[i...j] 的 1 数量 = Ones[j+1] - Ones[i]
#         return Ones[j + 1] - Ones[i]
#
#     # 2. 动态规划
#     # DP[i][j] 表示对子串 s[i...j] 进行合法切割，能得到的最大切割次数。
#     # 初始化为 0，因为长度小于 2 或不能合法切割的子串，其最大切割次数为 0 。
#     # DP 数组大小为 n x n
#     DP = [[0] * n for _ in range(n)]
#
#     # len 为子串长度，从 2 递增到 n
#     for length in range(2, n + 1):
#         # i 为子串起始点 (0-based)
#         for i in range(n - length + 1):
#             j = i + length - 1  # j 为子串终止点 (0-based)
#
#             max_cuts = 0  # 记录 s[i..j] 的最大合法切割次数
#
#             # k 为切割点，将子串 s[i...j] 切割成 s[i...k] (左 a) 和 s[k+1...j] (右 b)
#             # k 的范围：i <= k < j
#             for k in range(i, j):
#                 # 左子串 a: s[i...k]
#                 # 右子串 b: s[k+1...j]
#
#                 # C0: 左子串 a 中 '0' 的数量
#                 C0 = get_count_0(i, k)
#
#                 # C1: 右子串 b 中 '1' 的数量
#                 C1 = get_count_1(k + 1, j)
#
#                 # 检查切割是否合法：L <= |C0 - C1| <= R
#                 diff = abs(C0 - C1)
#
#                 if L <= diff <= R:
#                     # 切割合法，此次切割次数为 1，加上左右子串的最优切割次数
#                     current_cuts = 1 + DP[i][k] + DP[k + 1][j]
#                     max_cuts = max(max_cuts, current_cuts)
#
#             # 更新 DP 状态
#             DP[i][j] = max_cuts
#
#     # 3. 输出结果
#     # 最终答案是整个字符串 s[0...n-1] 的最大切割次数
#     print(DP[0][n - 1])
#
#
# # 由于是机考题，通常需要封装在一个函数内并处理标准输入/输出
# if __name__ == "__main__":
#     solve()
