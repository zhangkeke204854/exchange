# 整数与IP地址间的转换
# 原理：ip地址的每段可以看成是一个0-255的整数，把每段拆分成一个二进制形式组合起来，然后把这个二进制数转变成
# 一个长整数。
# 举例：一个ip地址为10.0.3.193
# 每段数字             相对应的二进制数
# 10                   00001010
# 0                    00000000
# 3                    00000011
# 193                  11000001
# 组合起来即为：00001010 00000000 00000011 11000001,转换为10进制数就是：167773121，即该IP地址转换后的数字就是它了。
# 数据范围：保证输入的是合法的 IP 序列
# 输入描述：
# 输入
# 1 输入IP地址
# 2 输入10进制型的IP地址
# 输出描述：
# 输出
# 1 输出转换成10进制的IP地址
# 2 输出转换后的IP地址
# 示例1
# 输入例子：
# 10.0.3.193
# 167969729
# 输出例子：
# 167773121
# 10.3.3.193

# def int_to_ip(num):
#     """将整数转换为IP地址"""
#     return f"{(num >> 24) & 255}.{(num >> 16) & 255}.{(num >> 8) & 255}.{num & 255}"
#
#
# def ip_to_int(ip_str):
#     """将IP地址转换为整数"""
#     parts = list(map(int, ip_str.split('.')))
#     return (parts[0] << 24) + (parts[1] << 16) + (parts[2] << 8) + parts[3]
#
#
# def main():
#     ip_input = input().strip()
#     int_input = int(input().strip())
#
#     print(ip_to_int(ip_input))
#     print(int_to_ip(int_input))
#
#
# if __name__ == "__main__":
#     main()


# 火车进站
# 火车站一共有 n 辆火车需要入站，每辆火车有一个编号，编号为 1 到 n。
# 同时，也有火车需要出站，由于火车站进出共享一个轨道，所以后入站的火车需要先出站。换句话说，对于某一辆火车，只有在它之后入站的火车都出站了，它才能出站。
# 现在，已经知道了火车的入站顺序，你需要计算，一共有多少种不同的出站顺序。按照字典序从小到大依次输出全部的出站顺序。
# 输入描述：
#  第一行输入一个整数 n(1<=n<=10) 代表火车的数量。
#  第二行输入n个整数 a1,a2,….,an(1<=ai<=n) 代表火车的入站顺序。
# 输出描述：
#  输出若干行，每行输出n个整数，代表一种出站顺序。你需要按照字典序从小到大依次输出。
# 示例1
# 输入例子：
# 3
# 1 2 3
# 输出例子：
# 1 2 3
# 1 3 2
# 2 1 3
# 2 3 1
# 3 2 1
#
# def main():
#     n = int(input().strip())
#     arrival = list(map(int, input().split()))
#
#     results = []
#     stack = []
#     output = []
#
#     def backtrack(in_index):
#         # 如果出站序列已经完成
#         if len(output) == n:
#             results.append(output[:])  # 保存副本
#             return
#
#         # 选择1：如果还有火车可以入站，让下一辆火车入站
#         if in_index < n:
#             # 入站
#             stack.append(arrival[in_index])
#             backtrack(in_index + 1)
#             # 回溯
#             stack.pop()
#
#         # 选择2：如果栈不为空，让栈顶火车出站
#         if stack:
#             # 出站
#             train = stack.pop()
#             output.append(train)
#             backtrack(in_index)
#             # 回溯
#             output.pop()
#             stack.append(train)
#
#     backtrack(0)
#
#     # 按字典序排序
#     results.sort()
#
#     # 输出结果
#     for seq in results:
#         print(' '.join(map(str, seq)))
#
#
# if __name__ == "__main__":
#     main()

#
# ？？？
# 有一个字符串 s ，它由小写英文字母和可能是零个或多个的字符 `?` 组成。
# 旺仔哥哥想将每个 `?` 改成小写英文字母，使字符串 t 成为字符串 s 的子序列（不一定连续）。
# 输出任何这样的可能的改写后的字符串，如果没有符合条件的字符串存在，则直接报告不可能即可。
# 输入描述：
# 第一行包含一个整数 T (1<=T<=10**4) - 测试用例数。
# 每个测试用例的第一行包含一个字符串 S （ 1<=|S|<=2*10**5，且 S 仅由小写英文字母和 ```?``` 组成。
# 每个测试用例的第二行包含一个字符串  t（ 1<=|t|<=|s|且 t 仅由小写英文字母组成）--该字符串本应是字符串 s 的子序列。
# 所有测试用例中 |s| 的总和不超过  2*10**5，其中 |x| 表示字符串 x 的长度。
# 输出描述：
# 对于每个测试用例，如果不存在语句中描述的字符串，则输出 "NO"（不带引号）。
#
# 否则，输出 "YES"（不带引号）。然后，输出一行--符合所有条件的字符串。
#
# 如果可能有多个答案，您可以输出其中任何一个。
# 示例1
# 输入例子：
# 4
# ??a???e????ba
# efe
# cbe??????e?b???b
# be
# a???bf?????
# deadaeefb
# f???bf?efc?eeebac?
# afbacea
# 输出例子：
# YES
# efaeaaeaaaaba
# YES
# cbeaaaaaaeabaaab
# NO
# YES
# fafbbfaefceeeebaca
#
#
# def solve():
#     s = input().strip()
#     t = input().strip()
#
#     n = len(s)
#     m = len(t)
#
#     # 找到t在s中的匹配位置
#     match_positions = []
#     j = 0  # t的指针
#
#     for i in range(n):
#         if j < m and (s[i] == t[j] or s[i] == '?'):
#             match_positions.append(i)
#             j += 1
#
#     # 检查是否完整匹配
#     if j != m:
#         print("NO")
#         return
#
#     # 构造结果字符串
#     result = list(s)
#
#     # 处理匹配位置的'?'
#     for idx, pos in enumerate(match_positions):
#         if result[pos] == '?':
#             result[pos] = t[idx]
#
#     # 处理剩余的'?'
#     for i in range(n):
#         if result[i] == '?':
#             result[i] = 'a'  # 任意字符都可以
#
#     print("YES")
#     print(''.join(result))
#
#
# def main():
#     t_cases = int(input().strip())
#     for _ in range(t_cases):
#         solve()
#
#
# if __name__ == "__main__":
#     main()

