# 数据分类处理
# 信息社会，有海量的数据需要分析处理，比如公安局分析身份证号码、QQ
# 用户、手机号码、银行帐号等信息及活动记录。采集输入大数据和分类规则，通过大数据分类处理程序，将大数据分类输出。
# 对于给定的分类规则集
# R = {R_1, R_2,…, R_m} ，规范化它，具体地：
# ∙" "
# 将
# R
# 中的整数按从小到大的顺序重新排序；
# ∙" "
# 去除
# R
# 中的重复元素；
# 记规范化后的分类规则集为
# r = {r_1, r_2,…, r_m} 。
# 对于收集到的、由若干个整数组成的数据集
# I ，按照下方的要求，使用规范后的分类规则集
# r
# 输出分类后的结果。
# ∙" "
# 对于第
# i
# 条分类规则
# r_i ，如果
# I
# 中存在以
# r_i
# 为连续子串的整数，则该规则集有效；进一步地，你需要输出有多少条数据符合该规则，以及这些数据在
# I
# 中的位置、数据本身。
# 子串为从原字符串中，连续的选择一段字符（可以全选、可以不选）得到的新字符串。对应本题中，你需要将整数看作是数字字符串。
#
# 补充说明：
# 本题由牛客重构过题面，您可能想要阅读原始题面，我们一并附于此处。
# 【以下为原始题面】
# 从R依次中取出R < i >，对I进行处理，找到满足条件的I：
# I整数对应的数字需要连续包含R < i > 对应的数字。比如R < i > 为23，I为231，那么I包含了R < i >，条件满足 。
# 按R < i > 从小到大的顺序:
# (1)
# 先输出R < i >；
# (2)
# 再输出满足条件的I的个数；
# (3)
# 然后输出满足条件的I在I序列中的位置索引(从0开始)；
# (4)
# 最后再输出I。
# 附加条件：
# (1)
# R < i > 需要从小到大排序。相同的R < i > 只需要输出索引小的以及满足条件的I，索引大的需要过滤掉
# (2)
# 如果没有满足条件的I，对应的R < i > 不用输出
# (3)
# 最后需要在输出序列的第一个整数位置记录后续整数序列的个数(不包含“个数”本身)
#
# 序列I：15, 123, 456, 786, 453, 46, 7, 5, 3, 665, 453456, 745, 456, 786, 453, 123（第一个15表明后续有15个整数）
# 序列R：5, 6, 3, 6, 3, 0（第一个5表明后续有5个整数）
# 输出：30, 3, 6, 0, 123, 3, 453, 7, 3, 9, 453456, 13, 453, 14, 123, 6, 7, 1, 456, 2, 786, 4, 46, 8, 665, 9, 453456, 11, 456, 12, 786
# 说明：
# 30 - ---后续有30个整数
# 3 - ---从小到大排序，第一个R < i > 为0，但没有满足条件的I，不输出0，而下一个R < i > 是3
# 6 - -- 存在6个包含3的I
# 0 - -- 123
# 所在的原序号为0
# 123 - -- 123
# 包含3，满足条件
# 示例1
# 输入例子：
# 15
# 123
# 456
# 786
# 453
# 46
# 7
# 5
# 3
# 665
# 453456
# 745
# 456
# 786
# 453
# 123
# 5
# 6
# 3
# 6
# 3
# 0
# 输出例子：
# 30
# 3
# 6
# 0
# 123
# 3
# 453
# 7
# 3
# 9
# 453456
# 13
# 453
# 14
# 123
# 6
# 7
# 1
# 456
# 2
# 786
# 4
# 46
# 8
# 665
# 9
# 453456
# 11
# 456
# 12
# 786

# def main():
#     import sys
#     data = sys.stdin.read().split()
#     if not data:
#         return
#
#     # Parse first line: I
#     n = int(data[0])
#     I = list(map(int, data[1:1 + n]))
#
#     # Parse second line: R
#     m = int(data[1 + n])
#     R = list(map(int, data[2 + n:2 + n + m]))
#
#     # Normalize R: remove duplicates and sort
#     R_normalized = sorted(set(R))
#
#     output_items = []
#
#     for r in R_normalized:
#         r_str = str(r)
#         matches = []
#         for idx, num in enumerate(I):
#             if r_str in str(num):
#                 matches.append((idx, num))
#
#         if not matches:
#             continue  # skip if no match
#
#         # Add: r, count, then alternating index and value
#         output_items.append(str(r))
#         output_items.append(str(len(matches)))
#         for idx, val in matches:
#             output_items.append(str(idx))
#             output_items.append(str(val))
#
#     # Prepend total number of output items
#     total_count = len(output_items)
#     result = [str(total_count)] + output_items
#
#     print(" ".join(result))
#
#
# if __name__ == "__main__":
#     main()
#

#
# 撞车
# 一条单向单车道的道路上有 n 辆车，第 i 辆车位于 x_i ，速度大小为 v_i 。
# 显然，如果车辆保持此速度行驶下去，在大多数情况下都会发生碰撞。
# 现在牛牛想知道，至少需要移除几辆车，才能让这些车不发生碰撞？
# 输入描述：
# 第一行一个整数n(1<=n<=10**5)，表示车的数量。
# 接下来 n 行，每行两个整数 xi,vi(|xi|,|vi|<=10**9) ，表示车的位置和速度的大小。
# 数据保证 xi 互不相同。
# 输出描述：
# 输出一行一个整数，表示需要移除车的数量。
# 示例1
# 输入例子：
# 3
# -1 -1
# 0 0
# 1 1
# 输出例子：
# 0
# 示例2
# 输入例子：
# 3
# -1 1
# 0 0
# 1 -1
# 输出例子：
# 2
#
# def main():
#     n = int(input())
#     cars = []
#     for _ in range(n):
#         x, v = map(int, input().split())
#         cars.append((x, v))
#
#     # 按位置排序
#     cars.sort(key=lambda car: car[0])
#
#     # 提取速度序列
#     speeds = [car[1] for car in cars]
#
#     # 求最长非递减子序列（LIS）
#     tails = []
#     for speed in speeds:
#         # 找到第一个大于speed的位置
#         left, right = 0, len(tails)
#         while left < right:
#             mid = (left + right) // 2
#             if tails[mid] <= speed:
#                 left = mid + 1
#             else:
#                 right = mid
#
#         if left == len(tails):
#             tails.append(speed)
#         else:
#             tails[left] = speed
#
#     longest_non_decreasing = len(tails)
#     result = n - longest_non_decreasing
#     print(result)
#
#
# if __name__ == "__main__":
#     main()
#
# ACM中的AC题
# 众所周知，出题人没玩过《双人成行》，于是给出了如下经典二人协作版迷宫问题。孤岛被划分为
# n×m
# 个方格，按行从上到下、列从左到右编号为(1, 1)
# 至(n, m)。地图上的地形分为三种：
# ∙" "
# 平地（`.
# `）——可以自由经过；
# ∙" "
# 陷阱（`  # `）——踩上去立即死亡；
# ∙" "
# 传送门（` @ `）——一旦进入便会立刻离开孤岛。
# 你与来自平行时空的另一个
# "你"
# 最初同时位于坐标(x, y)
# 的同一块平地。两人每次必须同时行动，且朝相反方向各移动一步，即：
# ∙" "
# 如果你选择向上，则另一个你必须向下；
# ∙" "
# 如果你选择向左，则另一个你必须向右，依此类推。
# 在任何时刻，若有人走出边界或踏入陷阱，游戏立即失败；若有人到达传送门，则他会立刻离开并不再返回，之后剩下的那个人可以单独自由移动（不再受
# "相反方向"
# 限制）。
# 请判断是否存在一条合法的移动序列，使得两个人都能成功离开孤岛；若存在，请输出最短所需步数，否则输出 - 1。
# 输入描述：
#
# 输出描述：
# 若存在可行方案，输出最短移动步数；否则输出 - 1。
# 示例1
# 输入例子：
# 3
# 3
# 2
# 2
#
#
# @
#
# .
#
# @
# # ..
# @
#
# .
#
# @
#
#
# 输出例子：
# 2
# 例子说明：
# 你可以先往上后往左到达(1, 1)
# 传送门
# 另外一个时空的你会先下后右到达(3, 3)
# 传送门
# 示例2
# 输入例子：
# 1
# 3
# 1
# 2
# ..
#
# @
#
# 输出例子：
# 3
# 示例3
# 输入例子：
# 3
# 1
# 2
# 1
# #
# .
#
# @
#
# 输出例子：
# -1
# 例子说明：
# 显然，谁都不想走到陷阱那...
#
# from collections import deque
#
#
# def main():
#     # 读取输入
#     line = input().split()
#     n = int(line[0])
#     m = int(line[1])
#     start_r = int(line[2]) - 1  # 转换为0-indexed
#     start_c = int(line[3]) - 1
#
#     grid = []
#     for _ in range(n):
#         grid.append(input().strip())
#
#     # 方向数组：右、左、下、上
#     directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
#
#     # BFS
#     # 状态: (r1, c1, r2, c2, both_active)
#     # both_active: True表示两人都还在，False表示只有一人还在
#     # 为了简化，我们用两个标志位表示每个人是否还在
#     queue = deque()
#     # visited[r1][c1][r2][c2][p1_active][p2_active]
#     # 但这样维度太高，我们用set存储元组
#
#     # 初始状态：两人都在起点，都活跃
#     visited = set()
#     initial_state = (start_r, start_c, start_r, start_c, True, True)
#     visited.add(initial_state)
#     queue.append((start_r, start_c, start_r, start_c, True, True, 0))
#
#     while queue:
#         r1, c1, r2, c2, p1_active, p2_active, steps = queue.popleft()
#
#         # 如果两人都不活跃（都已通过传送门），成功
#         if not p1_active and not p2_active:
#             print(steps)
#             return
#
#         if p1_active and p2_active:
#             # 两人都还在，必须相反方向移动
#             for dr, dc in directions:
#                 nr1, nc1 = r1 + dr, c1 + dc
#                 nr2, nc2 = r2 - dr, c2 - dc
#
#                 # 检查边界
#                 if not (0 <= nr1 < n and 0 <= nc1 < m):
#                     continue
#                 if not (0 <= nr2 < n and 0 <= nc2 < m):
#                     continue
#
#                 # 检查陷阱
#                 if grid[nr1][nc1] == "#" or grid[nr2][nc2] == "#":
#                     continue
#
#                 # 检查新的活跃状态
#                 new_p1_active = grid[nr1][nc1] != "@"
#                 new_p2_active = grid[nr2][nc2] != "@"
#
#                 new_state = (nr1, nc1, nr2, nc2, new_p1_active, new_p2_active)
#                 if new_state not in visited:
#                     visited.add(new_state)
#                     queue.append(
#                         (nr1, nc1, nr2, nc2, new_p1_active, new_p2_active, steps + 1)
#                     )
#
#         elif p1_active and not p2_active:
#             # 只有person1还在
#             for dr, dc in directions:
#                 nr1, nc1 = r1 + dr, c1 + dc
#
#                 # 检查边界
#                 if not (0 <= nr1 < n and 0 <= nc1 < m):
#                     continue
#
#                 # 检查陷阱
#                 if grid[nr1][nc1] == "#":
#                     continue
#
#                 new_p1_active = grid[nr1][nc1] != "@"
#                 new_state = (nr1, nc1, r2, c2, new_p1_active, False)
#                 if new_state not in visited:
#                     visited.add(new_state)
#                     queue.append((nr1, nc1, r2, c2, new_p1_active, False, steps + 1))
#
#         elif not p1_active and p2_active:
#             # 只有person2还在
#             for dr, dc in directions:
#                 nr2, nc2 = r2 + dr, c2 + dc
#
#                 # 检查边界
#                 if not (0 <= nr2 < n and 0 <= nc2 < m):
#                     continue
#
#                 # 检查陷阱
#                 if grid[nr2][nc2] == "#":
#                     continue
#
#                 new_p2_active = grid[nr2][nc2] != "@"
#                 new_state = (r1, c1, nr2, nc2, False, new_p2_active)
#                 if new_state not in visited:
#                     visited.add(new_state)
#                     queue.append((r1, c1, nr2, nc2, False, new_p2_active, steps + 1))
#
#     # 无法让两人都离开
#     print(-1)
#
#
# if __name__ == "__main__":
#     main()
#


