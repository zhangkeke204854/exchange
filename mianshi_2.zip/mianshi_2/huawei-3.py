# 图片整理
# 对于给定的由大小写字母和数字组成的字符串，请按照
# ASCII
# 码值将其从小到大排序。
# 如果您需要了解更多关于
# ASCII
# 码的知识，请参考下表。
#
# 输入描述：
# 在一行上输入一个长度为1 <= length(s) <= 10 ** 3, 仅由大小写字母和数字构成的字符串s，代表输入的字符串。
# 输出描述：
# 在一行上输出一个字符串s，代表排序后的答案。
# 示例1
# 输入例子：
# Ihave1nose2hands10fingers
# 输出例子：
# 0112
# Iaadeeefghhinnnorsssv
#
# def main():
#     s = input().strip()
#     # 按ASCII码值排序
#     sorted_chars = sorted(s)
#     result = ''.join(sorted_chars)
#     print(result)
#
# if __name__ == "__main__":
#     main()
#

# 取数游戏
# 一个 N×M 的由非负整数构成的数字矩阵，你需要在其中取出若干个数字，使得取出的任意两个数字不相邻（若一个数字在另外一个数字相邻 8 个格子中的一个即认为这两个数字相邻），求取出数字和最大是多少。
# 输入描述：
#  第一行有一个正整数 T（1<=T<=20），表示了有 T 组数据。
#
#  对于每一组数据，第一行有两个正整数 N,M（1<=N,M<=6），表示了数字矩阵为 N 行 M 列。
#
#  接下来 N 行，每行 M 个非负整数，描述了这个数字矩阵，满足 1<=aij<=10**5。
# 输出描述：
#  输出共 T 行，每行一个非负整数，输出所求得的答案。
# 示例1
# 输入例子：
# 1
# 3 3
# 1 1 1
# 1 1 1
# 1 1 1
# 输出例子：
# 4
#
# def solve():
#     n, m = map(int, input().split())
#     grid = []
#     for _ in range(n):
#         row = list(map(int, input().split()))
#         grid.append(row)
#
#     # 预处理每行每个状态的和
#     row_sum = [0] * (1 << m)
#
#     # DP
#     # prev_dp[state] = 到上一行为止，上一行状态为state时的最大和
#     prev_dp = {0: 0}  # 初始状态：第-1行状态为0，和为0
#
#     for i in range(n):
#         # 计算当前行每个状态的和
#         curr_row_sum = [0] * (1 << m)
#         for state in range(1 << m):
#             total = 0
#             for j in range(m):
#                 if state & (1 << j):
#                     total += grid[i][j]
#             curr_row_sum[state] = total
#
#         curr_dp = {}
#         # 枚举当前行状态
#         for curr_state in range(1 << m):
#             # 检查当前行状态是否有效（无左右相邻）
#             if curr_state & (curr_state << 1):
#                 continue
#
#             # 枚举上一行状态
#             for prev_state, prev_val in prev_dp.items():
#                 # 检查与上一行是否冲突
#                 if (curr_state & prev_state) or \
#                         (curr_state & (prev_state << 1)) or \
#                         (curr_state & (prev_state >> 1)):
#                     continue
#
#                 # 无冲突，更新DP
#                 new_val = prev_val + curr_row_sum[curr_state]
#                 if curr_state not in curr_dp or curr_dp[curr_state] < new_val:
#                     curr_dp[curr_state] = new_val
#
#         prev_dp = curr_dp
#
#     return max(prev_dp.values())
#
#
# def main():
#     t = int(input().strip())
#     for _ in range(t):
#         result = solve()
#         print(result)
#
#
# if __name__ == "__main__":
#     main()
#
# 画展布置
# 展厅共有 N 幅画作，其艺术价值为整数 A_1,A_2,…,A_N。策展人需选出其中 M 幅依次摆放。设选出后排成一列的价值为 B_1,…,B_M，定义一个画展的不和谐度 L 满足：
#
# L"  "="  " ∑_(i=1)^(M-1)∣B_(i+1)^2-B_i^2∣.
# 请最小化 L 并输出其最小可能值。
# 输入描述：
#  第一行输入两个整数 N,M（2<=M<=N<=10**5）。
#  第二行输入 N 个整数 A1,….An（1<=Ai<=10**5）。
# 输出描述：
#  输出一个整数，表示最小化后的L值。
# 示例1
# 输入例子：
# 4 2
# 1 5 2 4
# 输出例子：
# 3
# 例子说明：
# 选择 {1,2} 得到 L=2**2-1**2=3，为最小值。


# def main():
#     n, m = map(int, input().split())
#     a = list(map(int, input().split()))
#
#     # 排序数组
#     a.sort()
#
#     # 初始化最小L为一个很大的值
#     min_l = float('inf')
#
#     # 遍历所有长度为m的连续子数组
#     for i in range(n - m + 1):
#         min_val = a[i]
#         max_val = a[i + m - 1]
#         l = max_val * max_val - min_val * min_val
#         min_l = min(min_l, l)
#
#     print(min_l)
#
#
# if __name__ == "__main__":
#     main()
