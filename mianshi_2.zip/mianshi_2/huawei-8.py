# 合并表记录
# 数据表中，一条记录包含表索引和数值两个值。请对表索引相同的记录进行合并（即将相同索引的数值进行求和运算），随后按照索引值的大小从小到大依次输出。
# 输入描述：
# 第一行输入一个整数 n(1<=n<=500) 代表数据表的记录数。
# 此后 n 行，第 i 行输入两个整数 Xi,Yi(0<=Xi<=11111111;1<=Yi<=10**5) 代表数据表的第 i 条记录的索引和数值。
# 输出描述：
# 一共若干行（视输入数据变化），第 i 行输出两个整数，代表合并后数据表中第 i 条记录的索引和数值。
# 示例1
# 输入例子：
# 4
# 0 1
# 0 2
# 1 2
# 3 4
# 输出例子：
# 0 3
# 1 2
# 3 4
# 示例2
# 输入例子：
# 2
# 0 1
# 0 1
# 输出例子：
# 0 2
#
#
# def main():
#     n = int(input())
#
#     # 使用字典存储索引到数值总和的映射
#     record_dict = {}
#
#     # 读取n条记录
#     for _ in range(n):
#         x, y = map(int, input().split())
#         if x in record_dict:
#             record_dict[x] += y
#         else:
#             record_dict[x] = y
#
#     # 按索引从小到大排序并输出
#     for index in sorted(record_dict.keys()):
#         print(index, record_dict[index])
#
#
# if __name__ == "__main__":
#     main()

# 硬币凑钱
#  银行拥有面值为 7 元、5 元与 1 元的硬币若干，每种面值的硬币数量均视为无限。现在需要支付恰好 n 元，求出所需硬币数量的最小值。
# 输入描述：
#  在一行上输入一个整数 n(1<=n<=10**6)，表示需要支付的金额（单位：元）。
# 输出描述：
#  输出一个整数，表示凑成 n 元所需的最少硬币数量。
# 示例1
# 输入例子：
# 8
# 输出例子：
# 2
# 例子说明：
# 示例2
# 输入例子：
# 10
# 输出例子：
# 2
#
# def main():
#     n = int(input().strip())
#
#     # 根据示例推断，硬币面值应为1, 3, 5元
#     coins = [1, 5, 7]
#
#     # dp[i] 表示凑成金额i所需的最少硬币数量
#     dp = [float('inf')] * (n + 1)
#     dp[0] = 0
#
#     for i in range(1, n + 1):
#         for coin in coins:
#             if i >= coin:
#                 dp[i] = min(dp[i], dp[i - coin] + 1)
#
#     print(dp[n])
#
#
# if __name__ == "__main__":
#     main()
#
# 时津风的资源收集
# 时津风曾沉迷于页游 Kancolle。在游戏中，有一项日常任务需要玩家使用油、弹药、钢材、铝这 4 种资源来开发装备。
# 现给定目标资源量 a,b,c,d，时津风进入开发界面时 4 种资源均为 10 单位。她可以对单一资源执行以下任意一种操作（资源总量始终保持在区间 [10,300]）：
# ∙" " 将该资源 ±1；
# ∙" " 将该资源 ±10；
# ∙" " 将该资源 ±100；
# ∙" " 直接将该资源设为上限 300；
# ∙" " 直接将该资源设为下限 10。
# 在保证所有资源始终处于合法范围的前提下，求使四种资源同时恰好达到 (a,b,c,d) 所需的最少操作次数。
# 输入描述：
# 第一行输入整数 T(1<=T<=10**5) —— 测试组数。
# 接下来 T 行，每行输入4个整数 a,b,c,d(10<=a,b,c,d,<=300)。
# 输出描述：
# 对每组数据输出一个整数，表示最少操作次数。
# 示例1
# 输入例子：
# 2
# 10 100 200 300
# 10 10 10 10
# 输出例子：
# 5
# 0

# def min_operations(target):
#  if target == 300:
#   return 1
#
#  # 贪心策略：尽可能用+10，然后+5，最后+1
#  ops = target // 10
#  remainder = target % 10
#  if remainder >= 5:
#   ops += 1  # +5 operation
#   ops += remainder - 5  # +1 operations
#  else:
#   ops += remainder  # +1 operations
#
#  return ops
#
#
# # 读取输入
# T = int(input())
# for _ in range(T):
#  a, b, c, d = map(int, input().split())
#  total_ops = min_operations(a) + min_operations(b) + min_operations(c) + min_operations(d)
#  print(total_ops)

