# 名字的漂亮度
# 对于给定由小写字母构成的字符串，定义字符串的“漂亮度”为该字符串中所有字母“漂亮度”的总和。
# 每一个字母的“漂亮度”将由你来确定，具体规则如下：
# ∙" " 每一个字母的“漂亮度”为 1 到 26 之间的整数；
# ∙" " 没有两个字母的“漂亮度”相同。
# 现在，你需要确定每个字母的“漂亮度”，以使得字符串的“漂亮度”最大。
# 输入描述：
# 每个测试文件均包含多组测试数据。第一行输入一个整数 T(1<=T<=10) 代表数据组数，每组测试数据描述如下：
# 在一行上输入一个长度为 1<=len(s)<=10**4、仅由小写字母构成的字符串s。
# 输出描述：
# 对于每一组测试数据，输出一个整数，表示字符串的最大“漂亮度”。
# 示例1
# 输入例子：
# 2
# zhangsan
# lisi
# 输出例子：
# 192
# 101

# def main():
#     T = int(input())
#
#     for _ in range(T):
#         s = input().strip()
#
#         # 统计每个字母的频率
#         freq = {}
#         for char in s:
#             freq[char] = freq.get(char, 0) + 1
#
#         # 获取频率列表并按降序排序
#         frequencies = sorted(freq.values(), reverse=True)
#
#         # 计算最大漂亮度
#         # 频率最高的分配26，第二高分配25，以此类推
#         max_beauty = 0
#         beauty_value = 26
#         for freq_count in frequencies:
#             max_beauty += freq_count * beauty_value
#             beauty_value -= 1
#
#         print(max_beauty)
#
#
# if __name__ == "__main__":
#     main()
#
# 太阳系DISCO
# 在一个平行世界的太阳系中，所有行星恰好构成一个长度为
# n
# 的环，按顺时针依次编号为
# 1, 2,…, n。相邻两颗行星间距离相等，且保证
# n
# 为偶数。
# 你位于编号为
# a
# 的行星，目标是到达编号为
# b
# 的行星。你可以执行以下三种操作，每次操作均消耗
# 1
# 个单位时间：
# ∙" "
# 顺时针移动
# x
# 颗行星；
# ∙" "
# 逆时针移动
# y
# 颗行星；
# ∙" "
# 发动一次传送技能（最多可使用
# k
# 次），将你顺时针移动
# n / 2
# 颗行星，即跳到正对面的那颗行星。
# 请你计算，从
# a
# 行星移动到
# b
# 行星的最少时间；若无论如何都无法到达，则输出 - 1。
# 输入描述：
#
# 输出描述：
# 输出一个整数，表示最少所需时间；若无法到达，则输出 - 1。
# 示例1
# 输入例子：
# 4
# 0
# 1
# 2
# 2
# 1
# 输出例子：
# 2
# 示例2
# 输入例子：
# 4
# 114514
# 1
# 3
# 1
# 1
# 输出例子：
# 1
# 示例3
# 输入例子：
# 4
# 114514
# 1
# 2
# 2
# 2
# 输出例子：
# -1

# import sys
# from collections import deque
#
#
# def solve():
#     """
#     解决太阳系DISCO问题。使用BFS计算普通移动的最短距离，然后枚举传送次数。
#     """
#     # 读取一行输入 n, k, a, b, x, y
#     try:
#         # 确保输入正确性
#         line = sys.stdin.readline()
#         if not line:
#             print("-1")
#             return
#
#         # n (行星数), k (最大传送次数), a (起点), b (终点), x (顺移距离), y (逆移距离)
#         n, k, a, b, x, y = map(int, line.split())
#     except EOFError:
#         return
#     except ValueError:
#         return
#     except Exception:
#         # 如果输入格式不正确或为空，则按无法到达处理
#         print("-1")
#         return
#
#     # n 必须是偶数，且 2 <= n <= 2*10^5
#     if n % 2 != 0 or n < 2:
#         # 根据题意，n 保证为偶数，但作为防御性编程，此处可以忽略，或根据实际情况处理
#         pass
#
#     # 1. BFS 预计算普通移动 (x, y) 的最短距离
#
#     # dist[i] 存储从起点 a 到行星 i+1 的最小普通移动次数 (0-based)
#     # 使用 0-based 索引 [0, n-1] 对应行星 [1, n]
#     # 转换: 1-based index (p) -> 0-based index (p-1)
#     # 转换: 0-based index (i) -> 1-based index (i+1)
#
#     # 初始化距离数组，使用 -1 表示不可达，0 表示可达，方便检查
#     dist = [-1] * n
#     queue = deque()
#
#     start_node = a - 1  # 0-based 起点
#     dist[start_node] = 0
#     queue.append(start_node)
#
#     while queue:
#         u = queue.popleft()
#
#         # 顺时针移动 x
#         v1 = (u + x) % n
#         if dist[v1] == -1:
#             dist[v1] = dist[u] + 1
#             queue.append(v1)
#
#         # 逆时针移动 y
#         # (u - y) % n 在 Python 中对于负数会得到正结果，是正确的模运算
#         v2 = (u - y) % n
#         if dist[v2] == -1:
#             dist[v2] = dist[u] + 1
#             queue.append(v2)
#
#     # 2. 枚举传送次数 j (0 <= j <= k)
#
#     min_total_time = float('inf')
#     target_node = b - 1  # 0-based 终点
#     half_n = n // 2  # 传送距离 n/2
#
#     # 初始状态 (a - 1)
#     current_pos_0based = a - 1
#
#     # 由于 n/2 传送操作的性质，每两次传送回到原位置，即只关心 j % 2
#     # 我们只需要检查 j=0, 1 的情况，除非 k < 2
#
#     # 事实上，我们只需要检查 j=0 和 j=1 即可。
#     # j=0 对应 a
#     # j=1 对应 a + n/2
#     # j=2 对应 a + n/2 + n/2 = a + n = a (mod n)
#     # j=3 对应 a + 3*n/2 = a + n + n/2 = a + n/2 (mod n)
#     # j 次传送到达的位置只与 j 的奇偶性有关
#     max_j_to_check = min(k, 1)  # 只需检查 j=0 和 j=1 (如果 k>=1)
#
#     for j in range(max_j_to_check + 1):
#         # 计算使用 j 次传送后到达的位置 u_j (0-based)
#         u_j = (current_pos_0based + j * half_n) % n
#
#         # d_xy(u_j, b): 从 u_j 到 b 的最小普通移动次数
#         # d_xy(u_j, b) = d_xy(a, b - (u_j - a))
#         # 由于环的对称性，我们计算的是从 a 到 u_j 的最短距离 d_xy(a, u_j)，但这里 u_j 已经是目标 b 在只用普通移动下，到 a 的相对距离
#
#         # 这里的 u_j 实际上是：从 a 经过 j 次传送到达的位置
#         # 我们需要从 u_j 移动到 b
#
#         # 由于普通移动图 G_xy 也是对称的 (所有点到所有可达点的最短距离相同)
#         # d_xy(u_j, b) = d_xy(a, b - u_j + a) (模 n)
#         # 换句话说，我们只需要计算从 a 出发，经过普通移动到达 (b - u_j + a) 模 n 的距离。
#         # (b - u_j) 模 n 是 u_j 到 b 的**顺时针**距离
#
#         # 实际上，只需检查 dist 数组是否能到达 b 对应的点，这个 dist 数组是从 a 传播的
#         # d_xy(u_j, b) = dist_from_u_j[b]
#
#         # 关键洞察：由于图 G_xy 的同构性，我们只需要计算 G_xy 上 $0$ 到 $d$ 的最短距离 $d_{xy}(0, d)$。
#         # 则 $d_{xy}(u_j, b) = d_{xy}(0, (b - u_j) \pmod n)$
#
#         # 1. 相对目标距离 (0-based)
#         # (b - 1) - u_j 是 0-based 的差
#         # 相对目标距离 D_rel = ((b - 1) - u_j) % n
#         D_rel = (target_node - u_j) % n
#
#         # 2. 从 a 到 a + D_rel 的普通移动距离
#         # dist[D_rel] 存储的就是从 0 到 D_rel 的最短普通移动距离
#
#         dist_xy = dist[D_rel]
#
#         if dist_xy != -1:
#             # j 次传送时间 j + 普通移动时间 dist_xy
#             total_time = j + dist_xy
#             # 考虑 j 的所有奇偶性
#             # 如果 k >= 2，那么 j 就可以是 2, 3, 4, ...
#
#             # 如果 j 是偶数 (j = 2m)，到达 u_0。总时间 j + d_xy(u_0, b)
#             # 如果 j 是奇数 (j = 2m+1)，到达 u_1. 总时间 j + d_xy(u_1, b)
#
#             if j == 0:
#                 # 偶数次传送
#                 # 最优偶数次传送次数是 0 (因为 0 + dist_xy < 2 + dist_xy < ...)
#                 min_total_time = min(min_total_time, total_time)
#
#             elif j == 1 and k >= 1:
#                 # 奇数次传送
#                 # 如果 k >= 1，最优奇数次传送次数是 1
#                 min_total_time = min(min_total_time, total_time)
#
#     # 3. 最终结果
#
#     # 检查是否还有更优的奇数/偶数次传送
#
#     # 偶数次传送的最小时间
#     time_even = float('inf')
#     if dist[0] != -1:  # dist[0] = d_xy(a, a) = 0
#         dist_to_target_from_a = dist[(target_node - start_node) % n]
#         if dist_to_target_from_a != -1:
#             # 最少 0 次传送
#             time_even = dist_to_target_from_a
#             # 也可以是 2, 4, ... 次传送，但由于每次传送+2时间，肯定不如 0 次
#             # 除非 dist_to_target_from_a 是无穷大，但前面已经检查了 dist[0]
#
#     # 奇数次传送的最小时间 (如果 k >= 1)
#     time_odd = float('inf')
#     if k >= 1:
#         # u_1 = a + n/2 (mod n)
#         # 相对目标距离 D_rel = (b - u_1) mod n
#         # D_rel = (target_node - (start_node + half_n)) % n
#         D_rel_odd = (target_node - (start_node + half_n)) % n
#         dist_to_target_from_u1 = dist[D_rel_odd]
#         if dist_to_target_from_u1 != -1:
#             # 最少 1 次传送
#             time_odd = 1 + dist_to_target_from_u1
#             # 也可以是 3, 5, ... 次传送，但肯定不如 1 次，除非 k < 3
#             if k >= 3:
#                 # 如果 1 次传送无法到达，但 3 次可以，那 3 次是 3 + dist_xy。
#                 # 由于图 G_xy 的对称性，如果 1 次可达，1 次最优；如果 1 次不可达，3 次也不可能更好。
#                 pass  # 1 次传送最优
#
#     # 最终结果是 min(time_even, time_odd)
#     min_total_time = min(time_even, time_odd)
#
#     if min_total_time == float('inf'):
#         print("-1")
#     else:
#         print(min_total_time)
#
#
# if __name__ == "__main__":
#     solve()
#
#
# 来硬的
# 你厌倦了探索的日子，背包中堆满了铁矿石，准备放进熔炉烧炼。共有
# n
# 枚煤炭可供使用，第
# i
# 枚煤炭具有：
# ∙" "
# 可在熔炉中燃烧
# y_i
# 秒；
# ∙" "
# 最多融化
# x_i
# 单位铁矿石。
# 你掌握一项魔法，至多对
# 一枚
# 煤炭施放，将其升级为暗物质燃料。若第
# i
# 枚煤炭被升级，则：
# ∙" "
# 燃烧时间变为
# y_i / 2
# 秒；
# ∙" "
# 可融化的矿石数量变为
# 2
# x_i
# 单位。
# 熔炉同一时刻只允许燃烧一枚燃料；燃料耗尽之前，无法取出已融化的矿石。每枚燃料仅能使用一次。
# 现在你拥有
# m
# 单位铁矿石，请计算最少需要多少秒才能全部烧炼完毕。
# 输入描述：
#
# 输出描述：
# 输出一个整数，表示烧炼完
# m
# 单位铁矿石所需的最短时间。
# 示例1
# 输入例子：
# 5
# 28
# 6
# 8
# 5
# 4
# 6
# 10
# 5
# 2
# 6
# 4
# 输出例子：
# 14

# import sys
# from bisect import bisect_left
#
#
# def solve():
#     """
#     解决“来硬的”问题，使用贪心和前缀和结合二分查找，实现 O(N log N) 复杂度。
#     """
#     try:
#         # 读取 n, m
#         line = sys.stdin.readline().split()
#         if not line:
#             return
#         n, m = map(int, line)
#
#         # 读取 n 行 (xi, yi)
#         fuels = []
#         for i in range(n):
#             line = sys.stdin.readline().split()
#             if not line:
#                 # 确保读取了所有 n 行
#                 return
#             x, y = map(int, line)
#             # 存储 (x, y, original_index)
#             fuels.append((x, y, i))
#
#     except EOFError:
#         return
#     except Exception:
#         # 处理可能的格式错误
#         return
#
#     # 1. 对所有普通燃料 (xi, yi) 进行排序 (按时间 yi 升序)
#     # L 存储排序后的普通燃料 (x, y, original_index)
#     L = sorted(fuels, key=lambda item: item[1])
#
#     # 2. 预计算普通燃料的前缀和
#     # PX[k]: L 中前 k 个燃料的矿石总量 (0-based)
#     # PY[k]: L 中前 k 个燃料的燃烧时间总量 (0-based)
#     PX = [0] * (n + 1)
#     PY = [0] * (n + 1)
#
#     for i in range(n):
#         x_i, y_i, _ = L[i]
#         PX[i + 1] = PX[i] + x_i
#         PY[i + 1] = PY[i] + y_i
#
#     # 辅助函数：在 L 中选择最小时间满足 m_req 矿石量
#     def get_min_time_from_L(m_req):
#         """使用二分查找在普通燃料 L 中找到满足 m_req 所需的最小时间"""
#         if m_req <= 0:
#             return 0
#         if m_req > PX[n]:
#             return float('inf')  # 不可能满足
#
#         # 二分查找 PX 数组，找到第一个 >= m_req 的元素索引 (1-based)
#         # bisect_left 找到满足 P_X[k] >= m_req 的最小 k
#         k = bisect_left(PX, m_req)
#
#         # 索引 k 即为所需的最少燃料数量，PY[k] 为所需时间
#         return PY[k]
#
#     # 初始化最小总时间
#     min_total_time = float('inf')
#
#     # --- 情况 0: 不升级任何煤炭 ---
#     T0 = get_min_time_from_L(m)
#     min_total_time = min(min_total_time, T0)
#
#     # --- 情况 1 到 n: 升级第 i 块煤炭 ---
#
#     # 循环遍历所有原始煤炭 i (使用 fuels 列表确保遍历所有原始煤炭)
#     for i in range(n):
#         x_i, y_i, _ = fuels[i]
#
#         # 1. 升级后的燃料 Fi = (2xi, yi/2)
#         x_upgrade = 2 * x_i
#         y_upgrade = y_i // 2
#
#         # 2. 剩余矿石量 m'
#         m_prime = m - x_upgrade
#
#         # 3. 初始时间 T = yi/2
#         T_i = y_upgrade
#
#         if m_prime > 0:
#             # 需要从剩余的 n-1 块普通煤炭中选择 (R_i)
#             # 目标是：在 L 中移除 (xi, yi) 对应的元素，对剩余元素贪心选择 m' 矿石量
#
#             # 找到 L 中 (xi, yi) 对应的索引 k_idx
#             # 由于 L 存储了原始索引，我们可以找到它
#             k_idx = -1
#             for j in range(n):
#                 if L[j][2] == i:
#                     k_idx = j
#                     break
#
#             # k_idx 找到的是 L 数组中的 0-based 索引
#
#             # 计算 T': 从 R_i 中贪心选择 m' 矿石量所需的时间
#
#             # R_i 的矿石总量
#             total_x_ri = PX[n] - x_i
#             if m_prime > total_x_ri:
#                 T_i = float('inf')  # 剩余普通煤炭不足以满足 m'
#             else:
#                 # 找到满足 m' 的最短时间 T'
#                 T_prime = 0
#                 m_current = 0
#
#                 # 由于 R_i 也是按时间排序的，我们仍然可以贪心遍历 L，跳过 k_idx
#                 for j in range(n):
#                     if j == k_idx:
#                         continue  # 跳过被升级的燃料
#
#                     x_j, y_j, _ = L[j]
#
#                     if m_current < m_prime:
#                         m_current += x_j
#                         T_prime += y_j
#
#                         if m_current >= m_prime:
#                             # 已经满足 m' 矿石量，但可能多选了最后一个燃料的一部分
#                             # 由于题意是燃料耗尽才能取出，所以必须使用整块燃料。
#                             # 贪心选择是正确的：按时间从小到大选择，直到满足 m'
#                             T_i += T_prime
#                             break
#                 else:
#                     # 不可能到达这里，因为前面检查了 total_x_ri >= m_prime
#                     pass
#
#         # 更新最小总时间
#         min_total_time = min(min_total_time, T_i)
#
#     # 4. 输出结果
#     if min_total_time == float('inf'):
#         # 理论上不会发生，因为数据保证 sum(xi) >= m
#         print("-1")
#     else:
#         print(min_total_time)
#
#
# if __name__ == "__main__":
#     solve()
