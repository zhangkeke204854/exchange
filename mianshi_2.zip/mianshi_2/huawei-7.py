# 密码强度等级
# 密码按如下规则进行计分，并根据不同的得分为密码进行安全等级划分。
# 一、密码长度:
# 5
# 分: 小于等于4
# 个字符
# 10
# 分: 5
# 到7
# 字符
# 25
# 分: 大于等于8
# 个字符
# 二、字母:
# 0
# 分: 没有字母
# 10
# 分: 密码里的字母全都是小（大）写字母
# 20
# 分: 密码里的字母符合”大小写混合“
# 三、数字:
# 0
# 分: 没有数字
# 10
# 分: 1
# 个数字
# 20
# 分: 大于1
# 个数字
# 四、符号:
# 0
# 分: 没有符号
# 10
# 分: 1
# 个符号
# 25
# 分: 大于1
# 个符号
# 五、奖励（只能选符合最多的那一种奖励）:
# 2
# 分: 字母和数字
# 3
# 分: 字母、数字和符号
# 5
# 分: 大小写字母、数字和符号
# 最后的评分标准:
# >= 90: 非常安全
# >= 80: 安全（Secure）
# >= 70: 非常强
# >= 60: 强（Strong）
# >= 50: 一般（Average）
# >= 25: 弱（Weak）
# >= 0: 非常弱（Very_Weak）
# 对应输出为：
# VERY_SECURE
# SECURE
# VERY_STRONG
# STRONG
# AVERAGE
# WEAK
# VERY_WEAK
# 请根据输入的密码字符串，进行安全评定。
# 注：
# 字母：a - z, A - Z
# 数字：0 - 9
# 符号包含如下： (ASCII码表可以在UltraEdit的菜单view->ASCII Table查看)
# !"#$%&'()*+,-./     (ASCII码：0x21~0x2F)
# :; <= > ?
#
# @(ASCII码：0x3A~0x40)
#
#
# [\] ^ _
# `              (ASCII码：0x5B~0x60)
# { |}~                (ASCII码：0x7B~0x7E)
#
# 提示:
# 1 <= 字符串的长度 <= 300
# 输入描述：
# 输入一个string的密码
# 输出描述：
# 输出密码等级
# 示例1
# 输入例子：
# 38$
#
# @NoNoN
#
#
# 输出例子：
# VERY_SECURE
# 例子说明：
# 样例的密码长度大于等于8个字符，得25分；大小写字母都有所以得20分；有两个数字，所以得20分；包含大于1符号，所以得25分；由于该密码包含大小写字母、数字和符号，所以奖励部分得5分，经统计得该密码的密码强度为25 + 20 + 20 + 25 + 5 = 95
# 分。
#
# 示例2
# 输入例子：
# Jl)M: +
# 输出例子：
# AVERAGE
# 例子说明：
# 示例2的密码强度为10 + 20 + 0 + 25 + 0 = 55
# 分。
#
#
# def main():
#     password = input().strip()
#
#     # 一、密码长度评分
#     length = len(password)
#     if length <= 4:
#         length_score = 5
#     elif 5 <= length <= 7:
#         length_score = 10
#     else:  # length >= 8
#         length_score = 25
#
#     # 二、字母评分
#     has_lower = False
#     has_upper = False
#     for char in password:
#         if char.islower():
#             has_lower = True
#         elif char.isupper():
#             has_upper = True
#
#     if not has_lower and not has_upper:
#         letter_score = 0
#     elif (has_lower and not has_upper) or (not has_lower and has_upper):
#         letter_score = 10
#     else:  # has_lower and has_upper
#         letter_score = 20
#
#     # 三、数字评分
#     digit_count = 0
#     for char in password:
#         if char.isdigit():
#             digit_count += 1
#
#     if digit_count == 0:
#         digit_score = 0
#     elif digit_count == 1:
#         digit_score = 10
#     else:  # digit_count > 1
#         digit_score = 20
#
#     # 四、符号评分
#     # 符号范围：!"#$%&'()*+,-./ (0x21~0x2F)
#     #           :;<=>?@ (0x3A~0x40)
#     #           [\]^_` (0x5B~0x60)
#     #           {|}~ (0x7B~0x7E)
#     symbol_count = 0
#     for char in password:
#         ascii_val = ord(char)
#         if (0x21 <= ascii_val <= 0x2F or
#                 0x3A <= ascii_val <= 0x40 or
#                 0x5B <= ascii_val <= 0x60 or
#                 0x7B <= ascii_val <= 0x7E):
#             symbol_count += 1
#
#     if symbol_count == 0:
#         symbol_score = 0
#     elif symbol_count == 1:
#         symbol_score = 10
#     else:  # symbol_count > 1
#         symbol_score = 25
#
#     # 五、奖励评分（只能选符合最多的那一种奖励）
#     reward_score = 0
#
#     has_letter = has_lower or has_upper
#     has_digit = digit_count > 0
#     has_symbol = symbol_count > 0
#
#     # 5分：大小写字母、数字和符号
#     if has_lower and has_upper and has_digit and has_symbol:
#         reward_score = 5
#     # 3分：字母、数字和符号（但不满足5分条件）
#     elif has_letter and has_digit and has_symbol:
#         reward_score = 3
#     # 2分：字母和数字（但不满足3分或5分条件）
#     elif has_letter and has_digit:
#         reward_score = 2
#     # 其他情况奖励为0
#
#     # 计算总分
#     total_score = length_score + letter_score + digit_score + symbol_score + reward_score
#
#     # 根据总分确定安全等级
#     if total_score >= 90:
#         result = "VERY_SECURE"
#     elif total_score >= 80:
#         result = "SECURE"
#     elif total_score >= 70:
#         result = "VERY_STRONG"
#     elif total_score >= 60:
#         result = "STRONG"
#     elif total_score >= 50:
#         result = "AVERAGE"
#     elif total_score >= 25:
#         result = "WEAK"
#     else:
#         result = "VERY_WEAK"
#
#     print(result)
#
#
# if __name__ == "__main__":
#     main()


# 小A的线段（easy version）
# 在坐标轴的整数点 1∼n 上给出 m 条闭区间线段，第 i 条线段用其端点 [" " st_i," " ed_i " "] 描述。
# 现在要从这 m 条线段中选择若干条，使得每个整数点被至少两条所选线段覆盖。求满足条件的选择方案数量；两种方案视为不同，当且仅当存在某条线段在两方案中的"选/不选"状态不同。
# 答案对 P=998" " 244" " 353 取模。
# 输入描述：
# 第一行输入整数n,m(2<=n<=10**5,1<=m<=10)。
# 随后 m 行，每行两个整数Si,Ei（1<=Si<Ei<=n）描述一条线段。
# 输出描述：
#  输出满足条件的方案数对   取模的结果。
# 示例1
# 输入例子：
# 5 4
# 4 5
# 1 5
# 3 5
# 1 4
# 输出例子：
# 3

# def main():
#     MOD = 1000000007
#
#     import sys
#     input = sys.stdin.read
#     data = input().split()
#
#     n = int(data[0])
#     m = int(data[1])
#
#     segments = []
#     index = 2
#     for i in range(m):
#         s = int(data[index])
#         e = int(data[index + 1])
#         index += 2
#         segments.append((s, e))
#
#     # 收集所有关键点
#     key_points = set()
#     key_points.add(1)
#     key_points.add(n + 1)
#
#     for s, e in segments:
#         key_points.add(s)
#         key_points.add(e + 1)
#
#     key_points = sorted(key_points)
#
#     # 枚举所有方案
#     total_valid = 0
#
#     # 预处理：对于每个关键区间，确定哪些线段覆盖它
#     # 但实际上我们可以在每个方案中动态计算
#
#     for mask in range(1 << m):
#         # 检查当前方案是否有效
#         valid = True
#
#         # 遍历所有关键区间
#         for i in range(len(key_points) - 1):
#             start = key_points[i]
#             end = key_points[i + 1]
#
#             # 如果区间超出范围，跳过
#             if start > n:
#                 break
#             if end <= 1:
#                 continue
#
#             # 实际有效的区间
#             actual_start = max(start, 1)
#             actual_end = min(end - 1, n)
#
#             if actual_start > actual_end:
#                 continue
#
#             # 取区间中的一个点来检查（比如actual_start）
#             point = actual_start
#
#             # 计算这个点被多少条选中的线段覆盖
#             cover_count = 0
#             for j in range(m):
#                 if mask & (1 << j):
#                     s, e = segments[j]
#                     if s <= point <= e:
#                         cover_count += 1
#
#             if cover_count < 2:
#                 valid = False
#                 break
#
#         if valid:
#             total_valid = (total_valid + 1) % MOD
#
#     print(total_valid)
#
#
# if __name__ == "__main__":
#     main()

#
# 收集金币
# 现有一个
# n
# 行
# m
# 列的网格迷宫，每个方格要么是可以通过的空方格，要么是不可通过的墙方格，迷宫的四周边界外都是墙方格。初始时，迷宫中不存在墙方格。
# 我们使用(i, j)
# 表示网格中从上往下数第
# i
# 行和从左往右数第
# j
# 列的方格，里面有
# a_(i, j)
# 个金币。
# 在开始移动前，小K已经知道了
# t
# 条信息，每条信息以一个三元组
# {x, y, v}
# 表示，代表(x, y)
# 方格会在第
# v
# 回合永久变成墙方格（在此之前金币仍可收集）。每一回合开始时，方格先发生变化，小K再进行移动（特别地，如果起点在第一回合变为墙方格，视作小K不受影响）。
# 小K从左上角(1, 1)
# 方格出发，记当前所在的位置为(x, y)，每回合只能向右移动一格到达(x, y + 1)
# 或向下移动一格到达(x + 1, y)。每一个方格中的金币只能收集一次，请问小K最多能收集到多少金币？
# 输入描述：
#
# 输出描述：
# 输出一个整数，代表小K最多能收集到的金币数量。
# 示例1
# 输入例子：
# 3
# 3
# 1
# 100
# 100
# 1
# 100
# 100
# 1
# 1
# 1
# 3
# 1
# 1
# 1
# 1
# 2
# 1
# 2
# 2
# 2
# 输出例子：
# 5
# 示例2
# 输入例子：
# 3
# 3
# 1
# 100
# 100
# 100
# 100
# 100
# 100
# 100
# 100
# 2
# 2
# 1
# 1
# 1
# 2
# 1
# 输出例子：
# 1
#
# def main():
#     import sys
#     input = sys.stdin.read
#     data = input().split()
#
#     # 读取网格大小
#     n = int(data[0])
#     m = int(data[1])
#
#     # 读取金币网格
#     grid = []
#     index = 2
#     for i in range(n):
#         row = []
#         for j in range(m):
#             row.append(int(data[index]))
#             index += 1
#         grid.append(row)
#
#     # 读取墙信息数量
#     k = int(data[index])
#     index += 1
#
#     # 记录每个位置变成墙的时间，wall_time[i][j]表示(i+1,j+1)变成墙的时间
#     # 初始化为一个很大的数（表示永远不会变成墙）
#     wall_time = [[float('inf')] * m for _ in range(n)]
#
#     for _ in range(k):
#         r = int(data[index]) - 1  # 转换为0-indexed
#         c = int(data[index + 1]) - 1
#         t = int(data[index + 2])
#         index += 3
#         wall_time[r][c] = t
#
#     # dp[i][j] 表示到达(i,j)时能收集的最大金币数
#     # 使用-1表示无法到达
#     dp = [[-1] * m for _ in range(n)]
#
#     # 起点特殊处理
#     # 起点(0,0)的到达时间是0
#     # 即使wall_time[0][0] <= 0（实际上wall_time[0][0] >= 1），题目说明起点不受影响
#     dp[0][0] = grid[0][0]
#
#     # 填充dp表
#     for i in range(n):
#         for j in range(m):
#             if i == 0 and j == 0:
#                 continue
#
#             # 计算到达(i,j)的时间（回合数）
#             arrival_time = i + j  # 因为0-indexed，实际是(i+1)+(j+1)-2 = i+j
#
#             # 检查当前位置是否在到达前就变成了墙
#             # 如果arrival_time >= wall_time[i][j]，说明到达时已经是墙了
#             if arrival_time >= wall_time[i][j]:
#                 # 无法到达这个位置
#                 dp[i][j] = -1
#                 continue
#
#             # 可以到达，计算最大值
#             best = -1
#             # 从上方来
#             if i > 0 and dp[i - 1][j] != -1:
#                 best = max(best, dp[i - 1][j])
#             # 从左方来
#             if j > 0 and dp[i][j - 1] != -1:
#                 best = max(best, dp[i][j - 1])
#
#             if best != -1:
#                 dp[i][j] = best + grid[i][j]
#             else:
#                 dp[i][j] = -1
#
#     # 输出结果
#     result = dp[n - 1][m - 1]
#     if result == -1:
#         print(0)
#     else:
#         print(result)
#
#
# if __name__ == "__main__":
#     main()

