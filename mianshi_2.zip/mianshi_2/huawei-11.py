# 小心火烛的歪
# 小歪正在一个占地
# n×m
# 大小的草地上研究他的燃放烟花计划。其中，一些位置已经堆放了杂物，为了便于观察，我们将给出一个
# n×m
# 大小的字符矩阵描述草地。其中，堆放了杂物的位置使用数字
# 1
# 标注；其余位置使用数字
# 0
# 标注。
# 小歪已经做好了若干个烟花燃放计划，每一个计划均为一个
# n×m
# 大小的字符矩阵，一一对应草地的每一个方格。在这个计划中，将会被燃放烟花的地块使用数字
# 1
# 标注；没有烟花的地块使用数字
# 0
# 标注。
# 他想选择一些计划同时实施，如果某个地块在任意一个计划中被标注为燃放，那么这个地块就会真的燃放上烟花。小歪想要知道，是否存在这样一种选择方法，使得全部有杂物位置均不会燃放烟花，而没有杂物的位置全部燃放上烟花；如果存在，请输出最少数量的计划。
#
# 示例1
# 输入例子：
# 2
# 2
# 1
# 00
# 01
# 11
# 10
# 输出例子：
# 1
# 1
# 示例2
# 输入例子：
# 7
# 7
# 5
# 1110111
# 1111111
# 1100001
# 0101000
# 1100001
# 1111111
# 1110111
# 0001000
# 0000000
# 0000000
# 1000001
# 0000000
# 0000000
# 0001000
# 0000000
# 0000000
# 0011100
# 0000000
# 0011100
# 0000000
# 0000000
# 0000000
# 0000000
# 0000010
# 0000111
# 0000010
# 0000000
# 0000000
# 0000000
# 0000000
# 0010000
# 0010000
# 0010000
# 0000000
# 0000000
# 0000000
# 0000000
# 0010000
# 0010111
# 0010000
# 0000000
# 0000000
# 输出例子：
# 4
# 1
# 2
# 3
# 4
# 例子说明：
# 草地初始状态如下图所示。在这个样例中，选择
# 也是一个合法的答案。
#

# import sys
# import collections
#
#
# def solve():
#     """
#     使用位运算/暴力枚举解决“小心火烛的歪”问题。
#     """
#     try:
#         # 1. 读取输入 n, m, q
#         # n, m, q (1 <= n, m, q <= 7)
#         line = sys.stdin.readline().split()
#         if not line:
#             return
#         n, m, q = map(int, line)
#
#         # 2. 读取草地初始状态 S
#         S = []
#         for _ in range(n):
#             S.append(sys.stdin.readline().strip())
#
#         # 3. 读取 q 个计划 P
#         P = []
#         for _ in range(q):
#             plan = []
#             for _ in range(n):
#                 plan.append(sys.stdin.readline().strip())
#             P.append(plan)
#
#     except Exception:
#         # 容错处理
#         return
#
#     # 将 2D 矩阵压缩成 1D 列表进行处理，方便位运算后的检查
#     N_total = n * m
#
#     # 4. 预处理：确定目标燃放状态 T 和识别“坏计划”
#
#     # A. 目标燃放状态 T (一维化)：
#     # T[idx] = 1 - S[i][j]
#     Target = []
#     # R1_indices: 有杂物的位置的索引 (S[i][j] == '1')，这些位置最终必须为 0
#     R1_indices = []
#     # R0_indices: 无杂物的位置的索引 (S[i][j] == '0')，这些位置最终必须为 1
#     R0_indices = []
#
#     for i in range(n):
#         for j in range(m):
#             idx = i * m + j
#             if S[i][j] == '1':
#                 Target.append(0)
#                 R1_indices.append(idx)
#             else:  # S[i][j] == '0'
#                 Target.append(1)
#                 R0_indices.append(idx)
#
#     # B. 计划的一维化表示和坏计划标记
#     # P_1D[k] 存储第 k 个计划的一维化燃放状态 (字符串)
#     P_1D = []
#     # Bad_plans[k] = True 表示第 k 个计划自身违反了“有杂物位置不能燃放”的约束 (约束 1)
#     Bad_plans = [False] * q
#
#     for k in range(q):
#         plan_str = ""
#         is_bad = False
#         for i in range(n):
#             plan_str += P[k][i]
#
#         P_1D.append(plan_str)
#
#         # 检查约束 1: 计划自身不能在有杂物的位置燃放
#         for idx in R1_indices:
#             if plan_str[idx] == '1':
#                 is_bad = True
#                 break
#         Bad_plans[k] = is_bad
#
#     # 5. 暴力枚举所有 $2^q$ 种组合，寻找最优解
#
#     min_cuts = q + 1  # 最少计划数，初始化为一个不可能的值
#     best_mask = -1  # 存储最优组合的 mask
#
#     # 循环 $2^q$ 次，mask 表示选择的计划组合
#     for mask in range(1 << q):
#         # 统计当前组合选择的计划数量
#         current_cuts = bin(mask).count('1')
#
#         # 优化：如果当前组合比已找到的最优解使用的计划更多，则跳过
#         if current_cuts >= min_cuts and best_mask != -1:
#             continue
#
#         # 检查约束 1：组合中不能有任何“坏计划”
#         is_bad_combination = False
#         for k in range(q):
#             # 检查 mask 的第 k 位是否为 1 (即是否选择了第 k 个计划)
#             if (mask >> k) & 1:
#                 if Bad_plans[k]:
#                     is_bad_combination = True
#                     break
#
#         if is_bad_combination:
#             continue
#
#         # 检查约束 2：所有无杂物区必须被点燃 (即最终燃放状态在 R0_indices 处必须为 '1')
#
#         # Final_Fire_State 存储当前组合的最终燃放状态 (一维化，字符串)
#         Final_Fire_State = ['0'] * N_total
#
#         # 组合所有选中的计划
#         for k in range(q):
#             if (mask >> k) & 1:
#                 # 对选中的计划进行逻辑或
#                 for idx in range(N_total):
#                     if P_1D[k][idx] == '1':
#                         Final_Fire_State[idx] = '1'
#
#         # 检查是否满足约束 2: 所有 R0_indices 必须为 '1'
#         is_target_covered = True
#         for idx in R0_indices:
#             if Final_Fire_State[idx] == '0':
#                 is_target_covered = False
#                 break
#
#         if is_target_covered:
#             # 找到了一个合法的方案
#             if current_cuts < min_cuts:
#                 min_cuts = current_cuts
#                 best_mask = mask
#
#     # 6. 输出结果
#
#     if best_mask == -1:
#         # 如果不存在满足要求的方案，直接输出 -1 [cite: 15]
#         print("-1")
#     else:
#         # 输出最少数量 p [cite: 15]
#         print(min_cuts)
#
#         # 输出 p 个整数代表选择的计划编号 (编号从 1 开始) [cite: 15]
#         selected_plans = []
#         for k in range(q):
#             # 计划 k 的编号是 k + 1
#             if (best_mask >> k) & 1:
#                 selected_plans.append(str(k + 1))
#
#         print(" ".join(selected_plans))
#
#
# if __name__ == "__main__":
#     solve()

# 相差不超过k的最多数
# 给定一个包含 n 个正整数的数组 a_1,a_2,…,a_n。你需要从中选择若干个数（可以全部也可以一个都不选），使得在所选集合中任意两数的差的绝对值均不超过给定整数 k。
# 请输出能够选出的元素个数的最大值。
# 【名词解释】
# 若选出的元素集合为 S，则要求 max⁡(S)-min⁡(S)≦k。
# 输入描述：
# 第一行输入两个整数 n,k(1<=n<=2*10**5,1<=k<=10**9)。
# 第二行输入 n 个整数 ai,a2,…..,an(1<=ai<=10**9)。
# 输出描述：
# 输出一个整数，表示满足条件的最多可选元素数量。
# 示例1
# 输入例子：
# 5 3
# 2 1 5 3 2
# 输出例子：
# 4
# 例子说明：
# 选取元素集合{1,2,2,3}满足最大值与最小值之差为 3，且无法再加入 5。

# def main():
#     import sys
#     input = sys.stdin.read
#     data = input().split()
#
#     n = int(data[0])
#     k = int(data[1])
#     arr = list(map(int, data[2:2 + n]))
#
#     # 排序数组
#     arr.sort()
#
#     # 滑动窗口
#     left = 0
#     max_count = 0
#
#     for right in range(n):
#         # 如果窗口不满足条件，移动左指针
#         while arr[right] - arr[left] > k:
#             left += 1
#
#         # 更新最大窗口大小
#         max_count = max(max_count, right - left + 1)
#
#     print(max_count)
#
#
# if __name__ == "__main__":
#     main()

# 圆覆盖
# 在二维平面中给出
# n
# 个点，第
# i
# 个点的坐标为(x_i, y_i)，其点权为
# v_i。你可以以原点(0, 0)
# 为圆心放置一个圆。
# 设圆的半径为
# r，若某点满足
# x_i ^ 2 + y_i ^ 2≦r ^ 2，则认为该点被圆覆盖。请你计算：
# ∙" "
# 要使被覆盖点的权值和不少于给定整数
# S，所需的最小半径
# r
# 是多少？
# 若无论半径多大都无法达到权值下限，则输出 - 1。
#
# 示例1
# 输入例子：
# 5
# 10
# 0
# 1
# 2
# -1
# 1
# 3
# 3
# 3
# 4
# -4
# 3
# 1
# 5 - 3
# 1
# 输出例子：
# 5
# 示例2
# 输入例子：
# 5
# 10
# 0
# 1
# 2
# -1
# 1
# 3
# 3
# 3
# 2
# -4
# 3
# 1
# 5 - 3
# 1
# 输出例子：
# -1
#
# import math
#
#
# def main():
#     n, S = map(int, input().split())
#
#     points = []
#     total_weight = 0
#
#     for _ in range(n):
#         x, y, w = map(int, input().split())
#         dist = math.sqrt(x * x + y * y)
#         points.append((dist, w))
#         total_weight += w
#
#     if total_weight < S:
#         print(-1)
#         return
#
#     points.sort()
#
#     current_weight = 0
#     for dist, w in points:
#         current_weight += w
#         if current_weight >= S:
#             # 四舍五入到最近的整数（题目示例都是整数）
#             print(round(dist))
#             return
#
#
# if __name__ == "__main__":
#     main()
