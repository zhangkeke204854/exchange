# 最高分是多少
# 老师想知道从某某同学当中，分数最高的是多少，现在请你编程模拟老师的询问。当然，老师有时候需要更新某位同学的成绩.
# 输入描述：
# 每组输入第一行是两个正整数N和M（0 < N <= 30000,0 < M < 5000）,分别代表学生的数目和操作的数目。
# 学生ID编号从1编到N。
# 第二行包含N个整数，代表这N个学生的初始成绩，其中第i个数代表ID为i的学生的成绩
# 接下来又M行，每一行有一个字符C（只取‘Q’或‘U’），和两个正整数A,B,当C为'Q'的时候, 表示这是一条询问操作，假设A
# 输出描述：
# 对于每一次询问操作，在一行里面输出最高成绩.
# 示例1
# 输入例子：
# 5 7
# 1 2 3 4 5
# Q 1 5
# U 3 6
# Q 3 4
# Q 4 5
# U 4 5
# U 2 9
# Q 1 5
# 输出例子：
# 5
# 6
# 5
# 9
# 示例2
# 输入例子：
# 3 2
# 1 2 3
# U 2 8
# Q 3 1
# 输出例子：
# 8

#
# class SegmentTree:
#     def __init__(self, data):
#         self.n = len(data)
#         self.tree = [0] * (4 * self.n)
#         self.build(data, 0, 0, self.n - 1)
#
#     def build(self, data, node, start, end):
#         if start == end:
#             self.tree[node] = data[start]
#         else:
#             mid = (start + end) // 2
#             self.build(data, 2 * node + 1, start, mid)
#             self.build(data, 2 * node + 2, mid + 1, end)
#             self.tree[node] = max(self.tree[2 * node + 1], self.tree[2 * node + 2])
#
#     def update(self, idx, value, node=0, start=0, end=None):
#         if end is None:
#             end = self.n - 1
#         if start == end:
#             self.tree[node] = value
#         else:
#             mid = (start + end) // 2
#             if idx <= mid:
#                 self.update(idx, value, 2 * node + 1, start, mid)
#             else:
#                 self.update(idx, value, 2 * node + 2, mid + 1, end)
#             self.tree[node] = max(self.tree[2 * node + 1], self.tree[2 * node + 2])
#
#     def query(self, left, right, node=0, start=0, end=None):
#         if end is None:
#             end = self.n - 1
#         if right < start or end < left:
#             return float('-inf')
#         if left <= start and end <= right:
#             return self.tree[node]
#         mid = (start + end) // 2
#         left_max = self.query(left, right, 2 * node + 1, start, mid)
#         right_max = self.query(left, right, 2 * node + 2, mid + 1, end)
#         return max(left_max, right_max)
#
# def main():
#     line = input().split()
#     n = int(line[0])
#     m = int(line[1])
#
#     scores = list(map(int, input().split()))
#
#     # 构建线段树，注意学生ID从1开始，数组从0开始
#     seg_tree = SegmentTree(scores)
#
#     for _ in range(m):
#         parts = input().split()
#         op = parts[0]
#         a = int(parts[1])
#         b = int(parts[2])
#
#         if op == 'Q':
#             # 查询操作，注意A和B可能A>B，需要取区间
#             left = min(a, b) - 1  # 转换为0-based索引
#             right = max(a, b) - 1
#             result = seg_tree.query(left, right)
#             print(result)
#         elif op == 'U':
#             # 更新操作，将学生a的成绩更新为b
#             idx = a - 1  # 转换为0-based索引
#             seg_tree.update(idx, b)
#
# if __name__ == "__main__":
#     main()
#
# 简单错误记录
# 开发一个简单错误记录功能小模块，能够记录出错的代码所在的文件名称和行号。
# 处理:
# 1.记录最多8条错误记录，对相同的错误记录(即文件名称和行号完全匹配)只记录一条，错误计数增加；(文件所在的目录不同，文件名和行号相同也要合并)
# 2.超过16个字符的文件名称，只记录文件的最后有效16个字符；(如果文件名不同，而只是文件名的后16个字符和行号相同，也不要合并)
# 3.输入的文件可能带路径，记录文件名称不能带路径
# 数据范围：输入错误记录数量满足 1≤n≤1000，每条记录的长度满足 1≤len≤50" 					"
# 输入描述：
# 一行或多行字符串。每行包括带路径文件名称，行号，以空格隔开。
#
#     文件路径为windows格式
#
#     如：E:\V1R2\product\fpgadrive.c 1325
# 输出描述：
# 将所有的记录统计并将结果输出，格式：文件名代码行数数目，一个空格隔开，如: fpgadrive.c 1325 1
#
#     结果根据数目从多到少排序，数目相同的情况下，按照输入第一次出现顺序排序。
#
#     如果超过8条记录，则只输出前8条记录.
#
#     如果文件名的长度超过16个字符，则只输出后16个字符
# 示例1
# 输入例子：
# E:\V1R2\product\fpgadrive.c 1325
# 输出例子：
# fpgadrive.c 1325 1
#
# def main():
#     records = {}
#     input_order = []
#
#     # 读取输入
#     import sys
#     lines = []
#     for line in sys.stdin:
#         line = line.strip()
#         if line:
#             lines.append(line)
#
#     for line in lines:
#         # 分割路径和行号
#         parts = line.rsplit(' ', 1)
#         if len(parts) != 2:
#             continue
#
#         file_path, line_num = parts[0], parts[1]
#
#         # 提取文件名
#         if '\\' in file_path:
#             file_name = file_path.split('\\')[-1]
#         else:
#             file_name = file_path
#
#         # 截取后16个字符
#         if len(file_name) > 16:
#             file_name = file_name[-16:]
#
#         key = (file_name, line_num)
#         if key not in records:
#             records[key] = 0
#             input_order.append(key)
#         records[key] += 1
#
#     # 准备结果列表
#     results = []
#     for key in input_order:
#         file_name, line_num = key
#         count = records[key]
#         results.append((file_name, line_num, count))
#
#     # 按计数降序排序
#     results.sort(key=lambda x: x[2], reverse=True)
#
#     # 输出前8条
#     for i in range(min(8, len(results))):
#         print(f"{results[i][0]} {results[i][1]} {results[i][2]}")
#
#
# if __name__ == "__main__":
#     main()

# 扑克牌大小
# 扑克牌游戏大家应该都比较熟悉了，一副牌由54张组成，含3~A，2各4张，小王1张，大王1张。牌面从小到大用如下字符和字符串表示（其中，小写joker表示小王，大写JOKER表示大王）:)
# 3 4 5 6 7 8 9 10 J Q K A 2 joker JOKER
# 输入两手牌，两手牌之间用“-”连接，每手牌的每张牌以空格分隔，“-”两边没有空格，如：4 4 4 4-joker JOKER
# 请比较两手牌大小，输出较大的牌，如果不存在比较关系则输出ERROR
#
# 基本规则：
# （1）输入每手牌可能是个子，对子，顺子（连续5张），三个，炸弹（四个）和对王中的一种，不存在其他情况，由输入保证两手牌都是合法的，顺子已经从小到大排列；
# （2）除了炸弹和对王可以和所有牌比较之外，其他类型的牌只能跟相同类型的存在比较关系（如，对子跟对子比较，三个跟三个比较），不考虑拆牌情况（如：将对子拆分成个子）
# （3）大小规则跟大家平时了解的常见规则相同，个子，对子，三个比较牌面大小；顺子比较最小牌大小；炸弹大于前面所有的牌，炸弹之间比较牌面大小；对王是最大的牌；
# （4）输入的两手牌不会出现相等的情况。
# 答案提示：
# （1）除了炸弹和对王之外，其他必须同类型比较。
# （2）输入已经保证合法性，不用检查输入是否是合法的牌。
# （3）输入的顺子已经经过从小到大排序，因此不用再排序了.
#
# 数据范围：保证输入合法
# 输入描述：
# 输入两手牌，两手牌之间用“-”连接，每手牌的每张牌以空格分隔，“-”两边没有空格，如4 4 4 4-joker JOKER。
# 输出描述：
# 输出两手牌中较大的那手，不含连接符，扑克牌顺序不变，仍以空格隔开；如果不存在比较关系则输出ERROR。
# 示例1
# 输入例子：
# 4 4 4 4-joker JOKER
# 输出例子：
# joker JOKER


# def get_card_value(card):
#     """获取单张牌的数值大小"""
#     card_order = ['3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A', '2', 'joker', 'JOKER']
#     return card_order.index(card)
#
#
# def get_hand_type(hand):
#     """判断手牌类型"""
#     n = len(hand)
#
#     # 对王
#     if n == 2 and set(hand) == {'joker', 'JOKER'}:
#         return 'pair_king'
#
#     # 炸弹
#     if n == 4 and len(set(hand)) == 1:
#         return 'bomb'
#
#     # 顺子（5张连续）
#     if n == 5:
#         # 检查是否连续
#         values = [get_card_value(card) for card in hand]
#         if values == list(range(values[0], values[0] + 5)):
#             return 'straight'
#
#     # 个子
#     if n == 1:
#         return 'single'
#
#     # 对子
#     if n == 2 and len(set(hand)) == 1:
#         return 'pair'
#
#     # 三个
#     if n == 3 and len(set(hand)) == 1:
#         return 'three'
#
#     # 如果都不符合，可能是其他情况，但题目保证输入合法
#     return 'unknown'
#
#
# def compare_hands(hand1, hand2):
#     """比较两手牌大小，返回较大的手牌，如果无法比较返回None"""
#     type1 = get_hand_type(hand1)
#     type2 = get_hand_type(hand2)
#
#     # 对王是最大的
#     if type1 == 'pair_king':
#         return hand1
#     if type2 == 'pair_king':
#         return hand2
#
#     # 炸弹可以和任何牌比较
#     if type1 == 'bomb' and type2 != 'pair_king':
#         return hand1
#     if type2 == 'bomb' and type1 != 'pair_king':
#         return hand2
#
#     # 如果都不是对王或炸弹，必须同类型才能比较
#     if type1 != type2:
#         return None
#
#     # 同类型比较
#     if type1 == 'single':
#         return hand1 if get_card_value(hand1[0]) > get_card_value(hand2[0]) else hand2
#
#     elif type1 == 'pair':
#         return hand1 if get_card_value(hand1[0]) > get_card_value(hand2[0]) else hand2
#
#     elif type1 == 'three':
#         return hand1 if get_card_value(hand1[0]) > get_card_value(hand2[0]) else hand2
#
#     elif type1 == 'bomb':
#         return hand1 if get_card_value(hand1[0]) > get_card_value(hand2[0]) else hand2
#
#     elif type1 == 'straight':
#         # 顺子比较最小牌
#         return hand1 if get_card_value(hand1[0]) > get_card_value(hand2[0]) else hand2
#
#     return None
#
#
# def main():
#     line = input().strip()
#     hand1_str, hand2_str = line.split('-')
#     hand1 = hand1_str.split()
#     hand2 = hand2_str.split()
#
#     result = compare_hands(hand1, hand2)
#
#     if result is None:
#         print("ERROR")
#     else:
#         print(' '.join(result))
#
#
# if __name__ == "__main__":
#     main()


