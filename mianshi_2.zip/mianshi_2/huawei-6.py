# 从单向链表中删除指定值的节点
# 定义一种单向链表的构造方法如下所示：
# ∙" " 先输入一个整数 n ，代表链表中节点的总数；
# ∙" " 再输入一个整数 h ，代表头节点的值；
# ∙" " 此后输入 n-1 个二元组 (a,b) ，表示在值为 b 的节点后插入值为 a 的节点。
# 除此之外，保证输入的链表中不存在重复的节点值。
# 现在，对于给定的链表构造方法和一个额外的整数 k ，你需要先按照上述构造方法构造出链表，随后删除值为 k 的节点，输出剩余的链表。
# 输入描述：
#  在一行上：
#  先输入一个整数 n(1<=n<=10**3) 代表链表中节点的总数；
#  随后输入一个整数 h(1<=h<=10**4)  代表头节点的值；
#  随后输入 n-1 个二元组 (a,b)(1<=a,b<=10**4) ；
#  最后输入一个整数k，代表需要删除的节点值。
#
#  除此之外，保证每一个 b 值在输入前已经存在于链表中；每一个 a 值在输入前均不存在于链表中。节点的值各不相同。
# 输出描述：
#  在一行上输出n-1个整数，代表删除指定元素后剩余的链表。
# 补充说明：
#  本题由牛客重构过题面，您可能想要阅读原始题面，我们一并附于此处。
#  【以下为原始题面】
# 输入一个单向链表和一个节点的值，从单向链表中删除等于该值的节点，删除后如果链表中无节点则返回空指针。
# 链表的值不能重复。
# 构造过程，例如输入一行数据为:
# 6 2 1 2 3 2 5 1 4 5 7 2 2
# 则第一个参数6表示输入总共6个节点，第二个参数2表示头节点值为2，剩下的2个一组表示第2个节点值后面插入第1个节点值，为以下表示:
# 1 2 表示为
# 2->1
# 链表为2->1
#
# 3 2表示为
# 2->3
# 链表为2->3->1
#
# 5 1表示为
# 1->5
# 链表为2->3->1->5
#
# 4 5表示为
# 5->4
# 链表为2->3->1->5->4
#
# 7 2表示为
# 2->7
# 链表为2->7->3->1->5->4
#
# 最后的链表的顺序为 2 7 3 1 5 4
#
# 最后一个参数为2，表示要删掉节点为2的值
# 删除 结点 2
# 则结果为 7 3 1 5 4
#
# 数据范围：链表长度满足 1<=n<=1000 ，节点中的值满足 0<=ual<=10000
#
# 测试用例保证输入合法
# 示例1
# 输入例子：
# 5 2 3 2 4 3 5 2 1 4 3
# 输出例子：
# 2 5 4 1
# 示例2
# 输入例子：
# 6 2 1 2 3 2 5 1 4 5 7 2 2
# 输出例子：
# 7 3 1 5 4
#
# def main():
#     data = list(map(int, input().split()))
#
#     n = data[0]
#     head = data[1]
#     k = data[-1]  # 要删除的节点值
#
#     # 构建链表的next关系
#     next_node = {}
#
#     # 处理n-1个插入操作
#     for i in range(n - 1):
#         a = data[2 + 2 * i]  # 要插入的节点
#         b = data[2 + 2 * i + 1]  # 插入位置的节点
#
#         # 在b后面插入a
#         next_node[a] = next_node.get(b)  # a的next是b原来的next
#         next_node[b] = a  # b的next现在是a
#
#     # 现在处理删除操作
#     # 首先确定头节点
#     current_head = head
#
#     # 如果要删除的是头节点
#     if current_head == k:
#         new_head = next_node.get(current_head)
#     else:
#         # 找到要删除节点的前驱
#         prev = current_head
#         while prev is not None and next_node.get(prev) != k:
#             prev = next_node.get(prev)
#
#         if prev is not None:
#             # 删除k节点
#             next_node[prev] = next_node.get(k)
#         new_head = current_head
#
#     # 输出结果
#     result = []
#     current = new_head
#     while current is not None:
#         result.append(str(current))
#         current = next_node.get(current)
#
#     print(' '.join(result))
#
#
# if __name__ == "__main__":
#     main()

# 迷宫
# 给定一个 n×m 的迷宫，迷宫由 "#" 与"." 两种字符组成。其中 "#" 代表障碍物，"." 表示空地。迷宫中还有一个起点 "S" 和一个终点 "E" ，它们都可以视为空地。
# 由于近期迷宫发生了塌方，导致起点和终点之间可能并不连通。幸运的是，你拥有一种超能力——在迷宫中移动时（移动方向为上、下、左、右四个方向之一），可以在当前位置朝任一方向（上、下、左、右四个方向之一）释放激光。激光能够清除该方向上所有的障碍物，并且这种超能力至多只能使用一次。
# 现在，你需要判断是否能利用这种超能力成功从起点到达终点。
# 输入描述：
# 第一行给定两个整数n,m(2<=n,m<=1000)，分别表示迷宫的行数和列数。
# 下面n行，每行m个字符，描述迷宫的具体布局。字符只包含 "#"、"."、"S" 和 "E"，并且起点与终点有且仅有一个。
# 输出描述：
# 能够到达终点输出 YES ；否则输出NO。
# 示例1
# 输入例子：
# 4 5
# .####
# S####
# .####
# .E###
# 输出例子：
# YES
# 示例2
# 输入例子：
# 4 5
# ..###
# S####
# #####
# ##.E#
# 输出例子：
# YES
# 例子说明：
# 显然可以从起点出发，到达(1,2)处并向下方使用超能力，此时可以从起点到达终点。
# 示例3
# 输入例子：
# 4 5
# ..###
# S####
# #####
# ###E#
# 输出例子：
# NO
#
# from collections import deque
#
#
# def bfs(grid, start, n, m):
#     """BFS找到所有可达位置（不穿过障碍物）"""
#     visited = [[False] * m for _ in range(n)]
#     queue = deque([start])
#     visited[start[0]][start[1]] = True
#     reachable = set()
#     reachable.add(start)
#
#     directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
#
#     while queue:
#         x, y = queue.popleft()
#         for dx, dy in directions:
#             nx, ny = x + dx, y + dy
#             if 0 <= nx < n and 0 <= ny < m and not visited[nx][ny]:
#                 if grid[nx][ny] != '#':
#                     visited[nx][ny] = True
#                     reachable.add((nx, ny))
#                     queue.append((nx, ny))
#
#     return reachable
#
#
# def main():
#     n, m = map(int, input().split())
#     grid = []
#     start = None
#     end = None
#
#     for i in range(n):
#         row = input().strip()
#         grid.append(row)
#         for j in range(m):
#             if row[j] == 'S':
#                 start = (i, j)
#             elif row[j] == 'E':
#                 end = (i, j)
#
#     # 如果起点终点相同（理论上不会发生，但安全起见）
#     if start == end:
#         print("YES")
#         return
#
#     # BFS从起点和终点
#     start_reach = bfs(grid, start, n, m)
#     end_reach = bfs(grid, end, n, m)
#
#     # 检查是否直接可达
#     if end in start_reach:
#         print("YES")
#         return
#
#     # 四个方向
#     directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
#
#     # 对于每个起点可达的位置
#     for sx, sy in start_reach:
#         # 尝试四个方向发射激光
#         for dx, dy in directions:
#             # 沿着这个方向走
#             x, y = sx + dx, sy + dy
#             while 0 <= x < n and 0 <= y < m:
#                 # 如果当前位置是障碍物，激光会清除它，继续前进
#                 if grid[x][y] == '#':
#                     x += dx
#                     y += dy
#                     continue
#                 else:
#                     # 遇到了非障碍物位置，检查是否在终点可达区域
#                     if (x, y) in end_reach:
#                         print("YES")
#                         return
#                     # 对于非障碍物，激光不会影响其他方向，所以这个方向就到这里
#                     break
#
#     print("NO")
#
#
# if __name__ == "__main__":
#     main()

#
# 三角形取数(Hard
# Version)
# 给定一个由
# n
# 行构成的数字三角形。第
# i
# 行共有
# 2
# i - 1
# 个整数，整体形状如下图所示（以
# n = 3
# 为例）：
#
# 从顶点（第一行唯一的数字）出发，依次向下移动恰好
# n - 1
# 次直到抵达最后一行。
# 假设当前位于第
# i
# 行第
# j
# 列：
# 〖_
# "1." 〗" "
# 可以向正下方移动至第(i + 1)
# 行第
# j
# 列；
# 〖_
# "2." 〗" "
# 可以向左下方移动至第(i + 1)
# 行第(j - 1)
# 列；
# 〖_
# "3." 〗" "
# 可以向右下方移动至第(i + 1)
# 行第(j + 1)
# 列。
# 每到达一个位置都会获得该位置的数值。定义在整个行走过程中，向左下方移动的次数记为
# l，向右下方移动的次数记为
# r。我们需要满足
# ∣l - r∣≦k
# 请你选择一条合法路径，使得获得数值之和最大，并输出该最大值。
# 输入描述：
# 在一行上输入两个整数
# n, k(1 <= n <= 300;
# 0 <= k <= n)，分别表示数字三角形的行数与允许的移动差。
# 此后n
# 行，第i行输入2i - 1
# 个整数
# ai, 1, ai, 2,…., ai, 2
# i - 1(-2 * 10 ** 9 <= ai, j <= 2 * 10 ** 9)
# 共计
# n ** 2
# 个整数。
# 输出描述：
# 输出一个整数，表示满足条件的路径可以取得的最大数值之和。
# 示例1
# 输入例子：
# 3
# 1
# 1
# 2
# 3
# 4
# 5
# 6
# 7
# 8
# 9
# 输出例子：
# 13
# 示例2
# 输入例子：
# 3
# 0
# 1
# 2
# 3
# 4
# 5
# 6
# 7
# 8
# 9
# 输出例子：
# 12
#
# def main():
#     import sys
#     input = sys.stdin.read
#     data = input().split()
#
#     n = int(data[0])
#     k = int(data[1])
#
#     # 读取三角形
#     triangle = []
#     index = 2
#     for i in range(n):
#         row = []
#         for j in range(2 * i + 1):
#             row.append(int(data[index]))
#             index += 1
#         triangle.append(row)
#
#     # DP数组，使用字典或列表
#     # 第i行最多有2*i+1个元素
#     dp = [[-float('inf')] * (2 * n) for _ in range(n)]
#
#     # 初始化
#     dp[0][0] = triangle[0][0]
#
#     # DP转移
#     for i in range(n - 1):
#         for j in range(2 * i + 1):
#             if dp[i][j] == -float('inf'):
#                 continue
#             current_val = dp[i][j]
#             # 左下方: (i+1, j)
#             if j < 2 * (i + 1) + 1:
#                 dp[i + 1][j] = max(dp[i + 1][j], current_val + triangle[i + 1][j])
#             # 正下方: (i+1, j+1)
#             if j + 1 < 2 * (i + 1) + 1:
#                 dp[i + 1][j + 1] = max(dp[i + 1][j + 1], current_val + triangle[i + 1][j + 1])
#             # 右下方: (i+1, j+2)
#             if j + 2 < 2 * (i + 1) + 1:
#                 dp[i + 1][j + 2] = max(dp[i + 1][j + 2], current_val + triangle[i + 1][j + 2])
#
#     # 在最后一行找满足约束的最大值
#     last_row = n - 1
#     max_sum = -float('inf')
#     for j in range(2 * n - 1):
#         if abs(last_row - j) <= k:
#             max_sum = max(max_sum, dp[last_row][j])
#
#     print(max_sum)
#
#
# if __name__ == "__main__":
#     main()







