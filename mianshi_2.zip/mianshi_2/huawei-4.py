# 查找兄弟单词
# 定义一个字符串 s 的“兄弟单词”为：将 s 重新排序后得到的与原字符串不同的新字符串。
# 现在，对于给定的 n 个字符串 s_1,s_2,…,s_n 和另一个单独的字符串 x，你需要解决两个问题：
# ∙" " 统计这 n 个字符串中，有多少个是 x 的“兄弟单词”（注意，这 n 个字符串可能有重复，重复字符串分别计数）；
# ∙" " 将这 n 个字符串中 x 的“兄弟单词”按字典序从小到大排序，输出排序后的第 k 个兄弟单词（从 1 开始计数）。特别地，如果不存在，则不输出任何内容。
# 【名词解释】
# 从字符串的第一个字符开始逐个比较，直至发现第一个不同的位置，比较这个位置字符的字母表顺序，字母序较小的字符串字典序也较小；如果比较到其中一个字符串的结尾时依旧全部相同，则较短的字符串字典序更小。
# 输入描述：
#  在一行上依次输入：
#  一个整数 n(1<=n<=10**3) 代表字符串的个数；
#  n个长度为1<=length(si)<=10 ，仅由小写字母构成的字符串s1,s2….,sn ；
#  一个长度为 1<=length(x)<=10 ，仅由小写字母构成的字符串 x ；
#  一个整数k(1<=k<=n)代表要查找的第 k 小的兄弟单词的序号。
# 输出描述：
# 第一行输出一个整数，代表给定的 n 个字符串中，x 的“兄弟单词”的数量；
# 第二行输出一个字符串，代表将给定的n个字符串中 x的“兄弟单词”按字典序排序后的第k小兄弟单词。特别地，如果不存在，则不输出任何内容（完全省略第二行）。
# 示例1
# 输入例子：
# 3 abc bca cab abc 1
# 输出例子：
# 2
# bca
# 示例2
# 输入例子：
# 3 a aa aaa a 1
# 输出例子：
# 0
# def main():
#     line = input().split()
#
#     # 解析输入
#     n = int(line[0])
#     strings = line[1:1 + n]  # n个字符串
#     x = line[1 + n]  # 目标字符串
#     k = int(line[1 + n + 1])  # 第k个
#
#     # 找出所有兄弟单词
#     brother_words = []
#     x_sorted = sorted(x)
#     x_len = len(x)
#
#     for s in strings:
#         # 检查是否为兄弟单词
#         if len(s) == x_len and sorted(s) == x_sorted and s != x:
#             brother_words.append(s)
#
#     # 按字典序排序
#     brother_words.sort()
#
#     # 输出结果
#     count = len(brother_words)
#     print(count)
#
#     # 如果存在第k个兄弟单词，则输出
#     if count >= k:
#         print(brother_words[k - 1])
#
#
# if __name__ == "__main__":
#     main()
#
# 小苯的IDE括号问题（easy）
# 在一款智能代码编辑器中，光标用字符 I 表示。初始时给出一个只包含字符 "(" 、")" 、"I"  的括号串，其中 恰好出现一次 I 作为光标位置。编辑器支持下列两种删除操作：
# 〖_"1." 〗" "  backspace：
# ∘" " 若光标左侧字符为 `(`，且光标右侧紧跟字符为 `)`，编辑器会一次性删除这对括号；
# ∘" " 否则，若光标左侧仍有字符，则仅删除光标左侧一个字符；若左侧为空则无效果。
# 〖_"2." 〗" "  delete：
# ∘" " 若光标右侧存在字符，则删除光标右侧第一个字符；否则无效果。
# 给定初始括号串以及 k 次操作序列（每次为 backspace 或 delete），请输出全部操作执行完毕后的最终字符串。
# 输入描述：
#  第一行输入两个整数n,k(1<=k<=n<=2*10**5)——初始字符串长度及操作次数。
#  第二行输入长度为n的字符串 s，仅包含 `(`, `)` 与 `I`，其中 I 恰好出现一次。
#  接下来 k 行，每行输入一个操作类型：backspace 或 delete。
# 输出描述：
#  输出一行字符串，表示所有操作结束后的括号串。
# 示例1
# 输入例子：
# 10 3
# ((()(I))((
# backspace
# backspace
# delete
# 输出例子：
# (((I((
# 示例2
# 输入例子：
# 5 3
# ((I))
# backspace
# backspace
# delete
# 输出例子：
# I
# 例子说明：
# 显然括号都被删除完了。
#
# def main():
#     n, k = map(int, input().split())
#     s = input().strip()
#
#     # 找到光标位置并分离字符
#     cursor_pos = s.index('I')
#     chars = list(s[:cursor_pos] + s[cursor_pos + 1:])
#
#     # 处理k个操作
#     for _ in range(k):
#         operation = input().strip()
#
#         if operation == "backspace":
#             # 检查是否可以删除括号对
#             if (cursor_pos > 0 and
#                     cursor_pos < len(chars) and
#                     chars[cursor_pos - 1] == '(' and
#                     chars[cursor_pos] == ')'):
#                 # 删除括号对：先删右侧')'，再删左侧'('
#                 del chars[cursor_pos]
#                 del chars[cursor_pos - 1]
#                 cursor_pos -= 1
#             else:
#                 # 删除左侧单个字符
#                 if cursor_pos > 0:
#                     del chars[cursor_pos - 1]
#                     cursor_pos -= 1
#
#         elif operation == "delete":
#             # 删除右侧字符
#             if cursor_pos < len(chars):
#                 del chars[cursor_pos]
#
#     # 重构结果字符串
#     result = ''.join(chars[:cursor_pos]) + 'I' + ''.join(chars[cursor_pos:])
#     print(result)
#
#
# if __name__ == "__main__":
#     main()


# 山峰数组计数
# 定义一个山峰数组为长度为 3 的数组 [a_1,a_2,a_3]，满足 a_1<a_2 且 a_2>a_3。
# 给定一个长度为 n 的正整数数组 P，你需要选择两个下标 i,j(1≦i<j<n)，并将 P 划分成三个非空连续子数组：
# ∙" "  b_1=∑_(k=1)^i P_k；
# ∙" "  b_2=∑_(k=i+1)^j P_k；
# ∙" "  b_3=∑_(k=j+1)^n P_k。
# 若三元组 [b_1,b_2,b_3] 构成一个山峰数组，则称二元组 (i,j) 可行。请计算共有多少个不同的可行二元组 (i,j)。
# 输入描述：
#  第一行输入一个整数 n(3<=n<=2*10**5)，表示数组 P的长度。
#
#  第二行输入 n 个整数 P1,P2,….,Pn(1<=Pi<=10**6)，表示数组元素。
# 输出描述：
#  输出一个整数，表示可行二元组的数量。
# 示例1
# 输入例子：
# 5
# 1 2 3 4 5
# 输出例子：
# 2
#
# import bisect
#
#
# def main():
#     n = int(input().strip())
#     p = list(map(int, input().split()))
#
#     # 计算前缀和
#     prefix = [0] * (n + 1)
#     for i in range(n):
#         prefix[i + 1] = prefix[i] + p[i]
#
#     total = prefix[n]
#     count = 0
#
#     # 遍历所有可能的i
#     for i in range(1, n - 1):  # i从1到n-2
#         sumA = prefix[i]
#
#         # 计算prefix[j]需要满足的条件
#         # 条件1: prefix[j] > 2 * sumA
#         # 条件2: prefix[j] > (total + sumA) / 2
#         min_val1 = 2 * sumA
#         min_val2 = (total + sumA) / 2
#
#         min_prefix_j = max(min_val1, min_val2)
#
#         # 在prefix[i+1:n]中查找第一个大于min_prefix_j的位置
#         # prefix数组索引从i+1到n-1对应j从i+1到n-1
#         # 使用bisect_right找到第一个大于min_prefix_j的位置
#         pos = bisect.bisect_right(prefix, min_prefix_j, lo=i + 1, hi=n)
#
#         # 满足条件的j的数量是从pos到n-1
#         if pos <= n - 1:
#             count += (n - pos)
#
#     print(count)
#
#
# if __name__ == "__main__":
#     main()
