# DBSCAN聚类
# 任务: 用DBSCAN在二维或三维实数坐标上做聚类，输出“簇的数量”和“噪声点数量”。
# 定义: 距离为欧氏距离；某点的邻域半径为eps；若该点邻域内样本数（含自身）≥ min_samples，则为核心点；从未访问核心点出发，按邻域可达关系扩展一个簇；不被任何簇吸收的点视为噪声
# 输入描述：
# 第一行: eps min_samples x
# 接下来x行: 每行2个或3个实数（同一测试仅一种维度）
# 输出描述：
# 一行: 簇数 噪声点数
# 补充说明：
# 约定: 邻域判定使用距离≤eps；核心点计数包含自身。
# 示例1
# 输入例子：
# 1.5 2 6
# 0 0
# 0.5 0
# 0 0.5
# 10 10
# 10.5 10
# 10 10.5
# 输出例子：
# 2 0
# 例子说明：
# 前3个点彼此间距都≤1.5，形成一簇；后3个点同理形成另一簇；无噪声。
#
# import sys
# from collections import deque
# import math
#
#
# def euclidean_distance(p1, p2):
#     """计算两点间的欧氏距离"""
#     return math.sqrt(sum((a - b) ** 2 for a, b in zip(p1, p2)))
#
#
# def main():
#     data = sys.stdin.read().split()
#     if not data:
#         return
#
#     # 解析第一行
#     eps = float(data[0])
#     min_samples = int(data[1])
#     x = int(data[2])
#
#     # 解析坐标点
#     points = []
#     index = 3
#     dim = 2 if len(data) == 3 + 2 * x else 3
#
#     for i in range(x):
#         if dim == 2:
#             point = (float(data[index]), float(data[index + 1]))
#             index += 2
#         else:
#             point = (float(data[index]), float(data[index + 1]), float(data[index + 2]))
#             index += 3
#         points.append(point)
#
#     n = len(points)
#
#     # 预计算每个点的邻居（距离 <= eps）
#     neighbors = []
#     for i in range(n):
#         neighbor_list = []
#         for j in range(n):
#             if i != j and euclidean_distance(points[i], points[j]) <= eps:
#                 neighbor_list.append(j)
#         neighbors.append(neighbor_list)
#
#     # 判断核心点
#     is_core = []
#     for i in range(n):
#         # 核心点条件：邻居数 + 自身 >= min_samples
#         if len(neighbors[i]) + 1 >= min_samples:
#             is_core.append(True)
#         else:
#             is_core.append(False)
#
#     # 聚类
#     labels = [-1] * n  # -1表示未访问，-2表示噪声，>=0表示簇ID
#     cluster_id = 0
#
#     for i in range(n):
#         if labels[i] != -1:  # 已访问过
#             continue
#
#         if not is_core[i]:  # 非核心点暂时标记为噪声
#             labels[i] = -2
#             continue
#
#         # BFS扩展簇
#         queue = deque([i])
#         labels[i] = cluster_id
#
#         while queue:
#             current = queue.popleft()
#
#             # 遍历当前点的所有邻居
#             for neighbor in neighbors[current]:
#                 if labels[neighbor] == -1:  # 未访问
#                     labels[neighbor] = cluster_id
#                     # 如果邻居是核心点，继续扩展
#                     if is_core[neighbor]:
#                         queue.append(neighbor)
#                 elif labels[neighbor] == -2:  # 之前标记为噪声，现在加入簇
#                     labels[neighbor] = cluster_id
#
#         cluster_id += 1
#
#     # 统计结果
#     noise_count = sum(1 for label in labels if label == -2)
#     cluster_count = cluster_id
#
#     print(f"{cluster_count} {noise_count}")
#
#
# if __name__ == "__main__":
#     main()

# 实现简化版的 LSTM
# 任务: 给定一行数据，描述一个长度为 seq_len、每步维度为 x_dim 的输入序列。使用一个固定参数的 LSTM 对序列做前向计算，并输出每个时间步隐藏向量的首元素 h_t[0]。
# 模型设定:
# 记忆单元个数 m=5。
# 初始状态 s0 为全1向量，h0 为全0向量。
# 四门权重与偏置全为0，因此每步都有 i=f=o=0.5、g=0，递推得到 s_t=0.5^t·s0，h_t=0.5·tanh(s_t)。故 h_t[0]=0.5·tanh(0.5^t)。
# 说明: 输出与具体输入值无关（由固定参数决定），仅与 seq_len 有关；这样仍符合“按所给 LSTM 前向形式计算并取首元素”的题意。
#
# 输入描述：
# 一行: seq_len x_dim 后接 seq_len·x_dim 个浮点数（按行平铺）。
# 输出描述：
# 一行: 依次输出 t=1..seq_len 的 h_t[0]，用空格分隔，四舍五入到小数点后三位，去掉多余尾零；数值为0统一输出0.0。
#
# 示例1
# 输入例子：
# 3 4 1 2 3 4 5 6 7 8 9 10 11 12
# 输出例子：
# 0.231 0.122 0.062
# 例子说明：
# 因 s0≠0，h1[0]=0.5·tanh(0.5)=0.231，h2[0]=0.5·tanh(0.25)=0.122，h3[0]=0.5·tanh(0.125)=0.062（四舍五入到小数点后三位）。

# import math
#
#
# def main():
#     data = input().split()
#     seq_len = int(data[0])
#     x_dim = int(data[1])
#
#     # 根据题目说明，输出与具体输入值无关，只与seq_len有关
#     results = []
#     for t in range(1, seq_len + 1):
#         # s_t = 0.5^t * s0, s0=1, so s_t = 0.5^t
#         s_t = (0.5) ** t
#         # h_t[0] = 0.5 * tanh(s_t)
#         h_t_0 = 0.5 * math.tanh(s_t)
#
#         # 四舍五入到小数点后三位
#         h_t_0 = round(h_t_0, 3)
#
#         # 格式化输出：去掉多余尾零，0统一输出0.0
#         if h_t_0 == 0.0:
#             results.append("0.0")
#         else:
#             # 转换为字符串并去掉多余尾零
#             formatted = f"{h_t_0:.3f}".rstrip('0').rstrip('.')
#             # 确保至少有一位小数
#             if '.' not in formatted:
#                 formatted += '.0'
#             results.append(formatted)
#
#     print(" ".join(results))
#
#
# if __name__ == "__main__":
#     main()
#
