# 快速开始指南

## 🚀 5分钟上手

### 1. 环境准备
```bash
# 确保Python 3.8+已安装
python3 --version

# 安装依赖
pip3 install -r requirements.txt

# 安装Playwright浏览器
playwright install chromium
```

### 2. 配置API密钥
```bash
# 复制环境变量模板
cp .env.example .env

# 编辑.env文件，填入DeepSeek API密钥
# DEEPSEEK_API_KEY=your_actual_key_here
```

### 3. 立即体验

#### 方式1: 交互式CLI
```bash
python3 main.py
# 按提示输入话题即可开始
```

#### 方式2: 命令行直接运行
```bash
# 测试关键词扩展
python3 main.py --keyword-test "文化大革命"

# 完整爬取任务
python3 main.py --topic "国家主席" --iterations 2

# 分析现有图片
python3 main.py --analyze "四人帮"
```

### 4. 预期结果

运行成功后，你会看到：
- 自动扩展的关键词列表
- 下载进度显示
- 内容分析结果
- 最终报告文件

### 5. 文件结构
```
工作目录/
├── 国家主席/           # 按关键词创建的文件夹
│   ├── 0.png          # 下载的图片
│   ├── 1.png
│   └── ...
├── 文化大革命/
│   ├── 0.png
│   └── ...
├── 国家主席_final_report.md    # 最终报告
├── 文化大革命_analysis_report.md  # 分析报告
└── test_report.md      # 系统测试报告
```

## 🎯 常用命令

| 命令 | 说明 | 示例 |
|------|------|------|
| `python3 main.py` | 启动交互界面 | - |
| `--topic` | 指定话题爬取 | `--topic "改革开放"` |
| `--iterations` | 设置迭代轮数 | `--iterations 3` |
| `--keyword-test` | 测试关键词扩展 | `--keyword-test "抗日战争"` |
| `--analyze` | 分析现有图片 | `--analyze "./四人帮"` |
| `--help` | 查看帮助 | `--help` |

## 🔧 故障排除

### 常见问题快速解决

1. **ModuleNotFoundError**
   ```bash
   pip3 install -r requirements.txt
   ```

2. **Playwright错误**
   ```bash
   playwright install chromium
   ```

3. **API密钥错误**
   - 检查 `.env` 文件是否存在
   - 确认 `DEEPSEEK_API_KEY` 已正确设置

4. **代理问题**
   - 检查 `.env` 中的代理设置
   - 或暂时注释掉代理配置

### 验证安装
```bash
python3 test_system.py
```

如果看到"所有测试通过"，说明系统已就绪！