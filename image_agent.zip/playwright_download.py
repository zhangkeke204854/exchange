import os
from playwright.sync_api import sync_playwright
from concurrent.futures import ThreadPoolExecutor, as_completed


# 获取当前文件的绝对路径（包含文件名）
current_path = os.path.realpath(__file__)

# 获取目录路径
file_dir = os.path.dirname(current_path)

# 配置代理（Playwright 方式）
proxy_settings = {'server': 'http://127.0.0.1:13659'}


user_agent = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 "
              "Safari/537.36")


def open_playwright_browser(headless=True):
    """
    使用 Playwright 打开浏览器
    """
    playwright = sync_playwright().start()

    # 启动浏览器
    browser = playwright.chromium.launch(
        headless=headless,
        # proxy=proxy_settings,  # 代理设置
        args=[
            '--start-maximized',
            '--disable-blink-features=AutomationControlled',
            '--disable-gpu',
            '--no-sandbox',
            '--disable-dev-shm-usage',
            '--ignore-certificate-errors',
            '--allow-running-insecure-content',
            '--disable-notifications',
            '--disable-extensions',
            '--disable-popup-blocking',
        ]
    )

    # 创建上下文（类似无痕浏览器）[citation:7]
    context = browser.new_context(
        viewport={'width': 1920, 'height': 1080},
        user_agent=user_agent,
        ignore_https_errors=True
    )

    # 注入脚本隐藏自动化特征
    context.add_init_script("""
        Object.defineProperty(navigator, 'webdriver', { get: () => false });
        window.chrome = { runtime: {} };

        const originalQuery = window.navigator.permissions.query;
        window.navigator.permissions.query = (parameters) => (
            parameters.name === 'notifications' ?
                Promise.resolve({ state: Notification.permission }) :
                originalQuery(parameters)
        );
    """)

    return playwright, browser, context


# 同步版本的下载函数 (备用方案)
def download_image(url_data):
    """
    图片下载
    """
    file, url = url_data

    download_flag = True

    # 启动 Playwright 浏览器
    playwright, browser, context = open_playwright_browser()
    try:
        page = context.new_page()

        page.goto(url, wait_until='load', timeout=10000)

        # 等待并获取图片元素
        page.wait_for_selector('img', state='attached', timeout=10000)

        image_element = page.query_selector('img')

        if image_element:
            image_element.screenshot(path=file)
            print("成功下载:", url, file)
        else:
            print("未找到图片元素:", url)
            download_flag = False

    except Exception as e:
        print("下载失败:", url, e)
        download_flag = False

    finally:
        # 关闭浏览器资源
        browser.close()
        playwright.stop()

    return download_flag


def save_image(tasks, max_workers=10):
    """
    Playwright 多线程保存图片
    """
    success_count = 0
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_task = {
            executor.submit(download_image, task): task
            for task in tasks
        }

        for future in as_completed(future_to_task):
            try:
                download_flag = future.result()
                if download_flag:
                    success_count += 1
            except Exception as e:
                print(f"任务执行异常: {e}")

    print(f"\n🎉 playwright请求下载完成! 图片总量: {len(tasks)} 张\n"
          f"成功: {success_count} 张\n失败: {len(tasks) - success_count} 张")


# if __name__ == '__main__':
#     temp_keyword = '四人帮'
#
#     img_url_list = []
#
#     record_file = os.path.join(file_dir, 'google_img_url3.csv')
#     if os.path.exists(record_file):
#         with open(record_file, "r", encoding="utf-8-sig") as r:
#             read_lines = r.readlines()
#             for each_line in read_lines:
#                 img_url_list.append(each_line.replace('\n', ''))
#
#     file_path = os.path.join(file_dir, temp_keyword)
#
#     # 创建保存图片的目录
#     os.makedirs(file_path, exist_ok=True)
#
#     tasks = [(os.path.join(file_path, f"{index}.png"), url) for index, url in enumerate(img_url_list)]
#
#     save_image(tasks, max_workers=10)
