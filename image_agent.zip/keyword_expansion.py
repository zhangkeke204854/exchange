"""
关键词扩展和自适应prompt系统
负责根据用户输入的话题智能扩展相关关键词，并进行相似度计算和动态调整
"""

import os
import re
import json
from typing import List, Dict, Tuple
from langchain_deepseek import ChatDeepSeek
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from dotenv import load_dotenv


load_dotenv(override=True)


class KeywordExpansion:
    def __init__(self):
        self.model = ChatDeepSeek(model="deepseek-chat")
        
        # 关键词扩展prompt模板
        self.expansion_prompt = PromptTemplate(
            template="""你是一名专业的中文语义分析专家，擅长根据给定话题扩展出相关的关键词。

                        用户输入话题：{topic}

                        请根据这个话题，扩展出5-8个与之高度相关的关键词。这些关键词应该：
                        1. 与话题有直接关联
                        2. 涵盖话题的不同方面和角度
                        3. 包括历史事件、人物、概念、相关术语等
                        4. 避免过于宽泛或无关的词汇

                        请严格按照以下JSON格式返回结果：
                        {{
                            "expanded_keywords": [
                                {{
                                    "keyword": "关键词1",
                                    "relevance": 0.95,
                                    "category": "历史事件/人物/概念",
                                    "description": "简要描述该关键词与话题的关联"
                                }},
                                {{
                                    "keyword": "关键词2", 
                                    "relevance": 0.90,
                                    "category": "历史事件/人物/概念",
                                    "description": "简要描述该关键词与话题的关联"
                                }}
                            ]
                        }}

                        注意：relevance分数应该在0.7-1.0之间，数值越高表示与话题关联度越强。""", input_variables=["topic"]
        )
        
        # 关键词过滤prompt模板
        self.filter_prompt = PromptTemplate(
            template="""你是一名内容审核专家，负责判断关键词是否与给定话题相关。

                        原始话题：{original_topic}
                        关键词列表：{keywords}

                        请分析每个关键词与原始话题的相关性，并返回一个过滤后的关键词列表。

                        请严格按照以下JSON格式返回结果：
                        {{
                            "filtered_keywords": [
                                {{
                                    "keyword": "关键词1",
                                    "is_relevant": true,
                                    "relevance_score": 0.92,
                                    "reason": "说明为什么相关"
                                }},
                                {{
                                    "keyword": "关键词2",
                                    "is_relevant": false, 
                                    "relevance_score": 0.45,
                                    "reason": "说明为什么不相关"
                                }}
                            ]
                        }}

                        注意：is_relevant为true的关键词才会被保留用于图片搜索。""", input_variables=["original_topic", "keywords"]
        )
        
        # 预定义的关键词映射（用于快速扩展）
        self.keyword_mappings = {
            "国家主席": ["毛泽东", "邓小平", "江泽民", "胡锦涛", "习近平"],
            "文化大革命": ["林彪反革命集团", "四人帮", "文斗", "武斗", "红卫兵", "造反派", "批林批孔", "上山下乡"],
            "国家分裂": ["台独", "港独", "新疆独立", "西藏独立", "分裂势力", "境外势力"],
            "改革开放": ["经济特区", "深圳速度", "家庭联产承包", "市场经济", "邓小平南巡"],
            "抗日战争": ["南京大屠杀", "九一八事变", "七七事变", "八路军", "新四军", "抗日英雄"],
            "改革开放": ["经济特区", "深圳", "浦东开发", "市场经济", "邓小平理论"]
        }
    
    def expand_keywords(self, topic: str) -> List[Dict[str, any]]:
        """根据话题扩展关键词"""
        # 首先检查预定义映射
        if topic in self.keyword_mappings:
            keywords = [
                {
                    "keyword": kw,
                    "relevance": 0.9,
                    "category": "预定义扩展",
                    "description": f"与{topic}直接相关的关键词"
                }
                for kw in self.keyword_mappings[topic]
            ]
            return keywords
        
        # 使用LLM进行智能扩展
        try:
            chain = self.expansion_prompt | self.model | JsonOutputParser()
            result = chain.invoke({"topic": topic})
            return result.get("expanded_keywords", [])
        except Exception as e:
            print(f"关键词扩展失败: {e}")
            # 回退到简单扩展
            return [{"keyword": topic, "relevance": 1.0, "category": "原始话题", "description": "原始输入话题"}]
    
    def filter_keywords(self, original_topic: str, keywords: List[str]) -> List[str]:
        """过滤不相关的关键词"""
        if not keywords:
            return []
            
        keywords_str = json.dumps(keywords, ensure_ascii=False)
        try:
            chain = self.filter_prompt | self.model | JsonOutputParser()
            result = chain.invoke({
                "original_topic": original_topic,
                "keywords": keywords_str
            })
            
            filtered = []
            for item in result.get("filtered_keywords", []):
                if item.get("is_relevant", False):
                    filtered.append(item["keyword"])
            
            return filtered
        except Exception as e:
            print(f"关键词过滤失败: {e}")
            return keywords  # 出错时返回原始列表
    
    def calculate_similarity_score(self, keyword1: str, keyword2: str) -> float:
        """计算两个关键词的相似度分数（简化版）"""
        # 这里可以实现更复杂的相似度计算
        # 目前使用简单的字符串包含关系
        keyword1 = keyword1.lower()
        keyword2 = keyword2.lower()
        
        if keyword1 == keyword2:
            return 1.0
        elif keyword1 in keyword2 or keyword2 in keyword1:
            return 0.8
        else:
            return 0.3
    
    def dynamic_adjust_keywords(self, original_topic: str, current_keywords: List[str], feedback_data: Dict = None) -> List[str]:
        """根据反馈动态调整关键词"""
        # 第一轮：使用LLM过滤
        filtered_keywords = self.filter_keywords(original_topic, current_keywords)
        
        # 第二轮：根据反馈调整
        if feedback_data:
            # 这里可以根据实际下载结果和审核反馈进行调整
            # 例如：移除下载结果不好的关键词，添加新的相关关键词
            pass
        
        return filtered_keywords
    
    def get_expanded_keywords_for_topic(self, topic: str, max_keywords: int = 10) -> List[str]:
        """获取最终用于图片搜索的关键词列表"""
        # 扩展关键词
        expanded = self.expand_keywords(topic)
        
        # 按相关度排序
        expanded.sort(key=lambda x: x["relevance"], reverse=True)
        
        # 提取关键词
        keywords = [item["keyword"] for item in expanded[:max_keywords]]
        
        # 过滤不相关关键词
        filtered = self.filter_keywords(topic, keywords)
        
        return filtered


if __name__ == "__main__":
    # 测试关键词扩展功能
    expansion = KeywordExpansion()
    
    # test_topics = ["文化大革命", "国家主席", "改革开放", '恐怖主义']
    test_topics = ['恐怖主义']
    
    for topic in test_topics:
        print(f"\n=== 测试话题: {topic} ===")
        keywords = expansion.get_expanded_keywords_for_topic(topic)
        print(f"扩展关键词: {keywords}")