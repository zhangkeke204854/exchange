# 智能图片爬取系统

基于LangGraph的agent驱动图片爬取与内容审核系统，支持关键词智能扩展、动态调整、内容过滤等功能。

## 🚀 功能特性

### 核心功能
- **智能关键词扩展**: 根据用户输入话题自动扩展相关关键词
- **多轮动态调整**: 根据下载结果动态调整关键词策略
- **内容自动审核**: AI驱动的图片内容相关性分析
- **智能过滤系统**: 自动移除不相关或低质量图片
- **批量下载管理**: 支持多线程并发下载

### 技术特点
- **LangGraph驱动**: 基于状态机的agent工作流
- **模块化设计**: 关键词扩展、图片下载、内容分析独立模块
- **可扩展性**: 支持自定义关键词映射和分析规则
- **用户友好**: 提供CLI和API两种使用方式

## 📦 安装

### 环境要求
- Python 3.8+
- 支持的操作系统: Windows, macOS, Linux

### 安装步骤

1. 克隆项目
```bash
git clone <repository-url>
cd image_agent
```

2. 安装依赖
```bash
pip install -r requirements.txt
```

3. 安装Playwright浏览器
```bash
playwright install chromium
```

4. 配置环境变量
```bash
cp .env.example .env
# 编辑 .env 文件，填入必要的API密钥
```

## 🔧 配置

### 环境变量配置
创建 `.env` 文件并配置以下参数：

```bash
# DeepSeek API配置（必需）
DEEPSEEK_API_KEY=your_deepseek_api_key_here

# 代理配置（可选）
HTTP_PROXY=http://127.0.0.1:13659
HTTPS_PROXY=http://127.0.0.1:13659

# 系统配置
MAX_WORKERS=20              # 最大并发线程数
DEFAULT_ITERATIONS=2        # 默认迭代轮数
MIN_RELEVANCE_SCORE=0.7     # 最小相关度阈值
```

## 🎯 使用方法

### 1. 交互式CLI模式
```bash
python main.py
```

### 2. 命令行参数模式
```bash
# 直接爬取指定话题
python main.py --topic "文化大革命" --iterations 3

# 关键词扩展测试
python main.py --keyword-test "国家主席"

# 分析现有图片
python main.py --analyze ./四人帮
```

### 3. Python API使用
```python
from image_crawler_agent import ImageCrawlerAgent

# 创建agent实例
agent = ImageCrawlerAgent()

# 执行爬取任务
result = agent.run("文化大革命", max_iterations=2)
```

## 📋 使用示例

### 示例1: 爬取历史事件图片
```bash
python main.py --topic "文化大革命" --iterations 2
```

系统将自动：
1. 扩展关键词：["四人帮", "红卫兵", "批林批孔", ...]
2. 下载相关图片
3. 分析并过滤不相关内容
4. 生成详细报告

### 示例2: 关键词扩展测试
```bash
python main.py --keyword-test "改革开放"
```

输出：
```
话题: 改革开放
扩展关键词: 经济特区, 深圳, 浦东开发, 市场经济, 邓小平理论
```

## 📊 项目结构

```
image_agent/
├── main.py                 # 主程序入口
├── image_crawler_agent.py  # LangGraph agent工作流
├── keyword_expansion.py    # 关键词扩展模块
├── image_analyzer.py       # 图片内容分析模块
├── get_image_url.py        # 图片URL获取工具
├── requests_download.py    # 多线程下载模块
├── playwright_download.py  # Playwright备用下载
├── graph.py               # 基础LangGraph示例
├── requirements.txt       # 项目依赖
├── .env.example          # 环境变量模板
├── README.md             # 项目文档
└── utils/                # 工具模块
    ├── config.py
    └── llms.py
```

## 🔍 关键词扩展机制

### 预定义映射
系统内置了常用话题的关键词映射：

| 输入话题 | 扩展关键词 |
|---------|-----------|
| 国家主席 | 毛泽东, 邓小平, 江泽民, 胡锦涛, 习近平 |
| 文化大革命 | 四人帮, 红卫兵, 文斗, 武斗, 批林批孔 |
| 改革开放 | 经济特区, 深圳, 浦东开发, 市场经济 |

### 智能扩展
对于未预定义的话题，系统使用LLM进行智能扩展：
1. 语义分析用户输入
2. 生成相关关键词列表
3. 计算相关性分数
4. 动态过滤不相关内容

## 🎨 内容审核机制

### 审核流程
1. **图片分析**: 使用AI模型分析图片内容
2. **相关性评分**: 计算与关键词的相关度
3. **质量检查**: 检查图片尺寸、清晰度等
4. **自动过滤**: 移除低质量或不相关内容

### 审核标准
- 相关度阈值: 0.7
- 最小图片尺寸: 100x100
- 最大文件大小: 10MB
- 支持格式: JPG, PNG, GIF, WebP

## 📈 性能优化

### 并发下载
- 最大并发线程: 20
- 失败重试机制
- 多下载器备份(requests + Playwright)

### 缓存机制
- 关键词扩展结果缓存
- 图片URL去重
- 失败URL记录

## 🛠️ 故障排除

### 常见问题

1. **API密钥错误**
   - 检查 `.env` 文件中的 `DEEPSEEK_API_KEY`
   - 确保密钥有效且未过期

2. **代理连接问题**
   - 检查代理服务器是否运行
   - 验证代理地址和端口配置

3. **Playwright安装问题**
   ```bash
   playwright install chromium
   playwright install-deps
   ```

4. **图片下载失败**
   - 检查网络连接
   - 验证代理设置
   - 查看失败日志

### 调试模式
```bash
# 启用详细日志
python main.py --topic "测试" --debug
```

## 🤝 贡献指南

欢迎提交Issue和Pull Request！

### 开发环境设置
```bash
# 安装开发依赖
pip install -r requirements.txt
pip install pytest black flake8

# 运行测试
pytest tests/

# 代码格式化
black .
flake8 .
```

## 📄 许可证

本项目采用MIT许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🙋‍♂️ 联系方式

如有问题或建议，请通过以下方式联系：
- 提交Issue
- 发送邮件
- 项目讨论区

## 🔄 更新日志

### v1.0.0 (2024-11-14)
- ✨ 初始版本发布
- 🎯 核心功能实现
- 📊 关键词扩展系统
- 🔍 内容审核机制
- 🖥️ CLI界面