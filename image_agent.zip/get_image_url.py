import os
import random
from lxml import etree
from playwright.sync_api import sync_playwright
from urllib.parse import unquote, parse_qs, urlparse

import requests_download
import playwright_download


# 获取当前文件的绝对路径（包含文件名）
current_path = os.path.realpath(__file__)

# 获取目录路径
file_dir = os.path.dirname(current_path)

# 配置代理（Playwright 方式）
proxy_settings = {'server': 'http://127.0.0.1:13659'}

user_agent = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 "
              "Safari/537.36")


def force_click_thumbnail(page, thumbnail_element):
    """
    使用 Playwright 强制显示并点击缩略图
    """
    try:
        # 先尝试普通点击
        thumbnail_element.click()
        return True
    except Exception as e:
        print(f"普通点击失败，尝试JavaScript点击: {e}")
        try:
            # 使用 JavaScript 点击
            page.evaluate("element => element.click()", thumbnail_element)
            return True
        except Exception as js_e:
            print(f"JavaScript点击也失败: {js_e}")
            return False


def smart_scroll(page):
    """
    使用 Playwright 滚动页面以加载所有内容 [citation:1][citation:6]
    """
    try:
        print("开始滚动页面以加载更多内容...")

        last_height = page.evaluate("() => document.body.scrollHeight")
        scroll_attempts = 0
        max_attempts = 3
        scroll_count = 0
        max_scrolls = 10

        print(f"初始页面高度: {last_height}px")

        while scroll_attempts < max_attempts and scroll_count < max_scrolls:
            # 滚动到底部
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            page.wait_for_timeout(random.randint(2000, 3000))  # Playwright 的等待方式

            new_height = page.evaluate("() => document.body.scrollHeight")

            if new_height == last_height:
                scroll_attempts += 1
            else:
                scroll_attempts = 0
                last_height = new_height

            scroll_count += 1

        print(f"滚动完成 - 总共滚动 {scroll_count} 次")

        # 滚动回顶部
        return scroll_to_top(page)

    except Exception as e:
        print(f"滚动过程出现错误: {e}")
        return False


def scroll_to_top(page):
    """
    使用 Playwright 滚动回页面顶部 [citation:1]
    """
    try:
        print("正在滚动回页面顶部...")

        # 使用平滑滚动回到顶部
        page.evaluate("window.scrollTo({top: 0, behavior: 'smooth'})")
        page.wait_for_timeout(random.randint(2000, 3000))

        # 检查是否回到顶部
        current_position = page.evaluate("() => window.pageYOffset")
        print(f"当前滚动位置: {current_position}px")

        return current_position <= 50

    except Exception as e:
        print(f"回到顶部时出错: {e}")
        return False


def extract_image_url(img_url):
    """
    提取图片URL（保持不变）
    """
    parsed_url = urlparse(img_url)
    query_params = parse_qs(parsed_url.query)
    img_url_encoded = query_params.get('imgurl', [None])[0]
    if img_url_encoded:
        img_url_decoded = unquote(img_url_encoded)
        return img_url_decoded
    else:
        return None


def get_url(html):
    """
    解析HTML获取图片URL（保持不变）
    """
    all_list = []
    path = '//*[@id="rso"]/div/div/div[1]/div/div/div'
    div_list = html.xpath(path)
    for each_div in div_list:
        url, img_url = None, None
        url_list = each_div.xpath('./div[3]/a/@href')
        if url_list:
            url = url_list[0]
        href_list = each_div.xpath('./div[2]/h3/a/@href')
        if href_list:
            img_url = href_list[0]

        if url or img_url:
            all_list.append({'url': url, 'img_url': img_url})

    return all_list


def open_playwright_browser(headless=True):
    """
    使用 Playwright 打开浏览器
    """
    playwright = sync_playwright().start()

    # 启动浏览器
    browser = playwright.chromium.launch(
        headless=headless,
        # proxy=proxy_settings,  # 代理设置
        args=[
            '--start-maximized',
            '--disable-blink-features=AutomationControlled',
            '--disable-gpu',
            '--no-sandbox',
            '--disable-dev-shm-usage',
            '--ignore-certificate-errors',
            '--allow-running-insecure-content',
            '--disable-notifications',
            '--disable-extensions',
            '--disable-popup-blocking',
        ]
    )

    # 创建上下文（类似无痕浏览器）[citation:7]
    context = browser.new_context(
        viewport={'width': 1920, 'height': 1080},
        user_agent=user_agent,
        ignore_https_errors=True
    )

    # 注入脚本隐藏自动化特征
    context.add_init_script("""
        Object.defineProperty(navigator, 'webdriver', { get: () => false });
        window.chrome = { runtime: {} };

        const originalQuery = window.navigator.permissions.query;
        window.navigator.permissions.query = (parameters) => (
            parameters.name === 'notifications' ?
                Promise.resolve({ state: Notification.permission }) :
                originalQuery(parameters)
        );
    """)

    return playwright, browser, context


def get_keyword_image(keyword):
    """
    使用 Playwright 获取关键词图片URL
    """
    img_url_list = []

    # 启动 Playwright 浏览器
    playwright, browser, context = open_playwright_browser()

    try:
        # 创建新页面
        page = context.new_page()

        # 设置超时
        page.set_default_timeout(30000)

        # 导航到Google图片搜索
        search_url = f"https://www.google.com/search?q={keyword}&safe=on&newwindow=1&sclient=img&udm=2"

        page.goto(search_url, wait_until='networkidle', timeout=50000)

        print("页面加载完成，开始处理...")

        # 智能滚动加载
        smart_scroll(page)

        # 等待页面稳定
        page.wait_for_timeout(random.randint(2000, 3000))

        # 定位缩略图元素并点击
        thumbnail_elements = page.query_selector_all(".ob5Hkd")

        print(f"找到 {len(thumbnail_elements)} 个缩略图元素")

        retry_click = []

        # 第一轮点击尝试
        for index, element in enumerate(thumbnail_elements):
            try:
                if element.is_visible():
                    element.click()
                else:
                    retry_click.append(element)
            except Exception as e:
                print(f"点击缩略图 {index} 时出错: {e}")
                retry_click.append(element)

        # 第二轮重试点击
        for index, element in enumerate(retry_click):
            try:
                force_click_thumbnail(page, element)
            except Exception as e:
                print(f"重试点击缩略图 {index} 时失败: {e}")

        # 等待图片加载完成
        page.wait_for_timeout(random.randint(2000, 3000))

        # 获取页面HTML内容
        html_content = page.content()

        html = etree.HTML(html_content)

        # 解析获取图片URL
        all_list = get_url(html)

        for each_dict in all_list:
            img_url = extract_image_url(each_dict['img_url'])
            if img_url:
                img_url_list.append(img_url)

        print(f"总共找到 {len(img_url_list)} 个图片URL")
    except Exception as e:
        print(f'关键词 "{keyword}" 搜索图片失败: {e}')

    finally:
        # 关闭浏览器资源
        browser.close()
        playwright.stop()

    return img_url_list


def save_urls_to_file(keyword, img_url_list):
    """
    保存URL到文件
    """
    url_file = os.path.join(file_dir, f'{keyword}_img_url.csv')
    with open(url_file, "w", encoding="utf-8-sig") as f:
        for url in img_url_list:
            f.write(url + '\n')

    print(f"已保存 {len(img_url_list)} 个URL到文件: {url_file}")


if __name__ == '__main__':
    keyword = '四人帮'

    print(f"开始搜索关键词: {keyword}")

    # 使用 Playwright 获取图片URL
    img_url_list = get_keyword_image(keyword)

    # 保存结果
    if img_url_list:
        save_urls_to_file(keyword, img_url_list)

        file_path = os.path.join(file_dir, keyword)

        # 创建保存图片的目录
        os.makedirs(file_path, exist_ok=True)

        max_workers = 20

        tasks = [(os.path.join(file_path, f"{index}.png"), url) for index, url in enumerate(img_url_list)]

        failed_urls = requests_download.save_image(tasks, max_workers=max_workers)
        if failed_urls:
            playwright_download.save_image(failed_urls, max_workers=max_workers)

