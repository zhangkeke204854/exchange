"""
基于LangGraph的agent驱动图片爬取工作流
集成关键词扩展、图片下载、内容审核的完整agent系统
"""

import os
import json
from typing import Dict, List, TypedDict, Annotated
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain_deepseek import ChatDeepSeek
from langchain_core.messages import HumanMessage, AIMessage
from langgraph.prebuilt import ToolNode
from langchain_core.tools import tool
from langgraph.checkpoint.memory import MemorySaver

from keyword_expansion import KeywordExpansion
from image_analyzer import ImageContentAnalyzer
import get_image_url
import requests_download
import playwright_download

class ImageCrawlerState(TypedDict):
    """定义agent状态"""
    topic: str
    keywords: List[str]
    current_keyword: str
    downloaded_images: List[str]
    analysis_results: List[Dict]
    messages: Annotated[List, add_messages]
    iteration: int
    max_iterations: int

class ImageCrawlerAgent:
    def __init__(self):
        self.keyword_expander = KeywordExpansion()
        self.image_analyzer = ImageContentAnalyzer()
        self.model = ChatDeepSeek(model="deepseek-chat")
        
        # 创建状态图
        self.workflow = self._create_workflow()
        
    def _create_workflow(self) -> StateGraph:
        """创建LangGraph工作流"""
        
        # 定义工作流节点
        workflow = StateGraph(ImageCrawlerState)
        
        # 添加节点
        workflow.add_node("expand_keywords", self._expand_keywords_node)
        workflow.add_node("download_images", self._download_images_node)
        workflow.add_node("analyze_images", self._analyze_images_node)
        workflow.add_node("adjust_keywords", self._adjust_keywords_node)
        workflow.add_node("generate_report", self._generate_report_node)
        
        # 添加边
        workflow.add_edge(START, "expand_keywords")
        workflow.add_edge("expand_keywords", "download_images")
        workflow.add_edge("download_images", "analyze_images")
        workflow.add_edge("analyze_images", "adjust_keywords")
        
        # 条件边：根据迭代次数决定是否继续
        workflow.add_conditional_edges(
            "adjust_keywords",
            self._should_continue,
            {
                "continue": "download_images",
                "finish": "generate_report"
            }
        )
        workflow.add_edge("generate_report", END)
        
        return workflow
    
    def _expand_keywords_node(self, state: ImageCrawlerState) -> Dict:
        """关键词扩展节点"""
        topic = state["topic"]
        
        # 使用关键词扩展器获取相关关键词
        keywords = self.keyword_expander.get_expanded_keywords_for_topic(topic)
        
        return {
            "keywords": keywords,
            "messages": [AIMessage(content=f"已扩展关键词: {', '.join(keywords)}")],
            "iteration": 0
        }
    
    def _download_images_node(self, state: ImageCrawlerState) -> Dict:
        """图片下载节点"""
        keywords = state["keywords"]
        downloaded_images = []
        
        for keyword in keywords:
            print(f"正在下载关键词 '{keyword}' 的图片...")
            
            # 获取图片URL
            img_url_list = get_image_url.get_keyword_image(keyword)
            
            if not img_url_list:
                print(f"关键词 '{keyword}' 未找到图片")
                continue
            
            # 创建保存目录
            save_dir = os.path.join(os.path.dirname(__file__), keyword)
            os.makedirs(save_dir, exist_ok=True)
            
            # 准备下载任务
            tasks = [(os.path.join(save_dir, f"{index}.png"), url) 
                    for index, url in enumerate(img_url_list)]
            
            # 下载图片
            failed_urls = requests_download.save_image(tasks, max_workers=20)
            if failed_urls:
                playwright_download.save_image(failed_urls, max_workers=10)
            
            # 记录下载的图片
            downloaded_images.extend([task[0] for task in tasks])
            
            print(f"关键词 '{keyword}' 下载完成，共 {len(img_url_list)} 张图片")
        
        return {
            "downloaded_images": downloaded_images,
            "current_keyword": keywords[0] if keywords else "",
            "messages": [AIMessage(content=f"已下载 {len(downloaded_images)} 张图片")]
        }
    
    def _analyze_images_node(self, state: ImageCrawlerState) -> Dict:
        """图片分析节点"""
        keywords = state["keywords"]
        analysis_results = []
        
        for keyword in keywords:
            image_folder = os.path.join(os.path.dirname(__file__), keyword)
            
            if not os.path.exists(image_folder):
                continue
            
            print(f"正在分析关键词 '{keyword}' 的图片...")
            
            # 批量分析图片
            results = self.image_analyzer.batch_analyze_images(image_folder, keyword)
            
            # 过滤和清理图片
            filter_results = self.image_analyzer.filter_and_cleanup_images(results)
            
            # 记录分析结果
            analysis_results.append({
                "keyword": keyword,
                "total_images": len(results),
                "kept_images": filter_results["keep_count"],
                "removed_images": filter_results["remove_count"],
                "filter_results": filter_results
            })
            
            # 生成分析报告
            report = self.image_analyzer.generate_analysis_report(keyword, results, filter_results)
            self.image_analyzer.save_analysis_report(keyword, report)
            
            print(f"关键词 '{keyword}' 分析完成，保留 {filter_results['keep_count']} 张图片")
        
        return {
            "analysis_results": analysis_results,
            "messages": [AIMessage(content=f"已完成图片分析，共处理 {len(analysis_results)} 个关键词")]
        }
    
    def _adjust_keywords_node(self, state: ImageCrawlerState) -> Dict:
        """关键词调整节点"""
        current_iteration = state["iteration"]
        max_iterations = state["max_iterations"]
        analysis_results = state["analysis_results"]
        
        if current_iteration >= max_iterations - 1:
            return {"iteration": current_iteration + 1}
        
        # 根据分析结果调整关键词
        # 这里简化处理，实际可以根据保留率等指标调整
        keywords = state["keywords"]
        
        # 动态调整关键词（示例逻辑）
        adjusted_keywords = []
        for result in analysis_results:
            if result["kept_images"] > 0:  # 保留有图片的关键词
                adjusted_keywords.append(result["keyword"])
        
        # 如果没有有效关键词，添加原始话题
        if not adjusted_keywords:
            adjusted_keywords = [state["topic"]]
        
        return {
            "keywords": adjusted_keywords,
            "iteration": current_iteration + 1,
            "messages": [AIMessage(content=f"第{current_iteration + 1}轮调整，保留关键词: {', '.join(adjusted_keywords)}")]
        }
    
    def _should_continue(self, state: ImageCrawlerState) -> str:
        """判断是否继续迭代"""
        if state["iteration"] >= state["max_iterations"]:
            return "finish"
        return "continue"
    
    def _generate_report_node(self, state: ImageCrawlerState) -> Dict:
        """生成最终报告节点"""
        topic = state["topic"]
        analysis_results = state["analysis_results"]
        
        # 生成综合报告
        total_images = sum(result["total_images"] for result in analysis_results)
        total_kept = sum(result["kept_images"] for result in analysis_results)
        
        report = f"""
                    # 智能图片爬取系统最终报告

                    ## 搜索话题: {topic}

                    ## 执行统计
                    - 总迭代轮数: {state['iteration']}
                    - 处理关键词数量: {len(analysis_results)}
                    - 总下载图片: {total_images}
                    - 最终保留图片: {total_kept}
                    - 整体保留率: {total_kept/max(total_images, 1)*100:.1f}%

                    ## 各关键词详细统计
                    """
        
        for result in analysis_results:
            report += f"""
                        ### {result['keyword']}
                        - 下载图片: {result['total_images']}
                        - 保留图片: {result['kept_images']}
                        - 删除图片: {result['removed_images']}
                        - 保留率: {result['kept_images']/max(result['total_images'], 1)*100:.1f}%
                        """
        
        # 保存报告
        report_file = os.path.join(os.path.dirname(__file__), f"{topic}_final_report.md")
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)
        
        return {
            "messages": [AIMessage(content=f"任务完成！最终报告已保存到: {report_file}")]
        }
    
    def run(self, topic: str, max_iterations: int = 2) -> Dict:
        """运行图片爬取任务"""
        print(f"开始执行图片爬取任务，话题: {topic}")
        
        # 初始化状态
        initial_state = {
            "topic": topic,
            "keywords": [],
            "current_keyword": "",
            "downloaded_images": [],
            "analysis_results": [],
            "messages": [HumanMessage(content=f"请搜索并下载关于'{topic}'的图片")],
            "iteration": 0,
            "max_iterations": max_iterations
        }
        
        # 编译工作流
        app = self.workflow.compile()
        
        # 执行工作流
        final_state = app.invoke(initial_state)
        
        return final_state


if __name__ == "__main__":
    # 测试agent
    agent = ImageCrawlerAgent()
    
    # 测试话题
    test_topic = "文化大革命"
    result = agent.run(test_topic, max_iterations=2)
    
    print(f"\n任务完成！")
    print(f"最终状态: {result}")