"""
系统测试脚本
用于验证智能图片爬取系统的各个模块功能
"""

import os
import sys
import json
from datetime import datetime

# 添加当前目录到Python路径
sys.path.insert(0, os.path.dirname(__file__))

def test_keyword_expansion():
    """测试关键词扩展功能"""
    print("🧪 测试关键词扩展模块...")
    
    try:
        from keyword_expansion import KeywordExpansion
        
        expander = KeywordExpansion()
        
        # 测试预定义关键词
        test_cases = ["国家主席", "文化大革命", "改革开放"]
        
        for topic in test_cases:
            print(f"\n📋 测试话题: {topic}")
            keywords = expander.get_expanded_keywords_for_topic(topic)
            print(f"   扩展结果: {keywords}")
            
            # 验证结果
            if keywords and len(keywords) > 0:
                print(f"   ✅ 成功扩展 {len(keywords)} 个关键词")
            else:
                print(f"   ❌ 扩展失败")
        
        return True
        
    except Exception as e:
        print(f"❌ 关键词扩展测试失败: {e}")
        return False

def test_image_analyzer():
    """测试图片分析功能"""
    print("\n🧪 测试图片分析模块...")
    
    try:
        from image_analyzer import ImageContentAnalyzer
        
        analyzer = ImageContentAnalyzer()
        
        # 创建测试目录
        test_dir = "test_images"
        if not os.path.exists(test_dir):
            os.makedirs(test_dir)
            print(f"   📁 创建测试目录: {test_dir}")
        
        # 测试分析功能（模拟）
        print("   ✅ 图片分析模块初始化成功")
        return True
        
    except Exception as e:
        print(f"❌ 图片分析测试失败: {e}")
        return False

def test_agent_workflow():
    """测试agent工作流"""
    print("\n🧪 测试Agent工作流...")
    
    try:
        from image_crawler_agent import ImageCrawlerAgent
        
        # 创建agent实例（不实际运行）
        agent = ImageCrawlerAgent()
        print("   ✅ Agent工作流初始化成功")
        return True
        
    except Exception as e:
        print(f"❌ Agent工作流测试失败: {e}")
        return False

def test_dependencies():
    """测试依赖安装"""
    print("\n🧪 测试依赖安装...")
    
    required_modules = [
        'langchain',
        'langgraph',
        'langchain_deepseek',
        'PIL',
        'playwright',
        'requests',
        'dotenv'
    ]
    
    failed_modules = []
    
    for module in required_modules:
        try:
            __import__(module)
            print(f"   ✅ {module}")
        except ImportError:
            print(f"   ❌ {module} - 未安装")
            failed_modules.append(module)
    
    if failed_modules:
        print(f"\n❌ 以下模块未安装: {', '.join(failed_modules)}")
        print("请运行: pip install -r requirements.txt")
        return False
    else:
        print("   ✅ 所有依赖已安装")
        return True

def test_environment():
    """测试环境配置"""
    print("\n🧪 测试环境配置...")
    
    # 检查.env文件
    if os.path.exists('.env'):
        print("   ✅ .env 配置文件存在")
    else:
        print("   ⚠️  .env 文件不存在，请复制 .env.example 并配置")
    
    # 检查必要的API密钥
    from dotenv import load_dotenv
    load_dotenv()
    
    api_key = os.getenv('DEEPSEEK_API_KEY')
    if api_key and api_key != 'your_deepseek_api_key_here':
        print("   ✅ DeepSeek API密钥已配置")
    else:
        print("   ⚠️  DeepSeek API密钥未配置")
    
    return True

def create_test_report(results):
    """创建测试报告"""
    report = f"""
# 智能图片爬取系统测试报告

测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 测试结果摘要

"""
    
    for test_name, result in results.items():
        status = "✅ 通过" if result else "❌ 失败"
        report += f"- {test_name}: {status}\n"
    
    # 计算通过率
    passed = sum(results.values())
    total = len(results)
    report += f"\n## 通过率: {passed}/{total} ({passed/total*100:.1f}%)\n"
    
    # 建议
    if passed == total:
        report += "\n## 🎉 所有测试通过！系统已就绪\n"
    else:
        report += "\n## 🔧 需要修复的问题\n"
        for test_name, result in results.items():
            if not result:
                report += f"- {test_name} 需要修复\n"
    
    # 下一步操作
    report += """
## 下一步操作

1. 配置API密钥 (.env文件)
2. 运行示例任务: python main.py --topic "测试话题"
3. 使用CLI界面: python main.py

## 使用帮助

- 查看帮助: python main.py --help
- 关键词测试: python main.py --keyword-test "话题"
- 图片分析: python main.py --analyze "文件夹路径"
"""
    
    # 保存报告
    with open('test_report.md', 'w', encoding='utf-8') as f:
        f.write(report)
    
    print(f"\n📄 测试报告已保存: test_report.md")

def main():
    """主测试函数"""
    print("🚀 开始智能图片爬取系统测试...")
    print("=" * 50)
    
    # 运行各项测试
    test_results = {
        "依赖安装": test_dependencies(),
        "环境配置": test_environment(),
        "关键词扩展": test_keyword_expansion(),
        "图片分析": test_image_analyzer(),
        "Agent工作流": test_agent_workflow()
    }
    
    print("\n" + "=" * 50)
    print("📊 测试结果汇总:")
    print("=" * 50)
    
    for test_name, result in test_results.items():
        status = "✅ 通过" if result else "❌ 失败"
        print(f"{test_name}: {status}")
    
    # 创建详细报告
    create_test_report(test_results)
    
    # 总体评估
    passed = sum(test_results.values())
    total = len(test_results)
    
    if passed == total:
        print(f"\n🎉 恭喜！所有测试通过，系统已就绪")
        print("\n下一步:")
        print("1. 配置API密钥: 编辑 .env 文件")
        print("2. 运行CLI: python main.py")
        print("3. 测试任务: python main.py --topic '测试话题'")
    else:
        print(f"\n⚠️  发现 {total - passed} 个问题需要修复")
        print("请查看 test_report.md 获取详细信息")

if __name__ == "__main__":
    main()