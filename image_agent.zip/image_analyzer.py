"""
图片内容审核和过滤系统
负责自动审核下载的图片是否与关键词匹配，并过滤不相关内容
"""

import os
import json
from typing import List, Dict, Tuple
from PIL import Image
import requests
from io import BytesIO
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from langchain_deepseek import ChatDeepSeek
from dotenv import load_dotenv
import hashlib

load_dotenv(override=True)

class ImageContentAnalyzer:
    def __init__(self):
        self.model = ChatDeepSeek(model="deepseek-chat")
        
        # 图片内容分析prompt模板
        self.analysis_prompt = PromptTemplate(
            template="""你是一名专业的图片内容分析专家，擅长分析图片内容并判断其与给定关键词的相关性。

关键词：{keyword}
图片描述：{image_description}

请分析这张图片的内容，并判断它是否与给定关键词相关。

请严格按照以下JSON格式返回结果：
{{
    "is_relevant": true/false,
    "relevance_score": 0.85,
    "confidence": 0.90,
    "reason": "详细说明为什么这张图片与关键词相关或不相关",
    "main_elements": ["图片中的主要元素列表"],
    "category": "图片类别（如人物/风景/事件/文档等）",
    "suggested_action": "keep/remove"
}}

判断标准：
1. 图片必须直接展示或象征关键词相关内容
2. 相关性分数>0.7才视为相关
3. 对于抽象概念，可以接受象征性表达
4. 明显不相关的图片应该被移除""",
            input_variables=["keyword", "image_description"]
        )
        
        # 图片描述生成prompt模板
        self.description_prompt = PromptTemplate(
            template="""请详细描述这张图片的内容，包括：
1. 主要视觉元素（人物、物体、场景等）
2. 颜色、构图、风格特征
3. 可能的背景信息或上下文
4. 整体氛围和情感表达

请提供简洁但全面的描述，便于后续的内容分析。""",
            input_variables=[]
        )
    
    def generate_image_description(self, image_path: str) -> str:
        """生成图片的文字描述"""
        try:
            # 这里简化处理，实际项目中可以使用视觉模型
            # 目前返回基于文件名的简单描述
            filename = os.path.basename(image_path)
            keyword = os.path.basename(os.path.dirname(image_path))
            
            # 模拟图片描述
            description = f"图片文件名: {filename}, 所属关键词: {keyword}, 这是一张与{keyword}相关的图片"
            return description
        except Exception as e:
            print(f"生成图片描述失败: {e}")
            return "无法获取图片描述"
    
    def analyze_image_relevance(self, image_path: str, keyword: str) -> Dict[str, any]:
        """分析单张图片与关键词的相关性"""
        try:
            # 生成图片描述
            image_description = self.generate_image_description(image_path)
            
            # 使用LLM分析相关性
            chain = self.analysis_prompt | self.model | JsonOutputParser()
            result = chain.invoke({
                "keyword": keyword,
                "image_description": image_description
            })
            
            return result
        except Exception as e:
            print(f"图片分析失败: {e}")
            # 出错时默认保留图片
            return {
                "is_relevant": True,
                "relevance_score": 0.5,
                "confidence": 0.3,
                "reason": "分析失败，默认保留",
                "main_elements": [],
                "category": "unknown",
                "suggested_action": "keep"
            }
    
    def batch_analyze_images(self, image_folder: str, keyword: str) -> List[Dict[str, any]]:
        """批量分析文件夹中的图片"""
        results = []
        
        if not os.path.exists(image_folder):
            print(f"图片文件夹不存在: {image_folder}")
            return results
        
        image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'}
        
        for filename in os.listdir(image_folder):
            if any(filename.lower().endswith(ext) for ext in image_extensions):
                image_path = os.path.join(image_folder, filename)
                
                # 分析图片
                analysis = self.analyze_image_relevance(image_path, keyword)
                analysis["image_path"] = image_path
                analysis["filename"] = filename
                
                results.append(analysis)
        
        return results
    
    def filter_and_cleanup_images(self, analysis_results: List[Dict[str, any]], 
                                min_relevance_score: float = 0.7) -> Dict[str, List[str]]:
        """根据分析结果过滤并清理不相关图片"""
        keep_images = []
        remove_images = []
        
        for result in analysis_results:
            if result.get("relevance_score", 0) >= min_relevance_score and result.get("is_relevant", False):
                keep_images.append(result["image_path"])
            else:
                remove_images.append(result["image_path"])
        
        # 删除不相关的图片
        for image_path in remove_images:
            try:
                if os.path.exists(image_path):
                    os.remove(image_path)
                    print(f"已删除不相关图片: {os.path.basename(image_path)}")
            except Exception as e:
                print(f"删除图片失败: {image_path}, 错误: {e}")
        
        return {
            "kept": keep_images,
            "removed": remove_images,
            "keep_count": len(keep_images),
            "remove_count": len(remove_images)
        }
    
    def generate_analysis_report(self, keyword: str, analysis_results: List[Dict[str, any]], 
                               filter_results: Dict[str, List[str]]) -> str:
        """生成分析报告"""
        report = f"""
# 图片内容分析报告

## 关键词: {keyword}

## 分析统计
- 总图片数量: {len(analysis_results)}
- 保留图片数量: {filter_results['keep_count']}
- 删除图片数量: {filter_results['remove_count']}
- 保留率: {filter_results['keep_count']/max(len(analysis_results), 1)*100:.1f}%

## 详细分析结果
"""
        
        for result in analysis_results:
            report += f"""
### {result['filename']}
- 相关性: {'相关' if result['is_relevant'] else '不相关'}
- 相关度分数: {result['relevance_score']}
- 置信度: {result['confidence']}
- 主要原因: {result['reason']}
- 主要元素: {', '.join(result['main_elements'])}
- 处理建议: {result['suggested_action']}
"""
        
        return report
    
    def save_analysis_report(self, keyword: str, report: str, output_dir: str = None):
        """保存分析报告到文件"""
        if output_dir is None:
            output_dir = os.path.join(os.path.dirname(__file__), keyword)
        
        os.makedirs(output_dir, exist_ok=True)
        
        report_file = os.path.join(output_dir, f"{keyword}_analysis_report.md")
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"分析报告已保存: {report_file}")


class ImageQualityChecker:
    """图片质量检查器"""
    
    def __init__(self):
        self.min_width = 100
        self.min_height = 100
        self.max_file_size_mb = 10
    
    def check_image_quality(self, image_path: str) -> Dict[str, any]:
        """检查图片质量"""
        try:
            with Image.open(image_path) as img:
                width, height = img.size
                file_size = os.path.getsize(image_path) / (1024 * 1024)  # MB
                
                issues = []
                
                if width < self.min_width or height < self.min_height:
                    issues.append("图片尺寸过小")
                
                if file_size > self.max_file_size_mb:
                    issues.append("文件过大")
                
                if img.mode not in ['RGB', 'RGBA', 'L']:
                    issues.append("不支持的图片模式")
                
                return {
                    "valid": len(issues) == 0,
                    "width": width,
                    "height": height,
                    "file_size_mb": file_size,
                    "format": img.format,
                    "mode": img.mode,
                    "issues": issues
                }
        except Exception as e:
            return {
                "valid": False,
                "error": str(e)
            }


if __name__ == "__main__":
    # 测试图片分析功能
    analyzer = ImageContentAnalyzer()
    
    # 模拟测试
    test_keyword = "文化大革命"
    test_folder = os.path.join(os.path.dirname(__file__), test_keyword)
    
    if os.path.exists(test_folder):
        print(f"开始分析关键词 '{test_keyword}' 的图片...")
        
        # 批量分析图片
        results = analyzer.batch_analyze_images(test_folder, test_keyword)
        
        # 过滤和清理
        filter_results = analyzer.filter_and_cleanup_images(results)
        
        # 生成报告
        report = analyzer.generate_analysis_report(test_keyword, results, filter_results)
        analyzer.save_analysis_report(test_keyword, report)
        
        print(f"分析完成！保留图片: {filter_results['keep_count']}, 删除图片: {filter_results['remove_count']}")
    else:
        print(f"测试文件夹不存在: {test_folder}")