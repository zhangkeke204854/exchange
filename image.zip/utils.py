"""
工具函数模块
提供重试、资源管理等通用功能
"""

import functools
import time
import shutil
import os
from typing import Callable, Any, Optional, TypeVar, Type
from pathlib import Path
from datetime import datetime, timedelta

from logger import get_logger
from exceptions import ImageCrawlerException

logger = get_logger()

T = TypeVar('T')


def retry_on_failure(
    max_retries: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: tuple = (Exception,)
):
    """
    失败重试装饰器
    
    Args:
        max_retries: 最大重试次数
        delay: 初始延迟时间（秒）
        backoff: 延迟时间的倍增因子
        exceptions: 需要重试的异常类型元组
        
    Returns:
        装饰器函数
        
    Example:
        @retry_on_failure(max_retries=3, delay=1.0)
        def download_image(url):
            # 下载逻辑
            pass
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> T:
            current_delay = delay
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except exceptions as exc:
                    last_exception = exc
                    if attempt < max_retries - 1:
                        logger.warning(
                            f"{func.__name__} 失败 (尝试 {attempt + 1}/{max_retries}): {exc}. "
                            f"将在 {current_delay:.1f}秒后重试..."
                        )
                        time.sleep(current_delay)
                        current_delay *= backoff
                    else:
                        logger.error(
                            f"{func.__name__} 在 {max_retries} 次尝试后仍然失败: {exc}"
                        )
            
            # 所有重试都失败，抛出最后一个异常
            raise last_exception
        
        return wrapper
    return decorator


def check_disk_space(path: str, required_mb: int = 100) -> bool:
    """
    检查磁盘空间是否充足
    
    Args:
        path: 要检查的路径
        required_mb: 所需的最小空间（MB）
        
    Returns:
        bool: 空间是否充足
        
    Raises:
        RuntimeError: 磁盘空间不足时抛出
    """
    try:
        stat = shutil.disk_usage(path)
        free_mb = stat.free / (1024 * 1024)
        
        if free_mb < required_mb:
            error_msg = f"磁盘空间不足: {free_mb:.2f}MB < {required_mb}MB"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
        
        logger.debug(f"磁盘空间检查通过: {free_mb:.2f}MB 可用")
        return True
    except Exception as exc:
        logger.error(f"磁盘空间检查失败: {exc}")
        raise


def cleanup_old_files(directory: str, days: int = 7, pattern: str = "*") -> int:
    """
    清理指定天数之前的文件
    
    Args:
        directory: 要清理的目录
        days: 保留最近N天的文件
        pattern: 文件匹配模式
        
    Returns:
        int: 删除的文件数量
    """
    if not os.path.exists(directory):
        logger.warning(f"目录不存在: {directory}")
        return 0
    
    cutoff_time = datetime.now() - timedelta(days=days)
    deleted_count = 0
    
    try:
        path = Path(directory)
        for file_path in path.rglob(pattern):
            if file_path.is_file():
                file_time = datetime.fromtimestamp(file_path.stat().st_mtime)
                if file_time < cutoff_time:
                    try:
                        file_path.unlink()
                        deleted_count += 1
                        logger.debug(f"删除旧文件: {file_path}")
                    except Exception as exc:
                        logger.warning(f"删除文件失败 {file_path}: {exc}")
        
        logger.info(f"清理完成: 删除了 {deleted_count} 个超过 {days} 天的文件")
        return deleted_count
    
    except Exception as exc:
        logger.error(f"清理文件时出错: {exc}")
        return deleted_count


def ensure_directory(path: str) -> Path:
    """
    确保目录存在，不存在则创建
    
    Args:
        path: 目录路径
        
    Returns:
        Path: 目录路径对象
    """
    dir_path = Path(path)
    dir_path.mkdir(parents=True, exist_ok=True)
    logger.debug(f"确保目录存在: {dir_path}")
    return dir_path


def get_file_size_mb(file_path: str) -> float:
    """
    获取文件大小（MB）
    
    Args:
        file_path: 文件路径
        
    Returns:
        float: 文件大小（MB）
    """
    if not os.path.exists(file_path):
        return 0.0
    return os.path.getsize(file_path) / (1024 * 1024)


def safe_filename(filename: str) -> str:
    """
    将文件名转换为安全的文件名（移除特殊字符）
    
    Args:
        filename: 原始文件名
        
    Returns:
        str: 安全的文件名
    """
    # 移除或替换不安全的字符
    unsafe_chars = '<>:"/\\|?*'
    safe_name = filename
    for char in unsafe_chars:
        safe_name = safe_name.replace(char, '_')
    
    # 移除前后空格
    safe_name = safe_name.strip()
    
    # 限制长度
    max_length = 200
    if len(safe_name) > max_length:
        name, ext = os.path.splitext(safe_name)
        safe_name = name[:max_length - len(ext)] + ext
    
    return safe_name


def format_bytes(bytes_size: int) -> str:
    """
    格式化字节大小为人类可读格式
    
    Args:
        bytes_size: 字节数
        
    Returns:
        str: 格式化后的字符串
    """
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_size < 1024.0:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024.0
    return f"{bytes_size:.2f} PB"


def format_duration(seconds: float) -> str:
    """
    格式化时长为人类可读格式
    
    Args:
        seconds: 秒数
        
    Returns:
        str: 格式化后的字符串
    """
    if seconds < 60:
        return f"{seconds:.1f}秒"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.1f}分钟"
    else:
        hours = seconds / 3600
        return f"{hours:.1f}小时"


class ResourceManager:
    """资源管理器上下文管理器"""
    
    def __init__(self, name: str = "资源"):
        self.name = name
        self.resources = []
        logger.debug(f"初始化资源管理器: {name}")
    
    def add_resource(self, resource: Any, cleanup_func: Optional[Callable] = None):
        """
        添加需要管理的资源
        
        Args:
            resource: 资源对象
            cleanup_func: 清理函数，如果为None则调用resource.close()
        """
        self.resources.append((resource, cleanup_func))
        logger.debug(f"添加资源到管理器: {type(resource).__name__}")
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """清理所有资源"""
        logger.debug(f"开始清理资源: {self.name}")
        for resource, cleanup_func in reversed(self.resources):
            try:
                if cleanup_func:
                    cleanup_func(resource)
                elif hasattr(resource, 'close'):
                    resource.close()
                elif hasattr(resource, 'cleanup'):
                    resource.cleanup()
                logger.debug(f"成功清理资源: {type(resource).__name__}")
            except Exception as exc:
                logger.warning(f"清理资源失败 {type(resource).__name__}: {exc}")
        
        self.resources.clear()
        logger.debug(f"资源清理完成: {self.name}")


if __name__ == "__main__":
    # 测试重试装饰器
    @retry_on_failure(max_retries=3, delay=0.5)
    def test_function():
        import random
        if random.random() < 0.7:
            raise ValueError("随机失败")
        return "成功"
    
    try:
        result = test_function()
        print(f"结果: {result}")
    except Exception as e:
        print(f"最终失败: {e}")
    
    # 测试磁盘空间检查
    check_disk_space(".", required_mb=10)
    
    # 测试文件名安全化
    print(safe_filename("test<file>:name?.txt"))
    
    # 测试格式化
    print(format_bytes(1234567))
    print(format_duration(3665))
