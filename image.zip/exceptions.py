"""
自定义异常类
定义系统中使用的所有自定义异常
"""


class ImageCrawlerException(Exception):
    """图片爬取系统基础异常类"""
    
    def __init__(self, message: str, details: str = None):
        self.message = message
        self.details = details
        super().__init__(self.message)
    
    def __str__(self):
        if self.details:
            return f"{self.message} - 详情: {self.details}"
        return self.message


class ConfigurationError(ImageCrawlerException):
    """配置错误"""
    pass


class KeywordExtractionError(ImageCrawlerException):
    """关键词提取失败"""
    pass


class KeywordExpansionError(ImageCrawlerException):
    """关键词扩展失败"""
    pass


class ImageDownloadError(ImageCrawlerException):
    """图片下载失败"""
    pass


class ImageAnalysisError(ImageCrawlerException):
    """图片分析失败"""
    pass


class ClassificationError(ImageCrawlerException):
    """分类失败"""
    pass


class NetworkError(ImageCrawlerException):
    """网络错误"""
    pass


class StorageError(ImageCrawlerException):
    """存储错误"""
    pass


class ValidationError(ImageCrawlerException):
    """验证错误"""
    pass


class LLMError(ImageCrawlerException):
    """LLM调用错误"""
    pass


class WorkflowError(ImageCrawlerException):
    """工作流执行错误"""
    pass
