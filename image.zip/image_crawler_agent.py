"""
基于LangGraph的agent驱动图片爬取工作流
集成关键词提炼与扩展、图片下载、内容审核与分类的完整agent系统
"""
import os
import csv
import json
import asyncio
import shutil
from datetime import datetime
from typing import Annotated, Any, Dict, List, Optional, Set, TypedDict, Tuple
from langchain_deepseek import ChatDeepSeek
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.types import Checkpointer
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage

from keyword_expansion import KeywordExpansion
from image_analyzer import ImageContentAnalyzer
import get_image_url
import requests_download
import playwright_download



class ImageCrawlerState(TypedDict, total=False):
    """LangGraph状态定义"""
    topic: str
    last_prompt: str
    latest_user_input: str
    keywords: List[str]
    expanded_keywords: List[str]
    current_keyword: str
    downloaded_images: List[str]
    download_manifest: List[Dict[str, str]]
    analysis_results: List[Dict[str, Any]]
    classification_csv: str
    download_status: Dict[str, str]
    analysis_status: Dict[str, str]
    messages: Annotated[List[BaseMessage], add_messages]
    iteration: int
    max_iterations: int
    route: str
    tool_response: Dict[str, Any]
    tool_response_ready: bool
    pending_prompt: str


class ImageCrawlerAgent:
    """Agent中心路由器"""

    def __init__(self):
        self.keyword_expander = KeywordExpansion()
        self.image_analyzer = ImageContentAnalyzer()
        self.model = ChatDeepSeek(model="deepseek-chat")
        
        self.date_time = datetime.now().strftime("%Y%m%d%H%M%S")
        self.save_path = os.path.join(os.path.dirname(__file__), "images_result", self.date_time)
        os.makedirs(self.save_path, exist_ok=True)

        self.checkpointer: Checkpointer = MemorySaver()
        self.workflow = self._create_workflow()
        self.app = self.workflow.compile(checkpointer=self.checkpointer)
        
        self._render_workflow_graph()

        self._active_threads: Set[str] = set()

        # Agent中心路由器prompt模板
        self.router_instructions = PromptTemplate(
            template="""
            # 图片处理智能体调度指南

            ## 角色定位
            你是图片处理工作流的智能调度员，负责分析用户意图并选择最合适的处理动作。

            ## 可用动作库
            **chat** - 用户闲聊、提问或无需工具执行时
            **extract_keywords** - 从用户描述中提炼或重新提炼关键词
            **expand_keywords** - 基于现有关键词扩展相似词汇
            **download_images** - 根据关键词执行图片搜索与下载
            **analyze_images** - 对下载图片进行审核、去重和清理
            **classify_keywords** - 按风险等级对关键词和图片分类并生成CSV

            ## 决策规则

            ### 🎯 动作选择标准
            | 用户意图特征 | 对应动作 | 典型输入示例 |
            |------------|----------|-------------|
            | 包含"提炼/提取/生成关键词" | extract_keywords | "帮我把这段描述提炼成关键词" |
            | 包含"扩展/补充/更多关键词" | expand_keywords | "基于这些词再扩展一些相似词" |
            | 包含"下载/搜索图片" | download_images | "用这些关键词下载图片" |
            | 包含"审核/检查/清理图片" | analyze_images | "分析一下刚下载的图片质量" |
            | 包含"分类/风险评估/生成报告" | classify_keywords | "对这些关键词做风险分类" |
            | 纯问答、解释、总结需求 | chat | "这个功能怎么用？" |

            ### 🔄 重新执行处理
            - **关键词重提炼**：当用户对当前关键词不满意要求"重新提炼"时 → `extract_keywords`
            - **关键词重扩展**：当用户要求"重新扩展"或"换一批相似词"时 → `expand_keywords`  
            - **图片重下载**：当用户对下载结果不满意要求"重新下载"时 → `download_images`
            - **设置** `use_previous_prompt=true`：当用户明确要求"沿用上次描述"时

            ### 📝 展示规范
            - 提炼/扩展的关键词使用**加粗**突出
            - 多个关键词建议使用Markdown表格展示
            - 每次动作执行后明确提示下一步操作建议

            ## 当前会话状态
            **上下文记录**: {context_snapshot}
            **最新用户输入**: "{user_input_text}"

            ## 输出格式
            ```json
            {{
                "action": "chat|extract_keywords|expand_keywords|download_images|analyze_images|classify_keywords",
                "use_previous_prompt": true|false,
                "reason": "基于用户意图和上下文的具体分析"
            }}
            """, input_variables=["context_snapshot", "user_input_text"])
        
        # 使用PromptTemplate构建分类提示词
        self.classification = PromptTemplate(
            template="""你是专业的风险分类助手，负责对关键词进行准确的风险分类。
            ## 任务说明
            请根据提供的风险标签列表，为每个关键词选择一个最匹配的风险类别。
            每个关键词只能选择一个标签，请选择最主要、最直接相关的风险类别。

            ## 风险标签列表
            {risk_labels}

            ## 分类指南
            - 仔细分析关键词的语义和潜在风险
            - 考虑关键词在实际使用场景中可能带来的影响
            - 如果关键词涉及多个风险类别，选择最主要的一个
            - 必须提供清晰的判断依据

            ## 输入数据
            {input_data}

            ## 输出要求
            请严格按照以下JSON格式输出，不要添加任何额外的文字说明：

            {{
            "classifications": [
                {{
                "keyword": "关键词内容",
                "label": "选择的风险标签（必须从上述风险标签列表中选择）",
                "reason": "分类依据的详细说明（50字以内）"
                }}
            ]
            }}

            注意：
            1. 必须为输入数据中的每个关键词都提供分类结果
            2. label字段必须是上述风险标签列表中的一个
            3. reason字段要简洁明了，说明为什么选择该标签
            4. 只返回JSON，不要添加markdown代码块标记或其他文字
            """, input_variables=["risk_labels", "input_data"])

        # 定义风险标签
        self.RISK_LABELS = [
            "暴力与行为伤害",
            "性相关风险",
            "犯罪与违法活动",
            "仇恨、不公与心理伤害",
            "隐私与个人安全",
            "虚假信息与不当影响",
            "框架、体制和国家安全",
            "版权与知识产权",
            "灾害、紧急与敏感事件"
        ]

    def _render_workflow_graph(self) -> None:
        target_file = os.path.join(os.path.dirname(__file__), "workflow.png")
        try:
            with open(target_file, "wb") as f:
                f.write(self.app.get_graph().draw_mermaid_png(max_retries=5, retry_delay=2.0))
        except Exception as exc:
            print(f"⚠️ 无法保存 workflow.png: {exc}")

    def _create_workflow(self) -> StateGraph:
        workflow = StateGraph(ImageCrawlerState)

        workflow.add_node("agent", self._agent_node)
        workflow.add_node("extract_keywords", self._extract_keywords_node)
        workflow.add_node("expand_keywords", self._expand_keywords_node)
        workflow.add_node("download_images", self._download_images_node)
        workflow.add_node("analyze_images", self._analyze_images_node)
        workflow.add_node("classify_keywords", self._classify_keywords_node)

        workflow.add_edge(START, "agent")
        workflow.add_conditional_edges(
            "agent",
            self._route_from_agent,
            {
                "extract_keywords": "extract_keywords",
                "expand_keywords": "expand_keywords",
                "download_images": "download_images",
                "analyze_images": "analyze_images",
                "classify_keywords": "classify_keywords",
                "finish": END,
            },
        )

        workflow.add_edge("extract_keywords", "agent")
        workflow.add_edge("expand_keywords", "agent")
        workflow.add_edge("download_images", "agent")
        workflow.add_edge("analyze_images", "agent")
        workflow.add_edge("classify_keywords", "agent")

        return workflow

    # -----------------------------
    # Agent核心逻辑
    # -----------------------------
    def _agent_node(self, state: ImageCrawlerState) -> Dict[str, Any]:
        # 如果有工具结果需要汇报，优先总结
        if state.get("tool_response_ready"):
            summary = self._summarize_tool_response(state)
            return {
                "messages": [AIMessage(content=summary)],
                "route": "finish",
                "tool_response_ready": False,
                "tool_response": {},
            }

        latest_user_input = state.get("latest_user_input") or self._get_latest_user_message(
            state.get("messages", [])
        )

        selection_update = self._handle_keyword_selection(latest_user_input or "", state)
        if selection_update:
            return selection_update

        if not latest_user_input:
            return {"route": "finish"}

        decision = self._decide_next_action(latest_user_input, state)
        action = decision.get("action", "chat")
        use_previous_prompt = decision.get("use_previous_prompt", False)

        if action == "chat":
            reply = self._generate_chat_response(state.get("messages", []))
            return {
                "messages": [AIMessage(content=reply)],
                "route": "finish",
                "last_prompt": latest_user_input or state.get("last_prompt", ""),
            }

        if action == "extract_keywords":
            prompt_text = self._resolve_prompt(latest_user_input, state, use_previous_prompt)
            return {
                "pending_prompt": prompt_text,
                "last_prompt": prompt_text,
                "topic": prompt_text,
                "route": "extract_keywords",
            }

        if action == "expand_keywords":
            return {"route": "expand_keywords"}

        if action == "download_images":
            return {"route": "download_images"}

        if action == "analyze_images":
            return {"route": "analyze_images"}

        if action == "classify_keywords":
            return {"route": "classify_keywords"}

        # 默认回到聊天
        reply = self._generate_chat_response(state.get("messages", []))
        return {"messages": [AIMessage(content=reply)], "route": "finish"}

    def _route_from_agent(self, state: ImageCrawlerState) -> str:
        return state.get("route", "finish")

    def _get_latest_user_message(self, messages: List[BaseMessage]) -> str:
        for message in reversed(messages):
            if isinstance(message, HumanMessage):
                return message.content
        return ""

    def _generate_chat_response(self, messages: List[BaseMessage]) -> str:
        try:
            response = self.model.invoke(messages)
            return response.content if hasattr(response, "content") else str(response)
        except Exception as exc:
            return f"抱歉，我暂时无法回答该问题，错误信息：{exc}"

    def _stringify_input(self, value: Any) -> str:
        if isinstance(value, str):
            return value
        if isinstance(value, (list, tuple)):
            parts = [self._stringify_input(item) for item in value if item is not None]
            return "\n".join(part for part in parts if part)
        if hasattr(value, "content"):
            return self._stringify_input(getattr(value, "content"))
        if value is None:
            return ""
        return str(value)

    def _decide_next_action(self, user_input: Any, state: ImageCrawlerState) -> Dict[str, Any]:
        user_input_text = self._stringify_input(user_input)
        context_snapshot = json.dumps(
            {
                "keywords": state.get("keywords", []),
                "expanded_keywords": state.get("expanded_keywords", []),
                "downloaded_images": len(state.get("download_manifest", [])),
                "analysis_completed": len(state.get("analysis_results", [])) > 0,
                "has_classification": bool(state.get("classification_csv")),
            },
            ensure_ascii=False,
        )

        try:
            chain = self.router_instructions | self.model | JsonOutputParser()
            response = chain.invoke({"context_snapshot": context_snapshot, "user_input_text": user_input_text})
            parsed = self._safe_json_parse(response)
        except Exception:
            parsed = {}

        if not parsed or parsed.get("action") not in {
            "chat",
            "extract_keywords",
            "expand_keywords",
            "download_images",
            "analyze_images",
            "classify_keywords",
        }:
            lower_input = user_input_text.lower()
            if any(keyword in lower_input for keyword in ["提炼", "关键词", "prompt"]):
                fallback = "extract_keywords"
            elif "扩展" in lower_input or "更多" in lower_input:
                fallback = "expand_keywords"
            elif "下载" in lower_input or "图片" in lower_input:
                fallback = "download_images"
            elif "分析" in lower_input or "过滤" in lower_input:
                fallback = "analyze_images"
            elif "分类" in lower_input or "csv" in lower_input:
                fallback = "classify_keywords"
            else:
                fallback = "chat"
            parsed = {"action": fallback, "use_previous_prompt": False}

        return parsed

    def _safe_json_parse(self, response: Any) -> Dict[str, Any]:
        text = response.content if hasattr(response, "content") else str(response)
        text = text.strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            start = text.find("{")
            end = text.rfind("}")
            if start != -1 and end != -1 and end > start:
                try:
                    return json.loads(text[start : end + 1])
                except json.JSONDecodeError:
                    return {}
        return {}

    def _resolve_prompt(self, user_input: Any, state: ImageCrawlerState, use_previous: bool) -> str:
        if use_previous and state.get("last_prompt"):
            return state["last_prompt"]
        cleaned = self._stringify_input(user_input).strip()
        if cleaned:
            return cleaned
        return state.get("last_prompt", "")

    def _handle_keyword_selection(self, user_input: str, state: ImageCrawlerState) -> Optional[Dict[str, Any]]:
        if not user_input:
            return None

        normalized_input = self._stringify_input(user_input).strip()
        if not normalized_input:
            return None

        lower_input = normalized_input.lower()
        selection_triggers = [
            "只保留",
            "仅保留",
            "只留下",
            "仅留下",
            "只要",
            "只需要",
            "只要保留",
            "去掉其他",
            "删掉其他",
            "keep only",
        ]

        if not any(trigger in lower_input for trigger in selection_triggers):
            return None

        keywords = state.get("keywords", []) or []
        expanded_keywords = state.get("expanded_keywords", []) or []

        keyword_matches = self._match_keywords_in_text(normalized_input, keywords)
        expanded_matches = self._match_keywords_in_text(normalized_input, expanded_keywords)

        target = None
        selected: List[str] = []

        if expanded_matches and (len(expanded_matches) >= len(keyword_matches) or not keyword_matches):
            target = "expanded"
            selected = expanded_matches
        elif keyword_matches:
            target = "keywords"
            selected = keyword_matches

        if not target or not selected:
            return None

        target_label = "扩展关键词" if target == "expanded" else "关键词"
        detail = f"已根据你的要求保留{target_label}: {', '.join(selected)}。其余已移除。"

        update: Dict[str, Any] = {
            "messages": [AIMessage(content=detail)],
            "route": "finish",
            "tool_response_ready": False,
            "tool_response": {},
        }

        if target == "expanded":
            update["expanded_keywords"] = selected
        else:
            update["keywords"] = selected
            if selected:
                update["topic"] = selected[0]

        return update

    def _match_keywords_in_text(self, text: str, candidates: List[str]) -> List[str]:
        if not text or not candidates:
            return []
        lower_text = text.lower()
        matches: List[str] = []
        seen: Set[str] = set()
        for keyword in candidates:
            if not keyword:
                continue
            key_lower = keyword.lower()
            if key_lower in lower_text or keyword in text:
                if keyword not in seen:
                    matches.append(keyword)
                    seen.add(keyword)
        return matches

    def _reset_keyword_download_data(self, keyword: str, downloaded_images: List[str], manifest: List[Dict[str, str]]) -> Tuple[List[str], List[Dict[str, str]]]:
        """移除指定关键词的历史下载记录与文件，方便重新尝试"""
        keyword_dir = os.path.join(self.save_path, keyword)
        normalized_dir = os.path.normcase(os.path.abspath(keyword_dir))
        normalized_dir_with_sep = normalized_dir + os.sep

        filtered_images: List[str] = []
        for path in downloaded_images:
            abs_path = os.path.normcase(os.path.abspath(path))
            if abs_path.startswith(normalized_dir_with_sep):
                continue
            filtered_images.append(path)
        filtered_manifest = [
            item for item in manifest if item.get("keyword") != keyword
        ]

        if os.path.exists(keyword_dir):
            try:
                shutil.rmtree(keyword_dir)
            except Exception as exc:
                print(f"清理关键词 '{keyword}' 旧文件失败: {exc}")

        return filtered_images, filtered_manifest

    def _summarize_tool_response(self, state: ImageCrawlerState) -> str:
        tool_response = state.get("tool_response", {})
        summary = tool_response.get("summary", "工具执行完成")
        details = tool_response.get("details", "")
        next_hint = "如需继续，请输入新的指令，我会再次为你选择合适的工具。"
        if details:
            return f"{summary}\n{details}\n{next_hint}"
        return f"{summary}\n{next_hint}"

    # -----------------------------
    # 工具节点
    # -----------------------------
    def _extract_keywords_node(self, state: ImageCrawlerState) -> Dict[str, Any]:
        prompt_text = (
            state.get("pending_prompt")
            or state.get("last_prompt")
            or state.get("latest_user_input")
            or state.get("topic", "")
        )

        print(f"正在从描述中提炼关键词: {prompt_text}")
        extracted = self.keyword_expander.extract_keywords_from_prompt(prompt_text)
        keywords = [item.get("keyword", "") for item in extracted if item.get("keyword")]
        topic = keywords[0] if keywords else prompt_text

        details = (
            f"关键词: {', '.join(keywords)}"
            if keywords
            else "未能提炼出有效关键词，请尝试提供更具体的描述。"
        )

        return {
            "topic": topic,
            "keywords": keywords,
            "pending_prompt": "",
            "tool_response": {
                "tool": "extract_keywords",
                "summary": "关键词提炼完成。",
                "details": details,
                "data": extracted,
            },
            "tool_response_ready": True,
            "route": "finish",
        }

    def _expand_keywords_node(self, state: ImageCrawlerState) -> Dict[str, Any]:
        base_keywords = state.get("keywords") or state.get("expanded_keywords") or []
        if not base_keywords and state.get("topic"):
            base_keywords = [state["topic"]]

        print(f"正在扩展关键词: {base_keywords}")

        expanded: List[str] = []
        for keyword in base_keywords:
            try:
                expanded.extend(self.keyword_expander.get_expanded_keywords_for_topic(keyword))
            except Exception as exc:
                print(f"扩展关键词失败 {keyword}: {exc}")

        deduplicated = list(dict.fromkeys(expanded))
        details = (
            f"扩展关键词: {', '.join(deduplicated)}"
            if deduplicated
            else "未能扩展出新的关键词，请尝试重新提炼。"
        )

        return {
            "expanded_keywords": deduplicated,
            "tool_response": {
                "tool": "expand_keywords",
                "summary": "关键词扩展完成。",
                "details": details,
                "data": deduplicated,
            },
            "tool_response_ready": True,
            "route": "finish",
        }

    def _download_images_node(self, state: ImageCrawlerState) -> Dict[str, Any]:
        keywords = state.get("expanded_keywords") or state.get("keywords") or []
        downloaded_images = list(state.get("downloaded_images", []))
        manifest = list(state.get("download_manifest", []))
        download_status = dict(state.get("download_status", {}))
        downloaded_keyword_set = {entry.get("keyword") for entry in manifest if entry.get("keyword")}
        skipped_completed_keywords: List[str] = []
        retried_keywords: List[str] = []
        keywords_with_errors: List[str] = []
        initial_download_count = len(downloaded_images)

        if not keywords:
            return {
                "tool_response": {
                    "tool": "download_images",
                    "summary": "暂无可用关键词，无法执行下载。",
                    "details": "请先完成关键词提炼或扩展。",
                },
                "download_status": download_status,
                "tool_response_ready": True,
                "route": "finish",
            }

        for keyword in keywords:
            status = download_status.get(keyword)
            if status == "success":
                print(f"关键词 '{keyword}' 已完成下载，跳过重复请求。")
                skipped_completed_keywords.append(keyword)
                continue

            if status == "failed":
                downloaded_images, manifest = self._reset_keyword_download_data(
                    keyword, downloaded_images, manifest
                )
                downloaded_keyword_set.discard(keyword)
                retried_keywords.append(keyword)

            if keyword in downloaded_keyword_set:
                print(f"关键词 '{keyword}' 已在本轮任务中下载，跳过。")
                skipped_completed_keywords.append(keyword)
                download_status[keyword] = "success"
                continue

            print(f"正在下载关键词 '{keyword}' 的图片...")
            img_url_list = get_image_url.get_keyword_image(keyword)

            if not img_url_list:
                print(f"关键词 '{keyword}' 未找到图片")
                download_status[keyword] = "failed"
                keywords_with_errors.append(keyword)
                continue

            save_dir = os.path.join(self.save_path, keyword)
            os.makedirs(save_dir, exist_ok=True)
            tasks = [
                (os.path.join(save_dir, f"{index}.png"), url)
                for index, url in enumerate(img_url_list)
            ]

            success_list, initial_failed_list = requests_download.save_image(tasks, max_workers=20)
            final_failed_list = initial_failed_list

            if initial_failed_list:
                temp_success_list, temp_failed_list = playwright_download.save_image(initial_failed_list, max_workers=10)
                if temp_success_list:
                    success_list.extend(temp_success_list)
                final_failed_list = temp_failed_list

            for file_path, url in success_list:
                downloaded_images.append(file_path)
                manifest.append({"keyword": keyword, "img_file": file_path, "img_url": url})
            if success_list:
                downloaded_keyword_set.add(keyword)

            had_errors = bool(final_failed_list) or not success_list
            if had_errors:
                download_status[keyword] = "failed"
                keywords_with_errors.append(keyword)
            else:
                download_status[keyword] = "success"

            print(f"关键词 '{keyword}' 图片下载完成，成功 {len(success_list)} 张，失败 {len(final_failed_list)} 张")

        summary_parts: List[str] = []
        if skipped_completed_keywords:
            summary_parts.append(f"跳过已完成关键词: {', '.join(skipped_completed_keywords)}。")
        if retried_keywords:
            summary_parts.append(f"重新尝试关键词: {', '.join(retried_keywords)}。")
        if keywords_with_errors:
            summary_parts.append(f"以下关键词下载存在错误，可在修复后重试: {', '.join(keywords_with_errors)}。")
        new_download_count = len(downloaded_images) - initial_download_count
        if new_download_count > 0:
            summary_parts.append(f"本轮新增下载 {new_download_count} 张图片。")
        else:
            summary_parts.append("暂未成功下载任何图片。")
        summary = " ".join(summary_parts)

        return {
            "downloaded_images": downloaded_images,
            "download_manifest": manifest,
            "download_status": download_status,
            "tool_response": {
                "tool": "download_images",
                "summary": "图片下载完成。",
                "details": summary,
                "data": manifest,
            },
            "tool_response_ready": True,
            "route": "finish",
        }

    def _analyze_images_node(self, state: ImageCrawlerState) -> Dict[str, Any]:
        keywords = state.get("expanded_keywords") or state.get("keywords") or []
        existing_results = state.get("analysis_results", []) or []
        analysis_status = dict(state.get("analysis_status", {}))
        analysis_map: Dict[str, Dict[str, Any]] = {
            entry.get("keyword"): entry for entry in existing_results if entry.get("keyword")
        }
        processed_keywords: List[str] = []
        skipped_keywords: List[str] = []
        retried_keywords: List[str] = []
        failed_keywords: List[str] = []

        if not keywords:
            return {
                "tool_response": {
                    "tool": "analyze_images",
                    "summary": "暂无关键词可用于分析。",
                    "details": "请先完成关键词提炼或扩展并下载图片。",
                },
                "analysis_status": analysis_status,
                "tool_response_ready": True,
                "route": "finish",
            }

        for keyword in keywords:
            status = analysis_status.get(keyword)
            existing_entry = analysis_map.get(keyword)

            if status == "success" and existing_entry and existing_entry.get("status", "success") == "success":
                print(f"关键词 '{keyword}' 图片已完成分析，跳过。")
                skipped_keywords.append(keyword)
                continue

            if status == "failed":
                retried_keywords.append(keyword)
                if existing_entry:
                    analysis_map.pop(keyword, None)

            image_folder = os.path.join(self.save_path, keyword)
            if not os.path.exists(image_folder):
                continue

            print(f"正在分析关键词 '{keyword}' 的图片...")
            try:
                results = self.image_analyzer.batch_analyze_images(image_folder, keyword, max_workers=10)
                filter_results = self.image_analyzer.filter_and_cleanup_images(results)
                analysis_map[keyword] = {
                    "keyword": keyword,
                    "total_images": len(results),
                    "kept_images": filter_results["keep_count"],
                    "removed_images": filter_results["remove_count"],
                    "filter_results": filter_results,
                    "status": "success",
                }
                analysis_status[keyword] = "success"
                processed_keywords.append(keyword)
            except Exception as exc:
                print(f"分析关键词 '{keyword}' 时发生错误: {exc}")
                analysis_map[keyword] = {
                    "keyword": keyword,
                    "total_images": 0,
                    "kept_images": 0,
                    "removed_images": 0,
                    "filter_results": {},
                    "status": "failed",
                    "error": str(exc),
                }
                analysis_status[keyword] = "failed"
                failed_keywords.append(keyword)

        analysis_results = list(analysis_map.values())
        summary_parts: List[str] = []
        if processed_keywords:
            summary_parts.append(f"已完成 {len(processed_keywords)} 个关键词的图片审核。")
        if skipped_keywords:
            summary_parts.append(f"跳过已分析关键词: {', '.join(skipped_keywords)}。")
        if retried_keywords:
            summary_parts.append(f"重新分析关键词: {', '.join(retried_keywords)}。")
        if failed_keywords:
            summary_parts.append(f"以下关键词分析失败，可重试: {', '.join(failed_keywords)}。")
        if not summary_parts:
            summary_parts.append("未找到可分析的图片文件。")
        summary = " ".join(summary_parts)

        return {
            "analysis_results": analysis_results,
            "analysis_status": analysis_status,
            "tool_response": {
                "tool": "analyze_images",
                "summary": "图片分析完成。",
                "details": summary,
                "data": analysis_results,
            },
            "tool_response_ready": True,
            "route": "finish",
        }

    def _classify_keywords_node(self, state: ImageCrawlerState) -> Dict[str, Any]:
        """对关键词进行风险分类并生成CSV报告"""
        manifest = state.get("download_manifest", [])
        if not manifest:
            return {
                "tool_response": {
                    "tool": "classify_keywords",
                    "summary": "尚未下载任何图片，无法分类。",
                    "details": "请先完成图片下载。",
                },
                "tool_response_ready": True,
                "route": "finish",
            }

        # 按关键词分组
        keyword_groups: Dict[str, List[Dict[str, str]]] = {}
        for item in manifest:
            keyword_groups.setdefault(item["keyword"], []).append(item)

        print(f"正在对 {len(keyword_groups)} 个关键词进行风险分类...")

        # 构建分类输入数据
        input_data = {
            "keywords": [
                {
                    "keyword": keyword,
                    "image_count": len(entries),
                    "sample_images": [
                        os.path.basename(entry["img_file"])
                        for entry in entries[:5]
                    ],
                }
                for keyword, entries in keyword_groups.items()
            ]
        }

        # 使用chain链格式调用LLM进行分类
        classifications = []
        try:
            chain = self.classification | self.model | JsonOutputParser()
            response = chain.invoke({"risk_labels": ', '.join(self.RISK_LABELS), "input_data": json.dumps(input_data, ensure_ascii=False)})
            classifications = response.get("classifications", [])
            print(f"LLM分类成功，返回 {len(classifications)} 个分类结果")
        except Exception as exc:
            print(f"⚠️ LLM分类失败: {exc}")
            # 降级处理：为所有关键词设置默认分类
            classifications = [{"keyword": kw, "label": "未分类", "reason": "分类服务异常"} for kw in keyword_groups.keys()]

        # 构建关键词到标签的映射（包含原因）
        label_map = {}
        reason_map = {}
        for item in classifications:
            keyword = item.get("keyword", "")
            if keyword:
                label_map[keyword] = item.get("label", "未知")
                reason_map[keyword] = item.get("reason", "")

        # 为未分类的关键词添加默认标签
        for keyword in keyword_groups.keys():
            if keyword not in label_map:
                label_map[keyword] = "未分类"
                reason_map[keyword] = "未获得分类结果"

        # 生成CSV文件
        csv_file = os.path.join(self.save_path, f"{state.get('topic', 'task')}_classification.csv")
        os.makedirs(os.path.dirname(csv_file), exist_ok=True)

        with open(csv_file, "w", encoding="utf-8-sig", newline="") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["keyword", "label", "reason", "img_file", "img_url"])
            for entry in manifest:
                keyword = entry["keyword"]
                label = label_map.get(keyword, "未分类")
                reason = reason_map.get(keyword, "")
                writer.writerow([keyword, label, reason, entry["img_file"], entry["img_url"]])

        # 统计分类分布
        label_distribution = {}
        for label in label_map.values():
            label_distribution[label] = label_distribution.get(label, 0) + 1

        # 构建详细的统计信息
        stats_lines = [
            f"✅ 分类完成，共处理 {len(keyword_groups)} 个关键词，{len(manifest)} 张图片",
            f"📊 分类分布: {', '.join(f'{k}({v})' for k, v in label_distribution.items())}",
            f"📄 CSV文件: {csv_file}"
        ]
        details = "\n".join(stats_lines)

        print(f"分类完成: {len(keyword_groups)} 个关键词已分类")
        print(f"CSV文件已保存: {csv_file}")

        return {
            "classification_csv": csv_file,
            "tool_response": {
                "tool": "classify_keywords",
                "summary": "关键词分类和CSV导出完成。",
                "details": details,
                "data": {
                    "label_map": label_map,
                    "distribution": label_distribution,
                    "total_keywords": len(keyword_groups),
                    "total_images": len(manifest),
                },
            },
            "tool_response_ready": True,
            "route": "finish",
        }

    # -----------------------------
    # 会话控制
    # -----------------------------
    def _initial_state(self, user_input: str, max_iterations: int) -> ImageCrawlerState:
        return {
            "topic": user_input,
            "last_prompt": user_input,
            "latest_user_input": user_input,
            "keywords": [],
            "expanded_keywords": [],
            "current_keyword": "",
            "downloaded_images": [],
            "download_manifest": [],
            "analysis_results": [],
            "classification_csv": "",
            "download_status": {},
            "analysis_status": {},
            "messages": [HumanMessage(content=user_input)],
            "iteration": 0,
            "max_iterations": max_iterations,
            "route": "finish",
            "tool_response": {},
            "tool_response_ready": False,
            "pending_prompt": user_input,
        }

    def _prepare_thread_payload(self, user_input: str, max_iterations: int, thread_id: Optional[str]) -> Tuple[Dict[str, Any], str]:
        if not thread_id:
            thread_id = f"default-thread-{self.date_time}"

        if thread_id not in self._active_threads:
            payload = self._initial_state(user_input, max_iterations)
            self._active_threads.add(thread_id)
        else:
            payload = {
                "latest_user_input": user_input,
                "messages": [HumanMessage(content=user_input)],
                "pending_prompt": user_input,
            }
        return payload, thread_id

    def run(self, user_input: str, max_iterations: int = 2, thread_id: Optional[str] = None) -> Dict[str, Any]:
        """单轮执行：根据用户输入触发工作流"""
        payload, resolved_thread_id = self._prepare_thread_payload(user_input, max_iterations, thread_id)
        config = {"configurable": {"thread_id": resolved_thread_id}}
        result = self.app.invoke(payload, config=config)
        return result

    def stream(self, user_input: str, max_iterations: int = 2, thread_id: Optional[str] = None, stream_mode: str = "messages"):
        """以流式方式执行工作流"""
        payload, resolved_thread_id = self._prepare_thread_payload(user_input, max_iterations, thread_id)
        config = {"configurable": {"thread_id": resolved_thread_id}}
        return self.app.stream(payload, config=config, stream_mode=stream_mode)


def _ensure_windows_subprocess_support() -> None:
    """确保asyncio可以在Windows工作线程上生成子进程。"""
    if os.name != "nt":
        return

    policy_name = "WindowsProactorEventLoopPolicy"
    if not hasattr(asyncio, policy_name):
        return

    current = asyncio.get_event_loop_policy()
    desired_cls = getattr(asyncio, policy_name)

    if isinstance(current, desired_cls):
        return

    try:
        asyncio.set_event_loop_policy(desired_cls())
        print("🔧 已启用 Windows Proactor 事件循环，以支持 Playwright 子进程。")
    except Exception as exc:
        print(f"⚠️ 无法设置 Windows Proactor 事件循环: {exc}")


_ensure_windows_subprocess_support()

image_crawler_agent = ImageCrawlerAgent()
graph = image_crawler_agent.workflow
