"""
基于LangGraph的agent驱动图片爬取工作流
集成关键词扩展、图片下载、内容审核与分类的完整agent系统
"""
import os
import csv
import json
import asyncio
import traceback
from datetime import datetime
from typing import Annotated, Any, Dict, List, Optional, Set, TypedDict
from langchain_deepseek import ChatDeepSeek
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.types import Checkpointer

from keyword_expansion import KeywordExpansion
from image_analyzer import ImageContentAnalyzer
import get_image_url
import requests_download
import playwright_download
from blocking_fix import safe_makedirs, safe_write_csv


RISK_LABELS = [
    "暴力与行为伤害",
    "性相关风险",
    "犯罪与违法活动",
    "仇恨、不公与心理伤害",
    "隐私与个人安全",
    "虚假信息与不当影响",
    "框架、体制和国家安全",
    "版权与知识产权",
    "灾害、紧急与敏感事件",
]


class ImageCrawlerState(TypedDict, total=False):
    """LangGraph状态定义"""

    topic: str
    last_prompt: str
    latest_user_input: str
    keywords: List[str]
    expanded_keywords: List[str]
    current_keyword: str
    downloaded_images: List[str]
    download_manifest: List[Dict[str, str]]
    analysis_results: List[Dict[str, Any]]
    classification_csv: str
    messages: Annotated[List[BaseMessage], add_messages]
    iteration: int
    max_iterations: int
    route: str
    tool_response: Dict[str, Any]
    tool_response_ready: bool
    pending_prompt: str


class ImageCrawlerAgent:
    """Agent中心路由器"""

    def __init__(self):
        self.keyword_expander = KeywordExpansion()
        self.image_analyzer = ImageContentAnalyzer()
        self.model = ChatDeepSeek(model="deepseek-chat")
        self.date_time = datetime.now().strftime("%Y%m%d%H%M%S")
        self.save_path = os.path.join(os.path.dirname(__file__), "images_result", self.date_time)
        self.checkpointer: Checkpointer = MemorySaver()
        self.workflow = self._create_workflow()
        self.app = self.workflow.compile()

        self._active_threads: Set[str] = set()

    def _create_workflow(self) -> StateGraph:
        workflow = StateGraph(ImageCrawlerState)

        workflow.add_node("agent", self._agent_node)
        workflow.add_node("extract_keywords", self._extract_keywords_node)
        workflow.add_node("expand_keywords", self._expand_keywords_node)
        workflow.add_node("download_images", self._download_images_node)
        workflow.add_node("analyze_images", self._analyze_images_node)
        workflow.add_node("classify_keywords", self._classify_keywords_node)

        workflow.add_edge(START, "agent")
        workflow.add_conditional_edges(
            "agent",
            self._route_from_agent,
            {
                "extract_keywords": "extract_keywords",
                "expand_keywords": "expand_keywords",
                "download_images": "download_images",
                "analyze_images": "analyze_images",
                "classify_keywords": "classify_keywords",
                "finish": END,
            },
        )

        workflow.add_edge("extract_keywords", "agent")
        workflow.add_edge("expand_keywords", "agent")
        workflow.add_edge("download_images", "agent")
        workflow.add_edge("analyze_images", "agent")
        workflow.add_edge("classify_keywords", "agent")

        return workflow

    # -----------------------------
    # Agent核心逻辑
    # -----------------------------
    def _agent_node(self, state: ImageCrawlerState) -> Dict[str, Any]:
        # 如果有工具结果需要汇报，优先总结
        if state.get("tool_response_ready"):
            summary = self._summarize_tool_response(state)
            return {
                "messages": [AIMessage(content=summary)],
                "route": "finish",
                "tool_response_ready": False,
                "tool_response": {},
            }

        latest_user_input = state.get("latest_user_input") or self._get_latest_user_message(
            state.get("messages", [])
        )

        if not latest_user_input:
            return {"route": "finish"}

        decision = self._decide_next_action(latest_user_input, state)
        action = decision.get("action", "chat")
        use_previous_prompt = decision.get("use_previous_prompt", False)

        if action == "chat":
            reply = self._generate_chat_response(latest_user_input, state)
            return {
                "messages": [AIMessage(content=reply)],
                "route": "finish",
                "last_prompt": latest_user_input or state.get("last_prompt", ""),
            }

        if action == "extract_keywords":
            prompt_text = self._resolve_prompt(latest_user_input, state, use_previous_prompt)
            return {
                "pending_prompt": prompt_text,
                "last_prompt": prompt_text,
                "topic": prompt_text,
                "route": "extract_keywords",
            }

        if action == "expand_keywords":
            return {"route": "expand_keywords"}

        if action == "download_images":
            return {"route": "download_images"}

        if action == "analyze_images":
            return {"route": "analyze_images"}

        if action == "classify_keywords":
            return {"route": "classify_keywords"}

        # 默认回到聊天
        reply = self._generate_chat_response(latest_user_input, state)
        return {"messages": [AIMessage(content=reply)], "route": "finish"}

    def _route_from_agent(self, state: ImageCrawlerState) -> str:
        return state.get("route", "finish")

    def _get_latest_user_message(self, messages: List[BaseMessage]) -> str:
        for message in reversed(messages):
            if isinstance(message, HumanMessage):
                return message.content
        return ""

    def _generate_chat_response(self, user_input: Any, state: ImageCrawlerState) -> str:
        """处理普通聊天"""
        try:
            content = """
            你是一位贴心的智能助手，总是能敏锐地理解用户的真实需求，并用温暖专业的方式给予帮助。
            请用简洁明了的简体中文与我交流，让我们的对话既高效又愉快 🌟
            """

            # 构建聊天提示
            chat_prompt = ChatPromptTemplate.from_messages([
                SystemMessage(content=content),
                MessagesPlaceholder(variable_name="messages"),
                HumanMessage(content=user_input)
            ])
            
            chain = chat_prompt | self.model
            response = chain.invoke({"messages": state.get("messages", [])})
            return response.content if hasattr(response, "content") else str(response)
        except Exception as exc:
            return f"抱歉，我暂时无法回答该问题，错误信息：{exc}"

    def _stringify_input(self, value: Any) -> str:
        if isinstance(value, str):
            return value
        if isinstance(value, (list, tuple)):
            parts = [self._stringify_input(item) for item in value if item is not None]
            return "\n".join(part for part in parts if part)
        if hasattr(value, "content"):
            return self._stringify_input(getattr(value, "content"))
        if value is None:
            return ""
        return str(value)

    def _decide_next_action(self, user_input: Any, state: ImageCrawlerState) -> Dict[str, Any]:
        user_input_text = self._stringify_input(user_input)
        context_snapshot = json.dumps(
            {
                "keywords": state.get("keywords", []),
                "expanded_keywords": state.get("expanded_keywords", []),
                "downloaded_images": len(state.get("download_manifest", [])),
                "analysis_completed": len(state.get("analysis_results", [])) > 0,
                "has_classification": bool(state.get("classification_csv")),
            },
            ensure_ascii=False,
        )

        router_instructions = f"""
        # 图片处理智能体调度指南

        ## 角色定位
        你是图片处理工作流的智能调度员，负责分析用户意图并选择最合适的处理动作。

        ## 可用动作库
        **chat** - 用户闲聊、提问或无需工具执行时
        **extract_keywords** - 从用户描述中提炼或重新提炼关键词
        **expand_keywords** - 基于现有关键词扩展相似词汇
        **download_images** - 根据关键词执行图片搜索与下载
        **analyze_images** - 对下载图片进行审核、去重和清理
        **classify_keywords** - 按风险等级对关键词和图片分类并生成CSV

        ## 决策规则

        ### 🎯 动作选择标准
        | 用户意图特征 | 对应动作 | 典型输入示例 |
        |------------|----------|-------------|
        | 包含"提炼/提取/生成关键词" | extract_keywords | "帮我把这段描述提炼成关键词" |
        | 包含"扩展/补充/更多关键词" | expand_keywords | "基于这些词再扩展一些相似词" |
        | 包含"下载/搜索图片" | download_images | "用这些关键词下载图片" |
        | 包含"审核/检查/清理图片" | analyze_images | "分析一下刚下载的图片质量" |
        | 包含"分类/风险评估/生成报告" | classify_keywords | "对这些关键词做风险分类" |
        | 纯问答、解释、总结需求 | chat | "这个功能怎么用？" |

        ### 🔄 重新执行处理
        - **关键词重提炼**：当用户对当前关键词不满意要求"重新提炼"时 → `extract_keywords`
        - **关键词重扩展**：当用户要求"重新扩展"或"换一批相似词"时 → `expand_keywords`  
        - **图片重下载**：当用户对下载结果不满意要求"重新下载"时 → `download_images`
        - **设置** `use_previous_prompt=true`：当用户明确要求"沿用上次描述"时

        ### 📝 展示规范
        - 提炼/扩展的关键词使用**加粗**突出
        - 多个关键词建议使用Markdown表格展示
        - 每次动作执行后明确提示下一步操作建议

        ## 当前会话状态
        **上下文记录**: {context_snapshot}
        **最新用户输入**: "{user_input_text}"

        ## 输出格式
        ```json
        {{
            "action": "chat|extract_keywords|expand_keywords|download_images|analyze_images|classify_keywords",
            "use_previous_prompt": true|false,
            "reason": "基于用户意图和上下文的具体分析"
        }}"""

        try:
            response = self.model.invoke(
                [
                    SystemMessage(
                        content="你是Agent驱动图片爬取工作流调度器，只能输出JSON，且必须遵循动作列表。"
                    ),
                    HumanMessage(content=router_instructions),
                ]
            )
            parsed = self._safe_json_parse(response)
        except Exception as exc:
            print('模型处理失败：', exc)
            parsed = {}

        if not parsed or parsed.get("action") not in {
            "chat",
            "extract_keywords",
            "expand_keywords",
            "download_images",
            "analyze_images",
            "classify_keywords",
        }:
            lower_input = user_input_text.lower()
            if any(keyword in lower_input for keyword in ["提炼", "生成", '取出', '提取']):
                fallback = "extract_keywords"
            elif any(keyword in lower_input for keyword in ["扩展", "更多", '延伸']):
                fallback = "expand_keywords"
            elif any(keyword in lower_input for keyword in ["下载", "图片", '搜索']):
                fallback = "download_images"
            elif any(keyword in lower_input for keyword in ["分析", "过滤", '删除', '祛除']):
                fallback = "analyze_images"
            elif any(keyword in lower_input for keyword in ["分类", "汇总", 'csv']):
                fallback = "classify_keywords"
            else:
                fallback = "chat"
            parsed = {"action": fallback, "use_previous_prompt": False}

        return parsed

    def _safe_json_parse(self, response: Any) -> Dict[str, Any]:
        text = response.content if hasattr(response, "content") else str(response)
        text = text.strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            start = text.find("{")
            end = text.rfind("}")
            if start != -1 and end != -1 and end > start:
                try:
                    return json.loads(text[start : end + 1])
                except json.JSONDecodeError:
                    return {}
        return {}

    def _resolve_prompt(self, user_input: Any, state: ImageCrawlerState, use_previous: bool) -> str:
        if use_previous and state.get("last_prompt"):
            return state["last_prompt"]
        cleaned = self._stringify_input(user_input).strip()
        if cleaned:
            return cleaned
        return state.get("last_prompt", "")

    def _summarize_tool_response(self, state: ImageCrawlerState) -> str:
        tool_response = state.get("tool_response", {})
        summary = tool_response.get("summary", "工具执行完成")
        details = tool_response.get("details", "")
        next_hint = "如需继续，请输入新的指令，我会再次为你选择合适的工具。"
        if details:
            return f"{summary}\n{details}\n{next_hint}"
        return f"{summary}\n{next_hint}"

    # -----------------------------
    # 工具节点
    # -----------------------------
    def _extract_keywords_node(self, state: ImageCrawlerState) -> Dict[str, Any]:
        prompt_text = (
            state.get("pending_prompt")
            or state.get("last_prompt")
            or state.get("latest_user_input")
            or state.get("topic", "")
        )

        print(f"🔍 正在分析描述: {prompt_text}")
        print("⏳ 正在提炼关键词...")
        
        try:
            extracted = self.keyword_expander.extract_keywords_from_prompt(prompt_text)
            keywords = [item.get("keyword", "") for item in extracted if item.get("keyword")]
            topic = keywords[0] if keywords else prompt_text

            if keywords:
                print(f"✅ 成功提炼出 {len(keywords)} 个关键词")
                for i, keyword in enumerate(keywords, 1):
                    print(f"   {i}. {keyword}")
            else:
                print("⚠️  未能提炼出有效关键词")

            details = (
                f"关键词: {', '.join(keywords)}"
                if keywords
                else "未能提炼出有效关键词，请尝试提供更具体的描述。"
            )

            return {
                "topic": topic,
                "keywords": keywords,
                "pending_prompt": "",
                "tool_response": {
                    "tool": "extract_keywords",
                    "summary": "关键词提炼完成",
                    "details": details,
                    "data": extracted,
                },
                "tool_response_ready": True,
                "route": "finish",
            }
        except Exception as e:
            print(f"❌ 关键词提炼失败: {e}")
            return {
                "topic": prompt_text,
                "keywords": [],
                "pending_prompt": "",
                "tool_response": {
                    "tool": "extract_keywords",
                    "summary": "关键词提炼失败",
                    "details": f"错误: {str(e)}",
                    "data": [],
                },
                "tool_response_ready": True,
                "route": "finish",
            }

    def _expand_keywords_node(self, state: ImageCrawlerState) -> Dict[str, Any]:
        base_keywords = state.get("keywords") or state.get("expanded_keywords") or []
        if not base_keywords and state.get("topic"):
            base_keywords = [state["topic"]]

        print(f"🔄 正在扩展关键词: {', '.join(base_keywords)}")
        expanded: List[str] = []
        
        for i, keyword in enumerate(base_keywords, 1):
            print(f"   📊 处理关键词 {i}/{len(base_keywords)}: {keyword}")
            try:
                new_keywords = self.keyword_expander.get_expanded_keywords_for_topic(keyword)
                expanded.extend(new_keywords)
                print(f"      ✅ 扩展出 {len(new_keywords)} 个相关关键词")
            except Exception as exc:
                print(f"      ❌ 扩展关键词失败 {keyword}: {exc}")

        deduplicated = list(dict.fromkeys(expanded))
        
        if deduplicated:
            print(f"✅ 共扩展出 {len(deduplicated)} 个新关键词")
            for j, keyword in enumerate(deduplicated[:10], 1):  # 显示前10个
                print(f"   {j}. {keyword}")
            if len(deduplicated) > 10:
                print(f"   ... 还有 {len(deduplicated) - 10} 个关键词")
        else:
            print("⚠️  未能扩展出新的关键词")

        details = (
            f"扩展关键词: {', '.join(deduplicated)}"
            if deduplicated
            else "未能扩展出新的关键词，请尝试重新提炼。"
        )

        return {
            "expanded_keywords": deduplicated,
            "tool_response": {
                "tool": "expand_keywords",
                "summary": f"关键词扩展完成，共 {len(deduplicated)} 个",
                "details": details,
                "data": deduplicated,
            },
            "tool_response_ready": True,
            "route": "finish",
        }

    def _download_images_node(self, state: ImageCrawlerState) -> Dict[str, Any]:
        keywords = state.get("expanded_keywords") or state.get("keywords") or []
        downloaded_images = list(state.get("downloaded_images", []))
        manifest = list(state.get("download_manifest", []))

        if not keywords:
            return {
                "tool_response": {
                    "tool": "download_images",
                    "summary": "暂无可用关键词，无法执行下载",
                    "details": "请先完成关键词提炼或扩展",
                },
                "tool_response_ready": True,
                "route": "finish",
            }

        total_downloaded = 0
        total_failed = 0
        
        print(f"📥 开始下载图片，共 {len(keywords)} 个关键词")
        
        for keyword_idx, keyword in enumerate(keywords, 1):
            print(f"\n🔍 [{keyword_idx}/{len(keywords)}] 处理关键词: '{keyword}'")
            
            # 获取图片URL
            print("   🔍 搜索图片...")
            img_url_list = get_image_url.get_keyword_image(keyword)
            
            if not img_url_list:
                print("   ⚠️  未找到相关图片")
                continue

            print(f"   ✅ 找到 {len(img_url_list)} 张图片")
            
            # 创建保存目录（使用安全包装避免阻塞）
            save_dir = os.path.join(self.save_path, keyword)
            safe_makedirs(save_dir, exist_ok=True)
            
            # 准备下载任务
            tasks = [
                (os.path.join(save_dir, f"{index}.png"), url)
                for index, url in enumerate(img_url_list)
            ]

            print("   📥 开始下载...")
            success_list, failed_list = requests_download.save_image(tasks, max_workers=20)
            
            if failed_list:
                print(f"   🔄 重试失败的 {len(failed_list)} 张图片...")
                temp_success_list, temp_failed_list = playwright_download.save_image(
                    failed_list, max_workers=10
                )
                success_list.extend(temp_success_list)
                failed_list = temp_failed_list

            # 记录结果
            success_count = len(success_list)
            failed_count = len(failed_list)
            total_downloaded += success_count
            total_failed += failed_count

            print(f"   ✅ 成功: {success_count} 张, ❌ 失败: {failed_count} 张")
            
            # 添加到清单
            for file_path, url in success_list:
                downloaded_images.append(file_path)
                manifest.append({"keyword": keyword, "img_file": file_path, "img_url": url})
                print(f"      📁 保存: {os.path.basename(file_path)}")

        summary = f"共下载 {total_downloaded} 张图片"
        if total_failed > 0:
            summary += f"，失败 {total_failed} 张"
        
        details = f"成功下载 {total_downloaded} 张图片到: {self.save_path}"
        if total_failed > 0:
            details += f"\n失败 {total_failed} 张图片"

        return {
            "downloaded_images": downloaded_images,
            "download_manifest": manifest,
            "tool_response": {
                "tool": "download_images",
                "summary": summary,
                "details": details,
                "data": manifest,
            },
            "tool_response_ready": True,
            "route": "finish",
        }

    def _analyze_images_node(self, state: ImageCrawlerState) -> Dict[str, Any]:
        keywords = state.get("expanded_keywords") or state.get("keywords") or []
        analysis_results = list(state.get("analysis_results", []))

        if not keywords:
            return {
                "tool_response": {
                    "tool": "analyze_images",
                    "summary": "暂无关键词可用于分析。",
                    "details": "请先完成关键词提炼或扩展并下载图片。",
                },
                "tool_response_ready": True,
                "route": "finish",
            }

        for keyword in keywords:
            image_folder = os.path.join(self.save_path, keyword)
            if not os.path.exists(image_folder):
                continue

            print(f"正在分析关键词 '{keyword}' 的图片...")
            results = self.image_analyzer.batch_analyze_images(image_folder, keyword, max_workers=10)
            filter_results = self.image_analyzer.filter_and_cleanup_images(results)

            analysis_results.append(
                {
                    "keyword": keyword,
                    "total_images": len(results),
                    "kept_images": filter_results["keep_count"],
                    "removed_images": filter_results["remove_count"],
                    "filter_results": filter_results,
                }
            )

        summary = (
            f"已完成 {len(analysis_results)} 个关键词的图片审核。"
            if analysis_results
            else "未找到可分析的图片文件。"
        )

        return {
            "analysis_results": analysis_results,
            "tool_response": {
                "tool": "analyze_images",
                "summary": "图片分析完成。",
                "details": summary,
                "data": analysis_results,
            },
            "tool_response_ready": True,
            "route": "finish",
        }

    def _classify_keywords_node(self, state: ImageCrawlerState) -> Dict[str, Any]:
        manifest = state.get("download_manifest", [])
        if not manifest:
            return {
                "tool_response": {
                    "tool": "classify_keywords",
                    "summary": "尚未下载任何图片，无法分类。",
                    "details": "请先完成图片下载。",
                },
                "tool_response_ready": True,
                "route": "finish",
            }

        keyword_groups: Dict[str, List[Dict[str, str]]] = {}
        for item in manifest:
            keyword_groups.setdefault(item["keyword"], []).append(item)

        classification_prompt = {
            "risk_labels": RISK_LABELS,
            "keywords": [
                {
                    "keyword": keyword,
                    "sample_images": [
                        os.path.basename(entry["img_file"])
                        for entry in entries[:5]
                    ],
                }
                for keyword, entries in keyword_groups.items()
            ],
        }

        instructions = f"""
        请根据风险标签列表为提供的关键词进行分类分析。
        ## 任务说明：
            - 每个关键词只能选择**一个最匹配**的风险标签
            - 多个关键词可以分配到同一个标签
            - 请基于关键词的语义、潜在含义和使用场景进行综合判断
        风险标签: {', '.join(RISK_LABELS)}
        输入数据: {json.dumps(classification_prompt, ensure_ascii=False)}

        输出JSON:
        {{
        "classifications": [
            {{"keyword": "示例", "label": "风险标签", "reason": "判断依据"}}
        ]
        }}
        """
        try:
            response = self.model.invoke(
                [
                    SystemMessage(
                        content="你是风险分类助手，只能返回有效JSON，不允许添加额外文字。"
                    ),
                    HumanMessage(content=instructions),
                ]
            )
            parsed = self._safe_json_parse(response)
            classifications = parsed.get("classifications", [])
        except Exception as exc:
            print(f"分类失败: {exc}")
            classifications = []

        label_map = {item["keyword"]: item.get("label", "未知") for item in classifications}

        csv_file = os.path.join(self.save_path, f"{state.get('topic', 'task')}_classification.csv")
        
        # 使用安全包装避免阻塞
        headers = ["keyword", "label", "img_file", "img_url"]
        rows = []
        for entry in manifest:
            label = label_map.get(entry["keyword"], "未分类")
            rows.append([entry["keyword"], label, entry["img_file"], entry["img_url"]])
        
        safe_write_csv(csv_file, headers, rows)

        details = f"分类完成，CSV文件位于: {csv_file}"

        return {
            "classification_csv": csv_file,
            "tool_response": {
                "tool": "classify_keywords",
                "summary": "关键词分类和CSV导出完成。",
                "details": details,
                "data": label_map,
            },
            "tool_response_ready": True,
            "route": "finish",
        }

    # -----------------------------
    # 会话控制
    # -----------------------------
    def _initial_state(self, user_input: str, max_iterations: int) -> ImageCrawlerState:
        return {
            "topic": user_input,
            "last_prompt": user_input,
            "latest_user_input": user_input,
            "keywords": [],
            "expanded_keywords": [],
            "current_keyword": "",
            "downloaded_images": [],
            "download_manifest": [],
            "analysis_results": [],
            "classification_csv": "",
            "messages": [HumanMessage(content=user_input)],
            "iteration": 0,
            "max_iterations": max_iterations,
            "route": "finish",
            "tool_response": {},
            "tool_response_ready": False,
            "pending_prompt": user_input,
        }

    def run(self, user_input: str, max_iterations: int = 2, thread_id: Optional[str] = None) -> Dict[str, Any]:
        """单轮执行：根据用户输入触发工作流"""
        if not thread_id:
            thread_id = "default-thread"

        config = {"configurable": {"thread_id": thread_id}}

        if thread_id not in self._active_threads:
            payload = self._initial_state(user_input, max_iterations)
            self._active_threads.add(thread_id)
        else:
            payload = {
                "latest_user_input": user_input,
                "messages": [HumanMessage(content=user_input)],
                "pending_prompt": user_input,
            }

        result = self.app.invoke(payload, config=config)
        return result


# 定义响应函数
def graph_response(agent: ImageCrawlerAgent, user_input: str, config: dict) -> None:
    """
    处理用户输入并输出响应，实现真正的流式输出。

    Args:
        agent: ImageCrawlerAgent实例。
        user_input: 用户输入。
        config: 运行时配置。
    """
    try:
        # 获取线程ID
        thread_id = config.get("configurable", {}).get("thread_id", "default")
        
        # 准备初始状态
        if thread_id not in agent._active_threads:
            payload = agent._initial_state(user_input, max_iterations=2)
            agent._active_threads.add(thread_id)
        else:
            payload = {
                "latest_user_input": user_input,
                "messages": [HumanMessage(content=user_input)],
                "pending_prompt": user_input,
            }
        
        print(f"🔄 开始处理: {user_input}")
        print("-" * 50)
        
        # 使用stream进行流式输出
        try:
            # 直接执行工作流并获取最终结果
            result = agent.app.invoke(payload, config=config)
            
            # 处理最终结果并流式输出
            if result.get("tool_response_ready") and result.get("tool_response"):
                tool_response = result["tool_response"]
                summary = tool_response.get("summary", "")
                details = tool_response.get("details", "")
                
                print(f"✅ {summary}")
                if details:
                    # 流式输出详细信息
                    detail_lines = details.split('\n')
                    for line in detail_lines:
                        if line.strip():
                            print(f"  📋 {line.strip()}")
                            # 添加小延迟模拟流式效果
                            import time
                            time.sleep(0.1)
            
            # 输出AI回复
            if result.get("messages") and len(result["messages"]) > 0:
                last_message = result["messages"][-1]
                if hasattr(last_message, "content") and last_message.content:
                    content = last_message.content.strip()
                    if content and not content.startswith("如需继续"):
                        print(f"🤖 Assistant: {content}")
                        
        except Exception as workflow_error:
            print(f"❌ 工作流执行错误: {workflow_error}")
            # 回退到简单响应
            fallback_response = agent.run(user_input, thread_id=thread_id)
            if fallback_response.get("messages"):
                last_msg = fallback_response["messages"][-1]
                if hasattr(last_msg, "content") and last_msg.content:
                    print(f"🤖 Assistant: {last_msg.content}")
        
        print("-" * 50)
        
    except Exception as e:
        print(f"❌ Assistant: 处理响应时发生错误 - {e}")
        import traceback
        traceback.print_exc()


# 定义主函数
def main():
    """主函数，初始化并运行支持流式输出的聊天机器人"""
    try:
        # 创建ImageCrawlerAgent实例
        print("🚀 正在初始化图片爬取机器人...")
        image_crawler_agent = ImageCrawlerAgent()
        
        # 编译工作流并启用检查点
        checkpointer = image_crawler_agent.checkpointer
        image_crawler_agent.app = image_crawler_agent.workflow.compile(checkpointer=checkpointer)
        
        # 保存工作流图
        try:
            with open('workflow.png', "wb") as f:
                f.write(image_crawler_agent.app.get_graph().draw_mermaid_png())
            print("📊 工作流图已保存到 workflow.png")
        except Exception as e:
            print(f"⚠️  无法保存工作流图: {e}")

        # 打印机器人就绪提示
        print("\n" + "="*60)
        print("🤖 图片爬取机器人已就绪！")
        print("📋 支持的功能:")
        print("   • 关键词提炼: '帮我提炼关键词：未来科技城市夜景'")
        print("   • 关键词扩展: '扩展人工智能相关的关键词'")
        print("   • 图片下载: '下载这些关键词的图片'")
        print("   • 图片分析: '分析已下载的图片内容'")
        print("   • 风险分类: '对关键词进行分类并生成CSV报告'")
        print("   • 普通聊天: 直接输入任何问题")
        print("   • 退出程序: 'quit', 'exit', 'q' 或 Ctrl+C")
        print("="*60 + "\n")
        
        # 定义运行时配置
        config = {"configurable": {"thread_id": "1"}}
        
        # 会话计数器
        session_count = 0
        
        # 进入主循环
        while True:
            try:
                session_count += 1
                # 获取用户输入
                user_input = input(f"[{session_count}] User: ").strip()
                
                # 检查是否退出
                if user_input.lower() in {"quit", "exit", "q"}:
                    print("\n👋 感谢使用图片爬取机器人！再见!")
                    break
                    
                # 检查输入是否为空
                if not user_input:
                    print("⚠️  请输入有效的聊天内容！")
                    continue
                
                # 处理用户输入并使用流式输出
                try:
                    graph_response(image_crawler_agent, user_input, config)
                except KeyboardInterrupt:
                    print("\n⏸️  当前任务被中断，可以继续输入新的指令...")
                    continue
                    
            except KeyboardInterrupt:
                print("\n\n👋 用户强制退出，程序结束...")
                break
            except EOFError:
                print("\n\n👋 检测到文件结束，程序退出...")
                break
            except Exception as e:
                print(f"❌ 运行时错误: {e}")
                print("💡 请重试或联系技术支持")
                
    except Exception as e:
        print(f"❌ 初始化失败: {e}")
        traceback.print_exc()


# if __name__ == "__main__":
#     main()


image_crawler_agent = ImageCrawlerAgent()
graph = image_crawler_agent.app
