"""
智能图片爬取系统主程序
提供流式交互的命令行体验，并兼容关键词扩展与图片分析模式
"""

import argparse
import json
import os
import traceback
from datetime import datetime
from typing import Any, Dict, List, Optional

from langchain_core.messages import AIMessage, BaseMessage

from image_crawler_agent import ImageCrawlerAgent
from image_analyzer import ImageContentAnalyzer
from keyword_expansion import KeywordExpansion


STATE_CACHE_DIR = os.path.join(os.path.dirname(__file__), ".agent_state")
ANALYSIS_STATUS_FILE = os.path.join(STATE_CACHE_DIR, "analysis_status.json")


def _load_json_cache(file_path: str) -> Dict[str, Any]:
    if not os.path.exists(file_path):
        return {}
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        return {}


def _save_json_cache(file_path: str, data: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _stringify_stream_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for item in content:
            if isinstance(item, dict):
                parts.append(item.get("text", "") or item.get("data", ""))
            else:
                parts.append(str(item))
        return "".join(parts)
    if content is None:
        return ""
    return str(content)


def _extract_stream_text(chunk: Any) -> Optional[str]:
    if chunk is None:
        return None
    if isinstance(chunk, str):
        return chunk

    if isinstance(chunk, BaseMessage):
        if getattr(chunk, "type", "") not in {"ai", "tool"}:
            return None
        return _stringify_stream_content(chunk.content)

    if isinstance(chunk, dict):
        chunk_type = chunk.get("type")
        if chunk_type and chunk_type not in {"ai", "tool"}:
            return None
        if "content" in chunk:
            return _stringify_stream_content(chunk.get("content"))
        if "messages" in chunk:
            messages = chunk.get("messages") or []
            sections = [text for text in (_extract_stream_text(msg) for msg in messages) if text]
            return "".join(sections) if sections else None

    if isinstance(chunk, tuple):
        parts = [
            text
            for text in (_extract_stream_text(item) for item in chunk)
            if text
        ]
        return "".join(parts) if parts else None

    if isinstance(chunk, list):
        sections = [text for text in (_extract_stream_text(item) for item in chunk) if text]
        return "".join(sections) if sections else None

    return None


def graph_response(agent: ImageCrawlerAgent, user_input: str, config: Dict[str, Any], *, max_iterations: int=2) -> str:
    """使用LangGraph流式输出结果"""
    thread_id = config.get("configurable", {}).get("thread_id")
    stream = agent.stream(
        user_input,
        max_iterations=max_iterations,
        thread_id=thread_id,
        stream_mode="messages",
    )

    buffer: List[str] = []
    print("🤖 Agent: ", end="", flush=True)
    try:
        for chunk in stream:
            text = _extract_stream_text(chunk)
            if not text:
                continue
            print(text, end="", flush=True)
            buffer.append(text)
    finally:
        print()
    return "".join(buffer)


def run_stream_cli():
    """运行流式命令行对话"""
    try:
        print("🚀 正在初始化图片爬取机器人...")
        image_crawler_agent = ImageCrawlerAgent()

        workflow = image_crawler_agent.workflow

        print("\n" + "=" * 60)
        print("🤖 图片爬取机器人已就绪！")
        print("📋 支持的功能:")
        print("   • 关键词提炼: '帮我提炼关键词：未来科技城市夜景'")
        print("   • 关键词扩展: '扩展人工智能相关的关键词'")
        print("   • 图片下载: '下载这些关键词的图片'")
        print("   • 图片分析: '分析已下载的图片内容'")
        print("   • 风险分类: '对关键词进行分类并生成CSV报告'")
        print("   • 普通聊天: 直接输入任何问题")
        print("   • 退出程序: 'quit', 'exit', 'q' 或 Ctrl+C")
        print("=" * 60 + "\n")

        config = {"configurable": {"thread_id": "stream-cli"}}
        
        session_count = 0

        while True:
            try:
                session_count += 1
                user_input = input(f"[{session_count}] User: ").strip()

                if user_input.lower() in {"quit", "exit", "q"}:
                    print("\n👋 感谢使用图片爬取机器人！再见!")
                    break

                if not user_input:
                    print("⚠️  请输入有效的聊天内容！")
                    continue

                try:
                    graph_response(image_crawler_agent, user_input, config)
                except KeyboardInterrupt:
                    print("\n⏸️  当前任务被中断，可以继续输入新的指令...")
                    continue

            except KeyboardInterrupt:
                print("\n\n👋 用户强制退出，程序结束...")
                break
            except EOFError:
                print("\n\n👋 检测到文件结束，程序退出...")
                break
            except Exception as exc:
                print(f"❌ 运行时错误: {exc}")
                print("💡 请重试或联系技术支持")

    except Exception as exc:
        print(f"❌ 初始化失败: {exc}")
        traceback.print_exc()


def run_keyword_expansion(topic: str):
    expander = KeywordExpansion()
    keywords = expander.get_expanded_keywords_for_topic(topic)

    print(f"\n话题: {topic}")
    for idx, keyword in enumerate(keywords, 1):
        print(f"  {idx}. {keyword}")

    save_file = f"{topic}_keywords.json"
    with open(save_file, "w", encoding="utf-8") as f:
        json.dump(
            {
                "topic": topic,
                "keywords": keywords,
                "timestamp": datetime.now().isoformat(),
            },
            f,
            ensure_ascii=False,
            indent=2,
        )

    print(f"\n关键词已保存到: {save_file}")


def run_image_analysis(path: str):
    analyzer = ImageContentAnalyzer()
    keyword = os.path.basename(path.rstrip(os.sep)) or path
    abs_path = os.path.abspath(path)

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"找不到图片目录: {path}")

    status_map = _load_json_cache(ANALYSIS_STATUS_FILE)
    status_entry = status_map.get(abs_path)

    if status_entry and status_entry.get("status") == "success":
        print(f"检测到 '{keyword}' 已完成相似度分析，跳过重复执行。")
        return

    if status_entry and status_entry.get("status") == "failed":
        print(f"检测到 '{keyword}' 上次分析失败，正在重新尝试...")

    print(f"正在分析 '{keyword}' 文件夹中的图片...")
    try:
        results = analyzer.batch_analyze_images(abs_path, keyword)
        if not results:
            print("未找到可分析的图片")
            status_map[abs_path] = {
                "status": "failed",
                "updated_at": datetime.now().isoformat(),
                "keyword": keyword,
                "error": "未找到可分析的图片",
            }
            _save_json_cache(ANALYSIS_STATUS_FILE, status_map)
            return

        filter_results = analyzer.filter_and_cleanup_images(results)
        report_file = os.path.join(os.getcwd(), f"{keyword}_analysis_report.md")
        summary = f"""
        # 图片分析报告 - {keyword}
        - 总图片: {len(results)}
        - 保留图片: {filter_results['keep_count']}
        - 删除图片: {filter_results['remove_count']}

        ## 详情
        """
        with open(report_file, "w", encoding="utf-8") as f:
            f.write(summary)

        status_map[abs_path] = {
            "status": "success",
            "updated_at": datetime.now().isoformat(),
            "keyword": keyword,
            "report": report_file,
        }
        _save_json_cache(ANALYSIS_STATUS_FILE, status_map)

        print(f"\n✅ 分析完成！")
        print(f"📊 总图片: {len(results)}")
        print(f"✅ 保留图片: {filter_results['keep_count']}")
        print(f"❌ 删除图片: {filter_results['remove_count']}")
        print(f"📄 详细报告: {report_file}")
    except Exception as exc:
        status_map[abs_path] = {
            "status": "failed",
            "updated_at": datetime.now().isoformat(),
            "keyword": keyword,
            "error": str(exc),
        }
        _save_json_cache(ANALYSIS_STATUS_FILE, status_map)
        raise


def run_single_topic(topic: str, iterations: int):
    agent = ImageCrawlerAgent()
    result = agent.run(topic, iterations, thread_id=f"cli-{datetime.now().strftime('%H%M%S')}")
    messages = result.get("messages", [])
    reply = ""
    for msg in reversed(messages):
        if isinstance(msg, AIMessage):
            reply = msg.content
            break
    print(f"Agent回复: {reply}")


def main():
    """主函数 - 智能图片爬取系统入口"""
    parser = argparse.ArgumentParser(
        description="🤖 智能图片爬取系统 - 基于LangGraph的AI驱动图片爬取工作流",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
        使用示例:
        # 启动交互式命令行界面（默认模式）
        python main.py
        
        # 直接执行单个话题任务
        python main.py --topic "未来科技城市"
        
        # 测试关键词扩展功能
        python main.py --keyword-test "人工智能"
        
        # 分析已下载的图片文件夹
        python main.py --analyze ./images_result/20231212/关键词
        
        更多信息请访问项目文档。
        """)
            
    parser.add_argument(
        "--topic", "-t", 
        type=str, 
        help="指定搜索话题，直接执行完整的图片爬取流程"
    )
    parser.add_argument(
        "--iterations", "-i", 
        type=int, 
        default=2, 
        help="设置最大迭代轮数（默认: 2）"
    )
    parser.add_argument(
        "--mode", "-m", 
        choices=["cli", "api"], 
        default="cli", 
        help="运行模式: cli=命令行交互, api=API服务（默认: cli）"
    )
    parser.add_argument(
        "--keyword-test", "-k", 
        type=str, 
        help="测试关键词扩展功能，输入话题生成相关关键词"
    )
    parser.add_argument(
        "--analyze", "-a", 
        type=str, 
        help="分析指定文件夹中的图片，进行去重和质量检查"
    )

    args = parser.parse_args()

    try:
        # 关键词扩展测试模式
        if args.keyword_test:
            print(f"🔍 正在为话题 '{args.keyword_test}' 扩展关键词...")
            run_keyword_expansion(args.keyword_test)
            return

        # 图片分析模式
        if args.analyze:
            print(f"📊 正在分析图片文件夹: {args.analyze}")
            run_image_analysis(args.analyze)
            return

        # 单话题执行模式
        if args.topic:
            print(f"🚀 正在处理话题: {args.topic}")
            run_single_topic(args.topic, args.iterations)
            return

        # 交互式CLI模式
        if args.mode == "cli":
            run_stream_cli()
        else:
            print("⚠️  API模式暂未实现，请使用 --mode cli 进入交互模式。")
            print("💡 提示: 直接运行 'python main.py' 即可启动交互式界面")
            
    except KeyboardInterrupt:
        print("\n\n👋 程序被用户中断，正在退出...")
    except Exception as exc:
        print(f"\n❌ 程序执行出错: {exc}")
        print(f"📋 错误详情:")
        traceback.print_exc()
        print("\n💡 提示: 请检查配置文件和环境变量是否正确设置")


if __name__ == "__main__":
    main()

