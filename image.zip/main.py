"""
智能图片爬取系统主程序
提供用户友好的命令行界面和API接口
"""

import os
import sys
import argparse
import json
from typing import List, Dict
import asyncio
from datetime import datetime

from langchain_core.messages import AIMessage

from image_crawler_agent import ImageCrawlerAgent
from keyword_expansion import KeywordExpansion
from image_analyzer import ImageContentAnalyzer

class ImageCrawlerCLI:
    """命令行界面类"""
    
    def __init__(self):
        self.agent = ImageCrawlerAgent()
        self.keyword_expander = KeywordExpansion()
        self.analyzer = ImageContentAnalyzer()
    
    def display_banner(self):
        """显示程序横幅"""
        banner = """
        ╔═══════════════════════════════════════════════════════════════╗
        ║                                                               ║
        ║              智能图片爬取系统 v1.0                               ║
        ║              AI-Powered Image Crawler                         ║
        ║                                                               ║
        ║  基于LangGraph的agent驱动图片爬取与内容审核系统                    ║
        ║  支持关键词智能扩展、动态调整、内容过滤                             ║
        ║                                                               ║
        ╚═══════════════════════════════════════════════════════════════╝
        """
        print(banner)
    
    def display_menu(self):
        """显示主菜单"""
        menu = """
        请选择操作：
        1. 开始图片爬取任务
        2. 关键词扩展测试
        3. 图片内容分析
        4. 查看历史任务
        5. 系统设置
        6. 退出程序

        请输入选项编号 (1-6): """
        return input(menu).strip()
    
    def _extract_last_agent_reply(self, messages: List) -> str:
        for message in reversed(messages or []):
            if isinstance(message, AIMessage):
                return message.content
        return "未收到Agent回复，请稍后重试。"

    def start_crawl_task(self):
        """开始图片爬取任务（对话模式）"""
        print("\n" + "="*50)
        print("开始新的图片爬取任务")
        print("="*50)
        print("提示：可直接输入聊天或指令，例如“请提炼关键词”“重新扩展关键词”“下载图片”等。")
        print("输入 exit 或 quit 可结束对话。\n")

        thread_id = f"cli-task-{datetime.now().strftime('%Y%m%d%H%M%S')}"

        while True:
            user_input = input("你: ").strip()
            if not user_input:
                continue
            if user_input.lower() in {"exit", "quit"}:
                print("对话结束，感谢使用。")
                break

            try:
                result = self.agent.run(user_input, thread_id=thread_id)
                reply = self._extract_last_agent_reply(result.get("messages", []))
                print(f"\nAgent: {reply}\n")
            except Exception as exc:
                print(f"❌ 执行失败: {exc}")
                break
    
    def test_keyword_expansion(self):
        """关键词扩展测试"""
        print("\n" + "="*50)
        print("关键词扩展测试")
        print("="*50)
        
        topic = input("请输入测试话题: ").strip()
        if not topic:
            print("错误：话题不能为空！")
            return
        
        print("\n正在扩展关键词...")
        keywords = self.keyword_expander.get_expanded_keywords_for_topic(topic)
        
        print(f"\n话题: {topic}")
        print("扩展关键词:")
        for i, keyword in enumerate(keywords, 1):
            print(f"  {i}. {keyword}")
        
        # 保存到文件
        save_file = f"{topic}_keywords.json"
        with open(save_file, 'w', encoding='utf-8') as f:
            json.dump({
                "topic": topic,
                "keywords": keywords,
                "timestamp": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
        
        print(f"\n关键词已保存到: {save_file}")
    
    def analyze_existing_images(self):
        """分析现有图片"""
        print("\n" + "="*50)
        print("图片内容分析")
        print("="*50)
        
        keyword = input("请输入要分析的关键词: ").strip()
        if not keyword:
            print("错误：关键词不能为空！")
            return
        
        image_folder = os.path.join(os.getcwd(), keyword)
        if not os.path.exists(image_folder):
            print(f"错误：找不到文件夹 '{image_folder}'")
            return
        
        print(f"正在分析 '{keyword}' 文件夹中的图片...")
        
        try:
            # 批量分析
            results = self.analyzer.batch_analyze_images(image_folder, keyword)
            
            if not results:
                print("未找到可分析的图片")
                return
            
            # 过滤和清理
            filter_results = self.analyzer.filter_and_cleanup_images(results)

            report_file = os.path.join(os.getcwd(), f"{keyword}_analysis_report.md")
            self._write_analysis_report(report_file, keyword, results, filter_results)
            
            print(f"\n✅ 分析完成！")
            print(f"📊 总图片: {len(results)}")
            print(f"✅ 保留图片: {filter_results['keep_count']}")
            print(f"❌ 删除图片: {filter_results['remove_count']}")
            print(f"📄 详细报告: {report_file}")
            
        except Exception as e:
            print(f"❌ 分析失败: {str(e)}")
    
    def view_history(self):
        """查看历史任务"""
        print("\n" + "="*50)
        print("历史任务")
        print("="*50)
        
        # 查找历史报告文件
        history_files = []
        for file in os.listdir('.'):
            if file.endswith('_final_report.md'):
                topic = file.replace('_final_report.md', '')
                history_files.append({
                    'topic': topic,
                    'file': file,
                    'mtime': os.path.getmtime(file)
                })
        
        if not history_files:
            print("暂无历史任务")
            return
        
        # 按时间排序
        history_files.sort(key=lambda x: x['mtime'], reverse=True)
        
        print("历史任务列表:")
        for i, task in enumerate(history_files, 1):
            mtime = datetime.fromtimestamp(task['mtime']).strftime('%Y-%m-%d %H:%M:%S')
            print(f"  {i}. {task['topic']} ({mtime})")
        
        # 选择查看详细报告
        choice = input("\n输入编号查看详细报告 (或按回车返回): ").strip()
        if choice and choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(history_files):
                file_path = history_files[idx]['file']
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    print("\n" + "="*50)
                    print(content)
                except Exception as e:
                    print(f"读取报告失败: {e}")
    
    def _write_analysis_report(self, report_file: str, keyword: str, results: List[Dict], filter_results: Dict):
        summary = f"""
        # 图片分析报告 - {keyword}
        - 总图片: {len(results)}
        - 保留图片: {filter_results['keep_count']}
        - 删除图片: {filter_results['remove_count']}
        ## 详情
        """
        with open(report_file, "w", encoding="utf-8") as f:
            f.write(summary)

    def system_settings(self):
        """系统设置"""
        print("\n" + "="*50)
        print("系统设置")
        print("="*50)
        
        print("当前设置:")
        print("1. 代理设置: 127.0.0.1:13659")
        print("2. 最大并发线程: 20")
        print("3. 图片质量阈值: 0.7")
        print("4. 最大迭代轮数: 5")
        
        input("\n按回车键返回主菜单...")
    
    def run(self):
        """运行CLI程序"""
        self.display_banner()
        
        while True:
            try:
                choice = self.display_menu()
                
                if choice == '1':
                    self.start_crawl_task()
                elif choice == '2':
                    self.test_keyword_expansion()
                elif choice == '3':
                    self.analyze_existing_images()
                elif choice == '4':
                    self.view_history()
                elif choice == '5':
                    self.system_settings()
                elif choice == '6':
                    print("感谢使用，再见！")
                    break
                else:
                    print("无效选项，请输入1-6之间的数字")
                
                input("\n按回车键继续...")
                
            except KeyboardInterrupt:
                print("\n\n程序被中断，再见！")
                break
            except Exception as e:
                print(f"发生错误: {e}")
                input("\n按回车键继续...")


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='智能图片爬取系统')
    parser.add_argument('--topic', '-t', type=str, help='搜索话题')
    parser.add_argument('--iterations', '-i', type=int, default=2, help='最大迭代轮数')
    parser.add_argument('--mode', '-m', choices=['cli', 'api'], default='cli', help='运行模式')
    parser.add_argument('--keyword-test', '-k', type=str, help='关键词扩展测试')
    parser.add_argument('--analyze', '-a', type=str, help='分析现有图片文件夹')
    
    args = parser.parse_args()
    
    if args.keyword_test:
        # 关键词扩展测试模式
        expander = KeywordExpansion()
        keywords = expander.get_expanded_keywords_for_topic(args.keyword_test)
        print(f"话题: {args.keyword_test}")
        print("扩展关键词:", ", ".join(keywords))
        
    elif args.analyze:
        # 图片分析模式
        analyzer = ImageContentAnalyzer()
        results = analyzer.batch_analyze_images(args.analyze, os.path.basename(args.analyze))
        filter_results = analyzer.filter_and_cleanup_images(results)
        print(f"分析完成，保留 {filter_results['keep_count']} 张图片")
        
    elif args.topic:
        # 直接运行单轮任务
        agent = ImageCrawlerAgent()
        result = agent.run(args.topic, args.iterations, thread_id=f"cli-{datetime.now().strftime('%H%M%S')}")
        messages = result.get("messages", [])
        reply = ""
        for msg in reversed(messages):
            if isinstance(msg, AIMessage):
                reply = msg.content
                break
        print(f"Agent回复: {reply}")
        
    else:
        # 交互式CLI模式
        cli = ImageCrawlerCLI()
        cli.run()


if __name__ == "__main__":
    main()