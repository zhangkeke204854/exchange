"""
异步工具函数，用于处理文件系统操作
避免在LangGraph的ASGI环境中使用同步阻塞调用
"""
import asyncio
import os
import csv
import json
from typing import Any, Dict, List, Tuple


async def async_makedirs(path: str, exist_ok: bool = True) -> None:
    """异步创建目录"""
    await asyncio.to_thread(os.makedirs, path, exist_ok=exist_ok)


async def async_write_csv(file_path: str, headers: List[str], rows: List[List[str]]) -> None:
    """异步写入CSV文件"""
    def _write():
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "w", encoding="utf-8-sig", newline="") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(headers)
            writer.writerows(rows)
    
    await asyncio.to_thread(_write)


async def async_write_file(file_path: str, content: str, encoding: str = "utf-8") -> None:
    """异步写入文本文件"""
    def _write():
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "w", encoding=encoding) as f:
            f.write(content)
    
    await asyncio.to_thread(_write)


async def async_write_binary(file_path: str, content: bytes) -> None:
    """异步写入二进制文件"""
    def _write():
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "wb") as f:
            f.write(content)
    
    await asyncio.to_thread(_write)


async def async_read_file(file_path: str, encoding: str = "utf-8") -> str:
    """异步读取文本文件"""
    def _read():
        with open(file_path, "r", encoding=encoding) as f:
            return f.read()
    
    return await asyncio.to_thread(_read)


async def async_read_binary(file_path: str) -> bytes:
    """异步读取二进制文件"""
    def _read():
        with open(file_path, "rb") as f:
            return f.read()
    
    return await asyncio.to_thread(_read)


async def async_path_exists(path: str) -> bool:
    """异步检查路径是否存在"""
    return await asyncio.to_thread(os.path.exists, path)


async def async_listdir(path: str) -> List[str]:
    """异步列出目录内容"""
    return await asyncio.to_thread(os.listdir, path)