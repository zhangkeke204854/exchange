"""
阻塞调用修复工具
用于解决LangGraph在ASGI环境中的同步阻塞问题
"""
import asyncio
import os
import csv
import threading
from typing import Any, Callable, List


class AsyncRunner:
    """在单独线程中运行阻塞操作的实用工具"""
    
    @staticmethod
    def run_blocking(func: Callable, *args, **kwargs) -> Any:
        """在事件循环中运行阻塞函数"""
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # 如果事件循环已经在运行，使用线程池
                return asyncio.get_event_loop().run_in_executor(
                    None, lambda: func(*args, **kwargs)
                )
            else:
                # 否则直接运行
                return func(*args, **kwargs)
        except RuntimeError:
            # 没有事件循环，创建新的
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            return loop.run_until_complete(
                asyncio.to_thread(func, *args, **kwargs)
            )


# 全局实例
async_runner = AsyncRunner()


def safe_makedirs(path: str, exist_ok: bool = True) -> None:
    """安全地创建目录"""
    try:
        AsyncRunner.run_blocking(os.makedirs, path, exist_ok=exist_ok)
    except Exception as e:
        # 如果异步运行失败，回退到同步
        os.makedirs(path, exist_ok=exist_ok)


def safe_write_csv(file_path: str, headers: List[str], rows: List[List[str]]) -> None:
    """安全地写入CSV文件"""
    def _write():
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "w", encoding="utf-8-sig", newline="") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(headers)
            writer.writerows(rows)
    
    try:
        AsyncRunner.run_blocking(_write)
    except Exception as e:
        # 如果异步运行失败，回退到同步
        _write()