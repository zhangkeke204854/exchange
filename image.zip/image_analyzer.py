"""
图片内容审核和过滤系统
负责自动审核下载的图片是否与关键词匹配，并过滤不相关内容
使用阿里百炼视觉模型进行图片分析
"""

import os
import re
import json
import base64
from typing import List, Dict, Tuple
from PIL import Image
import requests
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor, as_completed
from dotenv import load_dotenv


load_dotenv(override=True)


class ImageContentAnalyzer:
    def __init__(self):
        self.API_KEY = 'sk-d216cf47c8e94a77be3e728a487c7bb3'
        self.max_file_size_bytes = 3 * 1024 * 1024  # 图片大小
        self.max_image_dimension = 2048  # 最大图片尺寸
    
    def _call_chat_api_non_stream(self, prompt: str, base64_image: str) -> str:
        """
        调用 Matrix LLM Chat API（非流式）
        """
        url = "https://matrixllm.alipay.com/v1/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.API_KEY}"
        }
        
        text = [
            {
                "type": "text", "text": f"{prompt}"
            },
            {
                "type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}
            }
        ]

        data = {
            "stream": False,  # 非流式模式
            "model": "gpt-5-chat-2025-08-07",
            "messages": [
                {"role": "user", "content": text}
            ]
        }

        try:
            response = requests.post(url, headers=headers, json=data, timeout=50)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            print(f"请求失败: {e}")
            return None

        try:
            result = response.json()
        except json.JSONDecodeError:
            print("API 返回的不是合法 JSON")
            return None

        # 优先提取 AI 回复内容
        if "choices" in result and len(result["choices"]) > 0:
            content = result["choices"][0].get("message", {}).get("content", "")
            return content
        else:
            print("API 返回中没有包含有效的回复")
            print(json.dumps(result, indent=2, ensure_ascii=False))
            return None
    
    def _compress_image(self, image_path: str) -> Tuple[bytes, str]:
        """压缩图片，确保不超过大小限制"""
        try:
            image_ext = os.path.splitext(image_path)[1].lower()

            # 检查文件大小
            file_size = os.path.getsize(image_path)

            # 如果文件已经很小，直接读取
            if file_size <= self.max_file_size_bytes:
                with open(image_path, 'rb') as f:
                    image_bytes = f.read()
                    return image_bytes, image_ext
            
            # 需要压缩
            with Image.open(image_path) as img:
                # 转换为RGB模式（如果不是）
                if img.mode in ('RGBA', 'LA', 'P'):
                    # 创建白色背景
                    background = Image.new('RGB', img.size, (255, 255, 255))
                    if img.mode == 'P':
                        img = img.convert('RGBA')
                    background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
                    img = background
                elif img.mode != 'RGB':
                    img = img.convert('RGB')
                
                # 计算压缩比例
                width, height = img.size
                if width > self.max_image_dimension or height > self.max_image_dimension:
                    # 等比例缩放
                    ratio = min(self.max_image_dimension / width, self.max_image_dimension / height)
                    new_width = int(width * ratio)
                    new_height = int(height * ratio)
                    img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
                
                # 保存到内存，逐步降低质量直到满足大小要求
                output = BytesIO()
                quality = 85
                while quality > 20:
                    output.seek(0)
                    output.truncate(0)
                    img.save(output, format='JPEG', quality=quality, optimize=True)
                    if len(output.getvalue()) <= self.max_file_size_bytes:
                        break
                    quality -= 10
                return output.getvalue(), '.jpg'
        except Exception as e:
            print(f"图片压缩失败 {image_path}: {e}")
            # 如果压缩失败，尝试直接读取（可能会失败）
            with open(image_path, 'rb') as f:
                image_bytes = f.read()
                return image_bytes, image_ext

    def _compress_image_to_size(self, image_path: str) -> Tuple[bytes, str]:
        """将图片压缩到指定大小以内，同时保持清晰度，返回PNG格式"""
        try:
            with Image.open(image_path) as img:
                # 获取原始图片信息
                original_width, original_height = img.size
                original_mode = img.mode
                
                # 保持原始模式，PNG支持透明度
                if img.mode == 'P':
                    # 处理调色板模式
                    img = img.convert('RGBA')
                elif img.mode not in ['RGB', 'RGBA', 'L', 'LA']:
                    img = img.convert('RGBA')
                
                # PNG压缩策略
                output = BytesIO()
                
                # 策略1: 尝试不同PNG压缩级别
                for compression_level in range(5, 10):  # 1-9，9为最高压缩
                    output.seek(0)
                    output.truncate(0)
                    
                    save_kwargs = {
                        'format': 'PNG',
                        'optimize': True,
                        'compress_level': compression_level
                    }
                    
                    if img.mode == 'RGBA':
                        save_kwargs['format'] = 'PNG'
                    
                    img.save(output, **save_kwargs)
                    compressed_size = len(output.getvalue())
                    
                    if compressed_size <= self.max_file_size_bytes:
                        return output.getvalue(), '.png'
                
                # 策略2: 轻微缩放 + PNG压缩
                temp_img = img.copy()
                scale_factor = 0.95
                new_width = max(int(original_width * scale_factor), 1000)
                new_height = max(int(original_height * scale_factor), 1000)
                temp_img = temp_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
                
                for compression_level in range(5, 10):
                    output.seek(0)
                    output.truncate(0)
                    
                    save_kwargs = {
                        'format': 'PNG',
                        'optimize': True,
                        'compress_level': compression_level
                    }
                    
                    temp_img.save(output, **save_kwargs)
                    if len(output.getvalue()) <= self.max_file_size_bytes:
                        return output.getvalue(), '.png'
                
                # 策略3: 中等缩放 + PNG压缩
                scale_factor = 0.85
                new_width = max(int(original_width * scale_factor), 800)
                new_height = max(int(original_height * scale_factor), 800)
                temp_img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
                
                for compression_level in range(5, 10):
                    output.seek(0)
                    output.truncate(0)
                    
                    save_kwargs = {
                        'format': 'PNG',
                        'optimize': True,
                        'compress_level': compression_level
                    }
                    
                    temp_img.save(output, **save_kwargs)
                    if len(output.getvalue()) <= self.max_file_size_bytes:
                        return output.getvalue(), '.png'
                
                # 策略4: 智能缩放 + 优化PNG
                current_size = os.path.getsize(image_path)
                if current_size > self.max_file_size_bytes:
                    # 根据文件大小比例估算缩放比例
                    scale_factor = (self.max_file_size_bytes / current_size) ** 0.5
                    if scale_factor < 0.4:  # 防止过度压缩
                        scale_factor = 0.4
                    
                    new_width = max(int(original_width * scale_factor), 500)
                    new_height = max(int(original_height * scale_factor), 500)
                    temp_img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
                else:
                    temp_img = img.copy()
                
                # 使用最高压缩级别
                output.seek(0)
                output.truncate(0)
                
                save_kwargs = {
                    'format': 'PNG',
                    'optimize': True,
                    'compress_level': 9
                }
                
                temp_img.save(output, **save_kwargs)
                
                # 如果仍然过大，转换为RGB模式（去除透明度）
                if len(output.getvalue()) > self.max_file_size_bytes and temp_img.mode in ['RGBA', 'LA']:
                    rgb_img = Image.new('RGB', temp_img.size, (255, 255, 255))
                    if temp_img.mode == 'LA':
                        temp_img = temp_img.convert('RGBA')
                    rgb_img.paste(temp_img, mask=temp_img.split()[-1] if temp_img.mode == 'RGBA' else None)
                    
                    output.seek(0)
                    output.truncate(0)
                    rgb_img.save(output, format='PNG', optimize=True, compress_level=9)
                
                return output.getvalue(), '.png'
                
        except Exception as e:
            print(f"图片压缩失败 {image_path}: {e}")
            # 如果压缩失败，尝试直接读取（可能会失败）
            with open(image_path, 'rb') as f:
                return f.read(), os.path.splitext(image_path)[1].lower()

    def analyze_image_relevance(self, image_path: str, keyword: str) -> Dict[str, any]:
        """使用视觉模型分析单张图片与关键词的相关性"""
        try:
            # 检查文件是否存在
            if not os.path.exists(image_path):
                return {
                    "is_relevant": False,
                    "relevance_score": 0.0,
                    "confidence": 0.0,
                    "reason": "图片文件不存在",
                    "main_elements": [],
                    "category": "unknown",
                    "suggested_action": "remove"
                }
            
            # 压缩图片并读取
            image_bytes, image_ext = self._compress_image(image_path)
            
            # 转换为base64
            image_data = base64.b64encode(image_bytes).decode('utf-8')
            
            # 检查base64编码后的大小（应该小于5MB）
            if len(image_data) > 5 * 1024 * 1024:
                print(f"图片base64编码后过大，跳过分析 {image_path}")
                return {
                    "is_relevant": False,
                    "relevance_score": 0.0,
                    "confidence": 0.0,
                    "reason": "图片编码后过大，跳过分析",
                    "main_elements": [],
                    "category": "unknown",
                    "suggested_action": "remove"
                }
            
            # 构建提示词
            prompt = f"""
            # 角色
            你是一位资深的视觉内容审核专家，擅长图像语义分析、符号学解读以及内容相关性匹配。

            # 任务
            请分析上传的图片，并评估其与关键词 "{keyword}" 的语义相关性。

            # 输入数据
            - 关键词: "{keyword}"
            - 图片: [上传的图片]

            # 分析步骤 (请在内心进行思考，不要输出)
            1. **视觉识别**: 识别图片的主体、背景、文字（OCR）及情感基调。
            2. **语义映射**: 分析图片内容是否直接表现、间接象征或完全无关该关键词。
            3. **评分判定**: 根据下方的[评分标准]进行打分。
            4. **格式化**: 将结果严格封装为JSON格式。

            # 评分标准 (评分标准)
            - **0.0 - 0.3 (Irrelevant)**: 图片与关键词毫无关联，或存在误导性。
            - **0.4 - 0.5 (Weak)**: 仅有微弱关联（如背景中微小出现），或关联非常牵强。
            - **0.6 - 0.7 (Relevant)**: 关键词是图片内容的一部分，或者图片清晰地象征了该概念。
            - **0.8 - 1.0 (Highly Relevant)**: 关键词是图片的核心主体、焦点，或图片是为了展示该关键词而拍摄/制作的。

            # 输出格式
            请仅返回一个纯净的JSON对象，**不要包含** Markdown 代码块标记（如 ```json），也不要包含任何开场白或结束语。

            JSON 结构如下：
            {{
                "is_relevant": true/false, // 布尔值。分数 >= 0.6 为true，否则为false
                "relevance_score": 0.85, // 浮点数，范围 0.0 - 1.0
                "confidence": 0.95, // 模型对自身判断的信心程度，0.0 - 1.0
                "reason": "简练精准的理由，先描述画面主体，再解释其与关键词的逻辑联系。",
                "main_elements": ["元素1", "元素2", "场景/背景", "文字内容(如有)"],
                "category": "具体类别（如：人像摄影、产品特写、自然风光、数据图表、矢量插画、含有文字的截图等）",
                "suggested_action": "keep/remove" // 建议操作：keep (>=0.6) 或 remove (<0.6)
            }}
            """
            
            # 调用模型
            result_text = self._call_chat_api_non_stream(prompt, image_data)
            if not result_text:
                print(f"API调用失败或返回格式不合法 {image_path}")
                return {
                    "is_relevant": True,
                    "relevance_score": 0.6,
                    "confidence": 0.3,
                    "reason": "API调用失败",
                    "main_elements": [],
                    "category": "unknown",
                    "suggested_action": "keep"
                }
            
            # 解析返回结果
            try:
                # 尝试提取JSON
                try:
                    # 如果返回的是纯JSON
                    result = json.loads(result_text)
                except json.JSONDecodeError:
                    # 如果返回的文本中包含JSON，尝试提取
                    json_match = re.search(r'\{.*\}', result_text, re.DOTALL)
                    if json_match:
                        result = json.loads(json_match.group())
                    else:
                        # 如果无法解析，使用默认值
                        result = {
                            "is_relevant": True,
                            "relevance_score": 0.6,
                            "confidence": 0.5,
                            "reason": f"无法解析模型返回结果，原始内容: {result_text[:100]}",
                            "main_elements": [],
                            "category": "unknown",
                            "suggested_action": "keep"
                        }
                
                return result                  
            except Exception as e:
                print(f"解析API响应失败 {image_path}: {e}")
                # 如果都失败了，返回默认值
                return {
                    "is_relevant": True,
                    "relevance_score": 0.6,
                    "confidence": 0.3,
                    "reason": f"解析API响应失败: {str(e)}",
                    "main_elements": [],
                    "category": "unknown",
                    "suggested_action": "keep"
                }
        except Exception as e:
            print(f"图片分析失败 {os.path.basename(image_path)}: {str(e)}")
            
            # 如果是内容审核相关错误
            if "inappropriate" in str(e).lower() or "内容审核" in str(e):
                return {
                    "is_relevant": False,
                    "relevance_score": 0.0,
                    "confidence": 0.0,
                    "reason": "内容审核失败",
                    "main_elements": [],
                    "category": "inappropriate",
                    "suggested_action": "remove"
                }
            else:
                # 其他错误默认保留图片
                return {
                    "is_relevant": True,
                    "relevance_score": 0.6,
                    "confidence": 0.3,
                    "reason": f"分析失败: {str(e)}",
                    "main_elements": [],
                    "category": "unknown",
                    "suggested_action": "keep"
                }
    
    def _analyze_single_image(self, image_data: Tuple[str, str]) -> Dict[str, any]:
        """分析单张图片的辅助函数，用于多线程"""
        image_path, keyword = image_data
        try:
            analysis = self.analyze_image_relevance(image_path, keyword)
            analysis["image_path"] = image_path
            return analysis
        except Exception as e:
            print(f"分析图片失败 {image_path}: {e}")
            return {
                "image_path": image_path,
                "is_relevant": True,
                "relevance_score": 0.6,
                "confidence": 0.3,
                "reason": f"分析异常: {str(e)}",
                "main_elements": [],
                "category": "unknown",
                "suggested_action": "keep"
            }
    
    def _compress_single_image(self, image_path: str) -> Tuple[str, bool]:
        """压缩单张图片的辅助函数，用于多线程"""
        try:
            file_size = os.path.getsize(image_path)
            if file_size > self.max_file_size_bytes:
                # 压缩图片
                compressed_bytes, _ = self._compress_image_to_size(image_path)
                
                # 保存压缩后的图片（覆盖原文件）
                with open(image_path, 'wb') as f:
                    f.write(compressed_bytes)
                
                new_size = len(compressed_bytes)
                print(f"压缩完成: {image_path} {file_size / 1024 / 1024:.2f}MB -> {new_size / 1024 / 1024:.2f}MB")
                return image_path, True
            else:
                return image_path, False
        except Exception as e:
            print(f"压缩失败: {image_path} {e}")
            return image_path, False
    
    def batch_analyze_images(self, image_folder: str, keyword: str, max_workers: int = 40) -> List[Dict[str, any]]:
        """多线程批量分析文件夹中的图片，包含多线程压缩功能"""
        results = []
        
        if not os.path.exists(image_folder):
            print(f"图片目录不存在: {image_folder}")
            return results

        if not os.path.isdir(image_folder):
            print(f"不是图片目录: {image_folder}")
            return results
        
        image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'}
        
        # 第一步：收集所有图片文件
        all_image_paths = []
        for filename in os.listdir(image_folder):
            if any(filename.lower().endswith(ext) for ext in image_extensions):
                image_path = os.path.join(image_folder, filename)
                if os.path.isfile(image_path):
                    all_image_paths.append(image_path)
        
        if not all_image_paths:
            print(f"文件夹中没有找到图片文件: {image_folder}")
            return results
        
        print(f"发现 {len(all_image_paths)} 张图片，开始多线程压缩处理，线程数: {max_workers}")
        
        # 第二步：使用多线程压缩大图片
        compressed_count = 0
        with ThreadPoolExecutor(max_workers=max_workers) as compress_executor:
            # 提交所有图片进行压缩检查
            compress_futures = {
                compress_executor.submit(self._compress_single_image, image_path): image_path
                for image_path in all_image_paths
            }
            
            # 收集压缩结果
            valid_image_paths = []
            for future in as_completed(compress_futures):
                image_path, was_compressed = future.result()
                if was_compressed:
                    compressed_count += 1
                valid_image_paths.append(image_path)
        
        if compressed_count > 0:
            print(f"多线程压缩完成，共压缩 {compressed_count} 个图片文件")
        
        # 第三步：准备分析数据
        image_files = [(image_path, keyword) for image_path in valid_image_paths]
        if not image_files:
            print("没有有效的图片文件需要分析")
            return results
        
        # 第四步：使用多线程批量分析
        print(f"开始多线程分析 {len(image_files)} 张图片，线程数: {max_workers}")
        with ThreadPoolExecutor(max_workers=max_workers) as analyze_executor:
            future_to_image = {
                analyze_executor.submit(self._analyze_single_image, image_data): image_data
                for image_data in image_files
            }
            
            for future in as_completed(future_to_image):
                try:
                    analysis = future.result()
                    results.append(analysis)
                except Exception as e:
                    image_path, _ = future_to_image[future]
                    print(f"任务执行异常 {image_path}: {e}")
                    # 添加默认结果
                    results.append({
                        "image_path": image_path,
                        "is_relevant": True,
                        "relevance_score": 0.6,
                        "confidence": 0.3,
                        "reason": f"任务执行异常: {str(e)}",
                        "main_elements": [],
                        "category": "unknown",
                        "suggested_action": "keep"
                    })
        
        print(f"图片分析完成，共分析 {len(results)} 张图片")
        return results
    
    def filter_and_cleanup_images(self, analysis_results: List[Dict[str, any]], min_relevance_score: float = 0.6) -> Dict[str, List[str]]:
        """根据分析结果过滤并清理不相关图片"""
        keep_images, success_remove_images, failed_remove_images = [], [], []
        for result in analysis_results:
            if result.get("relevance_score", 0) >= min_relevance_score and result.get("is_relevant", False):
                keep_images.append(result["image_path"])
            else:
                try:
                    os.remove(result["image_path"])
                    success_remove_images.append(result["image_path"])
                    print(f"已删除不相关图片: {result['image_path']}, {result['reason']}")
                except Exception as e:
                    failed_remove_images.append(result['image_path'])
                    print(f"删除图片失败: {result['image_path']}, 错误: {e}")
        
        return {
            "kept": keep_images,
            "keep_count": len(keep_images),
            "success_removed": success_remove_images,
            "success_removed_count": len(success_remove_images),
            "failed_removed": failed_remove_images,
            "failed_removed_count": len(failed_remove_images)
        }
    

if __name__ == "__main__":
    import json
    import pandas as pd

    # 测试图片分析功能
    analyzer = ImageContentAnalyzer()
    
    result_folder = os.path.join(os.path.dirname(__file__), 'result')
    topic_path_list = os.listdir(result_folder)
    for topic in topic_path_list:
        topic_folder = os.path.join(result_folder, topic)
        if os.path.isdir(topic_folder):
            keyword_path_list = os.listdir(topic_folder)
            for keyword in keyword_path_list:
                keyword_folder = os.path.join(topic_folder, keyword)
                if os.path.isdir(keyword_folder):
                    image_name_list = os.listdir(keyword_folder)
                    success_name = f'{keyword}_success_removed.csv'
                    failed_name = f'{keyword}_failed_removed.csv'
                    if success_name in image_name_list and failed_name in image_name_list:
                        continue

                    print(f"开始分析关键词 '{keyword}' 的图片...")
                    
                    # 批量分析图片
                    results = analyzer.batch_analyze_images(keyword_folder, keyword)
                    if results:
                        # 过滤和清理
                        filter_results = analyzer.filter_and_cleanup_images(results)

                        print(f"'{keyword}' 的图片分析完成！保留图片: {filter_results['keep_count']}, 删除图片: {filter_results['success_removed_count']}")

                        success_file = os.path.join(keyword_folder, f'{keyword}_success_removed.csv')
                        df = pd.DataFrame(filter_results['success_removed'], columns=['file'])
                        df.to_csv(success_file, index=False)
                        
                        failed_file = os.path.join(keyword_folder, f'{keyword}_failed_removed.csv')
                        df = pd.DataFrame(filter_results['failed_removed'], columns=['file'])
                        df.to_csv(failed_file, index=False)
