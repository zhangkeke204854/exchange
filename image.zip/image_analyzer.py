"""
图片内容审核和过滤系统
负责自动审核下载的图片是否与关键词匹配，并过滤不相关内容
使用阿里百炼视觉模型进行图片分析
"""

import os
import re
import json
import base64
from typing import List, Dict, Tuple
from PIL import Image
import requests
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor, as_completed
from dotenv import load_dotenv
import dashscope
from dashscope import MultiModalConversation

load_dotenv(override=True)

class ImageContentAnalyzer:
    def __init__(self):
        # 初始化阿里百炼视觉模型
        dashscope.api_key = os.getenv("DASHSCOPE_API_KEY", "")
        if not dashscope.api_key:
            print("警告: 未设置DASHSCOPE_API_KEY环境变量，图片分析功能可能无法使用")
        
        # 图片大小限制（7MB，但base64编码后会增大，所以限制在7MB左右）
        self.max_file_size_bytes = 7 * 1024 * 1024  # 70MB
        self.max_image_dimension = 2048  # 最大图片尺寸
    
    def _compress_image(self, image_path: str) -> Tuple[bytes, str]:
        """压缩图片，确保不超过大小限制"""
        try:
            # 检查文件大小
            file_size = os.path.getsize(image_path)
            
            # 如果文件已经很小，直接读取
            if file_size <= self.max_file_size_bytes:
                with open(image_path, 'rb') as f:
                    image_bytes = f.read()
                image_ext = os.path.splitext(image_path)[1].lower()
                return image_bytes, image_ext
            
            # 需要压缩
            with Image.open(image_path) as img:
                # 转换为RGB模式（如果不是）
                if img.mode in ('RGBA', 'LA', 'P'):
                    # 创建白色背景
                    background = Image.new('RGB', img.size, (255, 255, 255))
                    if img.mode == 'P':
                        img = img.convert('RGBA')
                    background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
                    img = background
                elif img.mode != 'RGB':
                    img = img.convert('RGB')
                
                # 计算压缩比例
                width, height = img.size
                if width > self.max_image_dimension or height > self.max_image_dimension:
                    # 等比例缩放
                    ratio = min(self.max_image_dimension / width, self.max_image_dimension / height)
                    new_width = int(width * ratio)
                    new_height = int(height * ratio)
                    img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
                
                # 保存到内存，逐步降低质量直到满足大小要求
                output = BytesIO()
                quality = 85
                while quality > 20:
                    output.seek(0)
                    output.truncate(0)
                    img.save(output, format='JPEG', quality=quality, optimize=True)
                    if len(output.getvalue()) <= self.max_file_size_bytes:
                        break
                    quality -= 10
                
                return output.getvalue(), '.jpg'
                
        except Exception as e:
            print(f"图片压缩失败 {image_path}: {e}")
            # 如果压缩失败，尝试直接读取（可能会失败）
            with open(image_path, 'rb') as f:
                return f.read(), os.path.splitext(image_path)[1].lower()
    
    def analyze_image_relevance(self, image_path: str, keyword: str) -> Dict[str, any]:
        """使用阿里百炼视觉模型分析单张图片与关键词的相关性"""
        try:
            # 检查文件是否存在
            if not os.path.exists(image_path):
                return {
                    "is_relevant": False,
                    "relevance_score": 0.0,
                    "confidence": 0.0,
                    "reason": "图片文件不存在",
                    "main_elements": [],
                    "category": "unknown",
                    "suggested_action": "remove"
                }
            
            
            # 压缩图片并读取
            image_bytes, image_ext = self._compress_image(image_path)
            
            # 转换为base64
            image_data = base64.b64encode(image_bytes).decode('utf-8')
            
            # 检查base64编码后的大小（应该小于10MB）
            if len(image_data) > 10 * 1024 * 1024:
                print(f"图片base64编码后过大，跳过分析: {image_path}")
                return {
                    "is_relevant": False,
                    "relevance_score": 0.0,
                    "confidence": 0.0,
                    "reason": "图片编码后过大，跳过分析",
                    "main_elements": [],
                    "category": "unknown",
                    "suggested_action": "remove"
                }
            
            # 检测图片格式
            mime_type_map = {
                '.png': 'image/png',
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.gif': 'image/gif',
                '.bmp': 'image/bmp',
                '.webp': 'image/webp'
            }
            mime_type = mime_type_map.get(image_ext, 'image/jpeg')
            
            # 构建提示词
            prompt = f"""请分析这张图片的内容，判断它与关键词"{keyword}"的相关性。

                        请严格按照以下JSON格式返回结果：
                        {{
                            "is_relevant": true/false,
                            "relevance_score": 0.85,
                            "confidence": 0.90,
                            "reason": "详细说明为什么这张图片与关键词相关或不相关",
                            "main_elements": ["图片中的主要元素列表"],
                            "category": "图片类别（如人物/风景/事件/文档等）",
                            "suggested_action": "keep/remove"
                        }}

                        判断标准：
                        1. 图片必须直接展示或象征关键词相关内容
                        2. 相关性分数>0.6才视为相关
                        3. 对于抽象概念，可以接受象征性表达
                        4. 明显不相关的图片应该被移除

                        请只返回JSON格式的结果，不要包含其他文字。"""
            
            # 调用阿里百炼视觉模型API
            messages = [
                {
                    "role": "user",
                    "content": [
                        {
                            "image": f"data:{mime_type};base64,{image_data}"
                        },
                        {
                            "text": prompt
                        }
                    ]
                }
            ]
            
            response = MultiModalConversation.call(
                model='qwen-vl-max',  # 使用阿里百炼视觉模型
                messages=messages
            )
            
            if response.status_code == 200:
                # 解析返回结果 - 安全地访问响应内容
                try:
                    # 获取响应内容
                    content_item = response.output.choices[0].message.content[0]
                    
                    # 处理content可能是字典或对象的情况
                    if isinstance(content_item, dict):
                        result_text = content_item.get('text', '')
                    else:
                        result_text = getattr(content_item, 'text', '')
                    
                    # 如果没有text字段，尝试其他可能的字段
                    if not result_text:
                        if isinstance(content_item, dict):
                            result_text = content_item.get('content', '') or str(content_item)
                        else:
                            result_text = str(content_item)
                    
                    # 尝试提取JSON
                    try:
                        # 如果返回的是纯JSON
                        result = json.loads(result_text)
                    except json.JSONDecodeError:
                        # 如果返回的文本中包含JSON，尝试提取
                        json_match = re.search(r'\{.*\}', result_text, re.DOTALL)
                        if json_match:
                            result = json.loads(json_match.group())
                        else:
                            # 如果无法解析，使用默认值
                            result = {
                                "is_relevant": True,
                                "relevance_score": 0.6,
                                "confidence": 0.5,
                                "reason": f"无法解析模型返回结果，原始内容: {result_text[:100]}",
                                "main_elements": [],
                                "category": "unknown",
                                "suggested_action": "keep"
                            }
                    
                    return result                  
                except (AttributeError, IndexError, KeyError) as e:
                    print(f"解析API响应失败 {image_path}: {e}")
                    # 尝试直接访问响应对象
                    try:
                        result_text = str(response.output)
                        json_match = re.search(r'\{.*\}', result_text, re.DOTALL)
                        if json_match:
                            result = json.loads(json_match.group())
                            return result
                    except Exception as e:
                        print(f"直接访问响应对象失败 {image_path}: {e}")
                        # 如果都失败了，返回默认值
                        return {
                            "is_relevant": True,
                            "relevance_score": 0.6,
                            "confidence": 0.3,
                            "reason": f"解析API响应失败: {str(e)}",
                            "main_elements": [],
                            "category": "unknown",
                            "suggested_action": "keep"
                        }
            else:
                # API调用失败
                error_msg = "未知错误"
                if hasattr(response, 'message'):
                    error_msg = response.message
                elif hasattr(response, 'output') and hasattr(response.output, 'message'):
                    error_msg = response.output.message
                
                print(f"API调用失败: {error_msg}")
                
                # 如果是内容审核失败，标记为不相关
                if "inappropriate content" in str(error_msg).lower() or "内容审核" in str(error_msg):
                    return {
                        "is_relevant": False,
                        "relevance_score": 0.0,
                        "confidence": 0.0,
                        "reason": f"内容审核失败: {error_msg}",
                        "main_elements": [],
                        "category": "inappropriate",
                        "suggested_action": "remove"
                    }
                
                # 其他错误默认保留图片
                return {
                    "is_relevant": True,
                    "relevance_score": 0.6,
                    "confidence": 0.3,
                    "reason": f"API调用失败: {error_msg}",
                    "main_elements": [],
                    "category": "unknown",
                    "suggested_action": "keep"
                }
        except Exception as e:
            error_str = str(e)
            print(f"图片分析失败 {os.path.basename(image_path)}: {error_str}")
            
            # 如果是内容审核相关错误
            if "inappropriate" in error_str.lower() or "内容审核" in error_str:
                return {
                    "is_relevant": False,
                    "relevance_score": 0.0,
                    "confidence": 0.0,
                    "reason": "内容审核失败",
                    "main_elements": [],
                    "category": "inappropriate",
                    "suggested_action": "remove"
                }
            else:
                # 其他错误默认保留图片
                return {
                    "is_relevant": True,
                    "relevance_score": 0.6,
                    "confidence": 0.3,
                    "reason": f"分析失败: {error_str}",
                    "main_elements": [],
                    "category": "unknown",
                    "suggested_action": "keep"
                }
    
    def _analyze_single_image(self, image_data: Tuple[str, str]) -> Dict[str, any]:
        """分析单张图片的辅助函数，用于多线程"""
        image_path, keyword = image_data
        try:
            analysis = self.analyze_image_relevance(image_path, keyword)
            analysis["image_path"] = image_path
            return analysis
        except Exception as e:
            print(f"分析图片失败 {image_path}: {e}")
            return {
                "image_path": image_path,
                "is_relevant": True,
                "relevance_score": 0.6,
                "confidence": 0.3,
                "reason": f"分析异常: {str(e)}",
                "main_elements": [],
                "category": "unknown",
                "suggested_action": "keep"
            }
    
    def batch_analyze_images(self, image_folder: str, keyword: str, max_workers: int = 20) -> List[Dict[str, any]]:
        """多线程批量分析文件夹中的图片"""
        results = []
        
        if not os.path.exists(image_folder):
            print(f"图片文件夹不存在: {image_folder}")
            return results
        
        image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'}
        
        # 收集所有图片文件，并过滤掉过大的文件
        image_files = []
        skipped_count = 0
        for filename in os.listdir(image_folder):
            if any(filename.lower().endswith(ext) for ext in image_extensions):
                image_path = os.path.join(image_folder, filename)
                
                # 检查文件大小，超过20MB的跳过
                try:
                    file_size = os.path.getsize(image_path)
                    if file_size > 20 * 1024 * 1024:  # 20MB
                        skipped_count += 1
                        print(f"跳过过大文件: {filename} ({file_size / 1024 / 1024:.2f}MB)")
                        continue
                except Exception as e:
                    print(f"检查文件大小失败 {filename}: {e}")
                    continue
                
                image_files.append((image_path, keyword))
        
        if skipped_count > 0:
            print(f"已跳过 {skipped_count} 个过大的图片文件")
        
        if not image_files:
            print(f"文件夹中没有找到图片文件: {image_folder}")
            return results
        
        # 使用多线程批量分析
        print(f"开始多线程分析 {len(image_files)} 张图片，线程数: {max_workers}")
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_image = {
                executor.submit(self._analyze_single_image, image_data): image_data
                for image_data in image_files
            }
            
            for future in as_completed(future_to_image):
                try:
                    analysis = future.result()
                    results.append(analysis)
                except Exception as e:
                    image_path, _ = future_to_image[future]
                    print(f"任务执行异常 {image_path}: {e}")
                    # 添加默认结果
                    results.append({
                        "image_path": image_path,
                        "is_relevant": True,
                        "relevance_score": 0.6,
                        "confidence": 0.3,
                        "reason": f"任务执行异常: {str(e)}",
                        "main_elements": [],
                        "category": "unknown",
                        "suggested_action": "keep"
                    })
        
        print(f"图片分析完成，共分析 {len(results)} 张图片")
        return results
    
    def filter_and_cleanup_images(self, analysis_results: List[Dict[str, any]], min_relevance_score: float = 0.6) -> Dict[str, List[str]]:
        """根据分析结果过滤并清理不相关图片"""
        keep_images = []
        remove_images = []
        
        for result in analysis_results:
            if result.get("relevance_score", 0) >= min_relevance_score and result.get("is_relevant", False):
                keep_images.append(result["image_path"])
            else:
                remove_images.append(result["image_path"])
        
        # 删除不相关的图片
        for image_path in remove_images:
            try:
                if os.path.exists(image_path):
                    os.remove(image_path)
                    print(f"已删除不相关图片: {os.path.basename(image_path)}")
            except Exception as e:
                print(f"删除图片失败: {image_path}, 错误: {e}")
        
        return {
            "kept": keep_images,
            "removed": remove_images,
            "keep_count": len(keep_images),
            "remove_count": len(remove_images)
        }
    


class ImageQualityChecker:
    """图片质量检查器"""
    
    def __init__(self):
        self.min_width = 100
        self.min_height = 100
        self.max_file_size_mb = 10
    
    def check_image_quality(self, image_path: str) -> Dict[str, any]:
        """检查图片质量"""
        try:
            with Image.open(image_path) as img:
                width, height = img.size
                file_size = os.path.getsize(image_path) / (1024 * 1024)  # MB
                
                issues = []
                
                if width < self.min_width or height < self.min_height:
                    issues.append("图片尺寸过小")
                
                if file_size > self.max_file_size_mb:
                    issues.append("文件过大")
                
                if img.mode not in ['RGB', 'RGBA', 'L']:
                    issues.append("不支持的图片模式")
                
                return {
                    "valid": len(issues) == 0,
                    "width": width,
                    "height": height,
                    "file_size_mb": file_size,
                    "format": img.format,
                    "mode": img.mode,
                    "issues": issues
                }
        except Exception as e:
            return {
                "valid": False,
                "error": str(e)
            }


if __name__ == "__main__":
    # 测试图片分析功能
    analyzer = ImageContentAnalyzer()
    
    # 模拟测试
    test_keyword = "9·11事件"
    test_folder = os.path.join(os.path.dirname(__file__), 'images_result', '20251116112950', test_keyword)
    
    if os.path.exists(test_folder):
        print(f"开始分析关键词 '{test_keyword}' 的图片...")
        
        # 批量分析图片
        results = analyzer.batch_analyze_images(test_folder, test_keyword)
        
        # 过滤和清理
        filter_results = analyzer.filter_and_cleanup_images(results)
        
        print(f"分析完成！保留图片: {filter_results['keep_count']}, 删除图片: {filter_results['remove_count']}")
    else:
        print(f"测试文件夹不存在: {test_folder}")