"""
历史图片爬取系统配置文件
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# 加载环境变量
load_dotenv(override=True)

# API配置
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
GOOGLE_CSE_ID = os.getenv("GOOGLE_CSE_ID")

# 存储配置
BASE_STORAGE_PATH = Path("./historical_images")
MAX_IMAGES_PER_KEYWORD = int(os.getenv("MAX_IMAGES_PER_KEYWORD", "10"))
MAX_CONCURRENT_DOWNLOADS = int(os.getenv("MAX_CONCURRENT_DOWNLOADS", "5"))

# 图片质量配置
MIN_IMAGE_WIDTH = int(os.getenv("MIN_IMAGE_WIDTH", "200"))
MIN_IMAGE_HEIGHT = int(os.getenv("MIN_IMAGE_HEIGHT", "200"))
MIN_FILE_SIZE = int(os.getenv("MIN_FILE_SIZE", "10240"))  # 10KB

# 搜索配置
SEARCH_ENGINES = [
    "google",
    "bing", 
    "baidu"
]

# 关键词配置
MAX_KEYWORDS = int(os.getenv("MAX_KEYWORDS", "15"))
MIN_KEYWORDS = int(os.getenv("MIN_KEYWORDS", "5"))

# 审核配置
ENABLE_IMAGE_REVIEW = os.getenv("ENABLE_IMAGE_REVIEW", "true").lower() == "true"
REVIEW_THRESHOLD = float(os.getenv("REVIEW_THRESHOLD", "0.7"))

# 日志配置
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FILE = Path("./logs/historical_crawler.log")

# 创建必要的目录
BASE_STORAGE_PATH.mkdir(exist_ok=True)
LOG_FILE.parent.mkdir(exist_ok=True)

# 检查必要的环境变量
def check_config():
    """检查配置是否完整"""
    required_vars = {
        "DEEPSEEK_API_KEY": DEEPSEEK_API_KEY,
    }
    
    missing = [k for k, v in required_vars.items() if not v]
    
    if missing:
        print("⚠️  缺少必要的环境变量:")
        for var in missing:
            print(f"   - {var}")
        return False
    
    return True

if __name__ == "__main__":
    check_config()