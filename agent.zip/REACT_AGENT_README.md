# React智能助手系统使用说明

## 系统概述

React智能助手是一个基于LangGraph的完整AI助手系统，集成了天气查询、新闻搜索、关键词处理、图片下载、内容审核和分类等所有功能。

## 功能特性

### 1. 产品定位功能
- **天气查询**：直接查询指定城市的天气信息
- **新闻搜索**：搜索最新的新闻和事件
- **关键词提炼**：从用户描述中提取核心关键词
- **关键词扩展**：基于关键词生成更多相关词汇
- **图片搜索与下载**：根据关键词搜索并下载图片
- **图片审核**：自动分析图片与关键词的相关性，删除不匹配的图片
- **关键词分类**：将关键词分类到9个风险类别中
- **CSV报告生成**：生成包含关键词、分类、图片路径和URL的CSV文件

### 2. 技术特性
- **短期存储**：使用Checkpointer实现对话记忆功能
- **最新依赖**：所有第三方包更新到最新版本
- **模块化设计**：基于现有模型接口，无需重新开发
- **多线程处理**：支持并发图片下载和分析

## 使用方法

### 1. 命令行使用

#### 启动React智能助手
```bash
# 启动交互模式
python main.py

# 选择菜单中的"1. React智能助手模式"
```

#### 直接测试
```bash
# 测试所有功能
python main.py --react-test

# 交互模式
python main.py --react-interactive

# 命令行模式
python -c "from react_agent import assistant; print(assistant.run('北京天气怎么样？')['response'])"
```

#### 参数说明
```bash
python main.py [选项]

选项：
  --react-test          测试React智能助手所有功能
  --react-interactive   启动React智能助手交互模式
  --topic TOPIC         传统图片爬取模式
  --keyword-test TEST   关键词扩展测试
  --analyze FOLDER      图片分析模式
```

### 2. 编程接口使用

#### 基本使用
```python
from react_agent import assistant

# 单次调用
result = assistant.run("北京天气怎么样？")
print(result['response'])

# 带线程ID的调用（支持记忆功能）
result = assistant.run("搜索关于猫的图片", thread_id="user_123")
```

#### 功能示例

**天气查询**
```python
result = assistant.run("上海天气如何？")
# 输出：上海当前天气：多云，温度：22°C，湿度：65%
```

**新闻搜索**
```python
result = assistant.run("今天有什么科技新闻？")
# 输出：为您找到以下相关新闻：...
```

**关键词处理**
```python
# 关键词提炼
result = assistant.run("从'人工智能在医疗领域的应用'中提取关键词")
# 输出：从您的输入中提炼出以下关键词：人工智能, 医疗, 应用

# 关键词扩展
result = assistant.run("扩展关键词'机器学习'")
# 输出：已扩展关键词：深度学习, 神经网络, 数据挖掘...
```

**图片搜索与处理**
```python
# 搜索图片
result = assistant.run("搜索关于'猫'的图片")
# 输出：已完成图片搜索和下载，共下载 15 张图片

# 关键词分类
result = assistant.run("对关键词'网络安全'进行分类")
# 输出：已完成关键词分类，网络安全 -> 隐私与个人安全
```

## 风险分类系统

系统将关键词自动分类到以下9个风险类别：

1. **暴力与行为伤害**
2. **性相关风险**
3. **犯罪与违法活动**
4. **仇恨、不公与心理伤害**
5. **隐私与个人安全**
6. **虚假信息与不当影响**
7. **框架、体制和国家安全**
8. **版权与知识产权**
9. **灾害、紧急与敏感事件**

## CSV报告格式

生成的CSV文件包含以下字段：
- `keyword`: 关键词
- `label`: 风险分类标签
- `img_file`: 图片本地路径
- `img_url`: 图片原始URL

## 环境配置

### 必需的环境变量
```bash
# 在.env文件中配置
OPENWEATHER_API_KEY=your_openweather_api_key
DASHSCOPE_API_KEY=your_dashscope_api_key
```

### 依赖安装
```bash
pip install -r requirements.txt
```

## 文件结构

```
image_agent/
├── react_agent.py          # React智能助手主文件
├── test_react_agent.py     # 测试脚本
├── main.py                 # 更新后的主程序
├── requirements.txt        # 更新后的依赖列表
├── graph.py               # 原始graph.py（保持不变）
├── image_crawler_agent.py  # 图片爬取Agent
├── keyword_expansion.py    # 关键词扩展模块
├── image_analyzer.py       # 图片分析模块
├── get_image_url.py        # 图片URL获取
├── requests_download.py    # 图片下载
├── playwright_download.py  # 浏览器下载
└── assistant_results/      # 结果保存目录
    └── classification_*.csv # 生成的CSV报告
```

## 使用示例

### 完整工作流示例
```python
# 1. 用户输入描述
user_input = "我想了解人工智能在医疗诊断中的应用"

# 2. 系统处理流程
result = assistant.run(user_input)

# 3. 系统会自动：
#    - 提炼关键词：人工智能, 医疗诊断, 应用
#    - 扩展关键词：深度学习, 医学影像, 疾病检测...
#    - 搜索相关图片
#    - 分析图片相关性
#    - 分类关键词
#    - 生成CSV报告
```

### 交互式使用
```bash
$ python main.py

╔═══════════════════════════════════════════════════════════════╗
║              智能助手系统 v1.0                               ║
╚═══════════════════════════════════════════════════════════════╝

请选择操作：
1. React智能助手模式
2. 开始图片爬取任务
...

选择 1 进入React智能助手模式

请输入您的问题: 搜索关于人工智能的图片
🔄 正在处理...
🤖 助手回复:
已完成图片搜索和下载，共下载 12 张图片
关键词: 人工智能, 机器学习, 深度学习
CSV报告: assistant_results/classification_20241117_143022.csv
```

## 注意事项

1. **API限制**：确保已配置有效的API密钥
2. **网络要求**：需要稳定的网络连接进行图片下载
3. **存储空间**：大量图片下载可能占用较多存储空间
4. **内容审核**：系统会自动过滤不适当的内容
5. **并发限制**：避免同时处理过多请求

## 故障排除

### 常见问题
1. **API错误**：检查.env文件中的API密钥配置
2. **网络超时**：检查网络连接，可调整超时参数
3. **存储错误**：确保有足够的磁盘空间
4. **权限错误**：确保有文件写入权限

### 调试模式
```python
# 启用详细日志
import logging
logging.basicConfig(level=logging.DEBUG)

# 测试单个功能
from react_agent import SmartAssistant
assistant = SmartAssistant()
result = assistant.run("测试输入")
print(result)