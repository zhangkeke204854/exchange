# 交互式智能助手系统

## 概述

本项目是一个基于LangGraph的交互式智能助手系统，以Agent节点为中心，支持用户与AI进行多轮对话式交互，完成从关键词提取到图片下载、分析、分类的完整工作流。

## 核心功能

### 1. 以Agent节点为中心的设计
- **Agent节点**: 作为智能决策中心，根据用户输入和当前状态决定下一步操作
- **交互式处理**: 支持用户在每个阶段提供反馈，决定是否继续、重新生成或结束
- **状态管理**: 使用LangGraph的Checkpointer实现短期记忆存储

### 2. 完整的工作流

```
用户输入 → Agent判断 → 关键词提取 → 用户反馈 → 关键词扩展 → 用户反馈 → 
图片搜索 → 用户反馈 → 图片分析 → 用户反馈 → 关键词分类 → 用户反馈 → CSV报告
```

### 3. 支持的功能类型

#### a. 天气查询
- 用户询问天气信息时，直接调用天气API
- 示例："北京天气怎么样？"

#### b. 新闻搜索
- 用户搜索新闻时，使用Tavily搜索工具
- 示例："今天有什么科技新闻？"

#### c. 关键词处理
- **关键词提取**: 从用户描述中提炼关键词
- **关键词扩展**: 基于关键词生成更多相关关键词
- **关键词分类**: 将关键词分类到9个风险类别

#### d. 图片处理
- **图片搜索**: 根据关键词搜索并下载图片
- **图片分析**: 使用阿里百炼视觉模型分析图片内容
- **图片过滤**: 自动删除与关键词不匹配的图片

#### e. 报告生成
- **CSV报告**: 生成包含keyword, label, img_file, img_url字段的CSV文件

## 风险分类标签

系统支持以下9个风险类别：
1. 暴力与行为伤害
2. 性相关风险
3. 犯罪与违法活动
4. 仇恨、不公与心理伤害
5. 隐私与个人安全
6. 虚假信息与不当影响
7. 框架、体制和国家安全
8. 版权与知识产权
9. 灾害、紧急与敏感事件

## 交互式使用示例

### 场景1：关键词提取和扩展
```
用户：从"人工智能在医疗领域的应用"中提取关键词
助手：提炼出关键词：人工智能, 医疗, 诊断, 应用
用户：满意，继续扩展
助手：扩展关键词：机器学习, 深度学习, 医疗AI, 智能诊断...
```

### 场景2：图片搜索和分析
```
用户：搜索关于"深度学习"的图片
助手：已下载15张相关图片
用户：继续分析这些图片
助手：分析完成，保留12张相关图片，删除3张不相关图片
```

### 场景3：完整工作流
```
用户：帮我处理这个主题：网络安全威胁
助手：提取关键词：网络安全, 威胁, 攻击
用户：满意，继续扩展
助手：扩展关键词：网络攻击, 恶意软件, 数据泄露...
用户：满意，搜索相关图片
助手：已下载20张图片
用户：继续分析
助手：分析完成，保留18张图片
用户：继续分类
助手：分类完成
用户：生成报告
助手：CSV报告已生成：classification_report_20251117_171500.csv
```

## 使用方法

### 基本使用
```python
from react_agent import assistant

# 单次查询
result = assistant.run("北京天气怎么样？")
print(result['response'])

# 带会话ID的交互（保持上下文）
result = assistant.run("继续扩展关键词", thread_id="user_session_001")
```

### 运行测试
```bash
python test_interactive_agent.py
```

## 技术架构

### 核心组件
- **Agent节点**: 智能决策中心
- **状态管理**: 使用TypedDict定义完整状态
- **记忆存储**: LangGraph的MemorySaver实现短期记忆
- **工具集成**: 天气、新闻、图片搜索、分析、分类工具

### 状态结构
```python
class AssistantState(TypedDict):
    messages: List[消息历史]
    user_input: str
    intent_type: str
    keywords: List[str]
    downloaded_images: List[Dict]
    analysis_results: List[Dict]
    classification_results: List[Dict]
    csv_file_path: str
    interaction_stage: str  # 当前交互阶段
    user_feedback: str      # 用户反馈
    risk_categories: List[str]  # 风险分类标签
```

### 交互阶段
- `initial`: 初始状态
- `keyword_extracted`: 关键词已提取
- `keyword_expanded`: 关键词已扩展
- `images_downloaded`: 图片已下载
- `images_analyzed`: 图片已分析
- `classified`: 关键词已分类

## 环境要求

### 依赖包
```
langchain-deepseek
langgraph
langchain-tavily
requests
pillow
lxml
playwright
python-dotenv
```

### 环境变量
```bash
# .env文件
OPENWEATHER_API_KEY=your_openweather_api_key
TAVILY_API_KEY=your_tavily_api_key
DASHSCOPE_API_KEY=your_dashscope_api_key
```

## 文件结构

```
image_agent/
├── react_agent.py          # 主智能助手
├── keyword_expansion.py    # 关键词扩展模块
├── image_analyzer.py       # 图片分析模块
├── get_image_url.py        # 图片URL获取
├── requests_download.py    # 图片下载（requests）
├── playwright_download.py  # 图片下载（playwright）
├── test_interactive_agent.py  # 测试脚本
├── INTERACTIVE_AGENT_README.md  # 本文档
└── assistant_results/      # CSV报告输出目录
```

## 注意事项

1. **API限制**: 确保所有API密钥有效且未超出使用限制
2. **网络代理**: 根据需要配置代理设置
3. **存储空间**: 图片下载和分析可能占用较多存储空间
4. **并发限制**: 合理设置并发线程数避免被封禁

## 扩展建议

1. **长期记忆**: 可以集成数据库存储用户历史会话
2. **多语言支持**: 扩展支持英文等其他语言
3. **自定义分类**: 允许用户自定义风险分类标签
4. **Web界面**: 开发Web界面提供可视化操作
5. **批量处理**: 支持批量关键词和批量图片处理