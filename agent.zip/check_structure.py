#!/usr/bin/env python3
"""
结构验证脚本 - 不依赖外部模块
"""

import os
import ast

def check_file_structure():
    """检查文件结构"""
    print("🔍 检查项目结构")
    print("=" * 40)
    
    # 检查核心文件
    core_files = [
        'react_agent.py',
        'keyword_expansion.py', 
        'image_analyzer.py',
        'get_image_url.py',
        'requests_download.py',
        'playwright_download.py',
        'requirements.txt'
    ]
    
    for file in core_files:
        if os.path.exists(file):
            print(f"✅ {file}")
        else:
            print(f"❌ {file} - 缺失")
    
    # 检查react_agent.py结构
    print("\n📋 检查react_agent.py结构")
    try:
        with open('react_agent.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 检查关键组件
        checks = [
            ('AssistantState', '状态类型定义'),
            ('SmartAssistant', '主类定义'),
            ('_agent_node', 'Agent节点方法'),
            ('_create_graph', '图创建方法'),
            ('risk_categories', '风险分类标签'),
            ('_classify_keywords', '关键词分类方法'),
            ('_generate_csv_report', 'CSV报告生成方法'),
            ('interaction_stage', '交互状态字段'),
            ('Checkpointer', '短期存储'),
            ('MemorySaver', '内存存储')
        ]
        
        for keyword, description in checks:
            if keyword in content:
                print(f"✅ {description}")
            else:
                print(f"❌ {description} - 未找到")
        
        # 检查CSV字段
        if 'keyword,label,img_file,img_url' in content:
            print("✅ CSV字段定义正确")
        else:
            print("❌ CSV字段定义缺失")
            
        # 检查交互方法
        interaction_methods = [
            '_handle_keyword_feedback',
            '_handle_expansion_feedback', 
            '_handle_image_feedback',
            '_handle_analysis_feedback',
            '_handle_classification_feedback'
        ]
        
        for method in interaction_methods:
            if method in content:
                print(f"✅ {method}")
            else:
                print(f"❌ {method}")
    
    except Exception as e:
        print(f"❌ 读取文件错误: {e}")

def check_directory_structure():
    """检查目录结构"""
    print("\n📁 检查目录结构")
    print("=" * 40)
    
    # 创建必要的目录
    directories = ['images_result', 'assistant_results', 'logs']
    
    for directory in directories:
        if os.path.exists(directory):
            print(f"✅ {directory}/")
        else:
            os.makedirs(directory, exist_ok=True)
            print(f"✅ {directory}/ - 已创建")

def check_requirements():
    """检查requirements.txt"""
    print("\n📦 检查依赖配置")
    print("=" * 40)
    
    try:
        with open('requirements.txt', 'r') as f:
            content = f.read()
        
        required_packages = [
            'langgraph',
            'langchain-deepseek',
            'dashscope',
            'playwright',
            'requests'
        ]
        
        for package in required_packages:
            if package in content:
                print(f"✅ {package}")
            else:
                print(f"⚠️  {package} - 建议添加")
    except:
        print("❌ requirements.txt读取失败")

if __name__ == "__main__":
    check_file_structure()
    check_directory_structure()
    check_requirements()
    
    print("\n" + "=" * 40)
    print("🎉 结构验证完成！")
    print("\n下一步:")
    print("1. 安装依赖: pip install -r requirements.txt")
    print("2. 配置环境变量: 创建.env文件")
    print("3. 运行测试: python3 test_interactive_agent.py")