# 🤖 智能助手系统 v2.0

基于产品定位要求重新设计的智能助手系统，支持关键词提炼、扩展、图片搜索、内容分类等功能。

## 🎯 产品定位

乐于助人的智能助手，擅长根据用户的问题选择合适的工具来查询信息并回答。

## ✨ 功能特性

### 1. 智能意图识别
- 自动识别用户输入的意图类型
- 支持天气、新闻、关键词处理等多种场景

### 2. 关键词处理
- **关键词提炼**：从描述性文本中提炼核心关键词
- **关键词扩展**：基于关键词扩展更多相关词汇
- **重新扩展**：用户不满意时可重新扩展

### 3. 图片搜索与下载
- 基于关键词搜索相关图片
- 支持批量下载和并发处理
- 自动过滤无效图片

### 4. 内容审核与分类
- 图片内容自动审核
- 关键词风险分类（9个预定义类别）
- 自动生成CSV和JSON报告

### 5. 普通聊天
- 支持天气查询
- 支持新闻搜索
- 支持日常对话

## 🚀 快速开始

### 环境要求

- Python 3.8+
- OpenAI API Key
- Tavily API Key（可选）

### 安装依赖

```bash
# 安装依赖包
pip install -r requirements_new.txt

# 复制环境变量模板
cp .env.example .env

# 编辑配置文件
vim .env
```

### 配置环境变量

在 `.env` 文件中设置：

```bash
# 必需
OPENAI_API_KEY=your_openai_api_key_here
TAVILY_API_KEY=your_tavily_api_key_here

# 可选
UNSPLASH_API_KEY=your_unsplash_api_key_here
PEXELS_API_KEY=your_pexels_api_key_here
```

### 运行程序

#### 交互式模式
```bash
python main_v2.py
```

#### 直接运行模式
```bash
# 关键词提炼
python main_v2.py --mode direct --type extract --input "未来科技城市景观"

# 关键词扩展
python main_v2.py --mode direct --type expand --input "人工智能"

# 图片搜索
python main_v2.py --mode direct --type search --input "机器学习"

# 内容分类
python main_v2.py --mode direct --type classify --input "深度学习"

# 普通聊天
python main_v2.py --mode direct --type chat --input "今天北京的天气怎么样？"
```

## 📋 使用场景

### 场景1：关键词提炼
```
用户输入："一座现代化的智能城市，有高楼大厦、自动驾驶汽车"
系统输出：提炼关键词：["智能城市", "高楼大厦", "自动驾驶", "未来科技"]
```

### 场景2：关键词扩展
```
用户输入："人工智能"
系统输出：扩展关键词：["机器学习", "深度学习", "神经网络", "自然语言处理"]
```

### 场景3：图片搜索
```
用户输入："搜索人工智能相关图片"
系统输出：下载20张相关图片到指定文件夹
```

### 场景4：内容分类
```
用户输入："对关键词进行分类"
系统输出：生成包含关键词、标签、图片路径的CSV文件
```

### 场景5：普通聊天
```
用户输入："今天北京的天气怎么样？"
系统输出：提供天气信息和相关建议
```

## 🏗️ 系统架构

```
智能助手系统 v2.0
├── 核心引擎 (intelligent_assistant.py)
├── 关键词处理 (keyword_expansion_v2.py)
├── 图片分析 (image_analyzer_v2.py)
├── 图片下载 (image_downloader_v2.py)
├── 内容分类 (content_classifier.py)
├── 聊天处理 (chat_handler.py)
├── 配置管理 (config_v2.py)
└── 主程序 (main_v2.py)
```

## 🔧 技术栈

- **AI框架**: LangChain, LangGraph
- **大模型**: OpenAI GPT-4o-mini
- **搜索**: Tavily Search API
- **异步**: asyncio, aiohttp
- **图片处理**: Pillow
- **数据存储**: CSV, JSON

## 📊 分类标签

系统支持以下9个风险分类标签：

1. **暴力与行为伤害**
2. **性相关风险**
3. **犯罪与违法活动**
4. **仇恨、不公与心理伤害**
5. **隐私与个人安全**
6. **虚假信息与不当影响**
7. **框架、体制和国家安全**
8. **版权与知识产权**
9. **灾害、紧急与敏感事件**
10. **正常内容**

## 📁 文件结构

```
assistant_results/          # 结果目录
├── downloads/              # 下载的图片
├── classification_reports/ # 分类报告
└── logs/                  # 日志文件
```

## 🛠️ 开发指南

### 添加新功能

1. 在对应模块中添加新功能
2. 更新主程序菜单
3. 添加测试用例

### 自定义配置

编辑 `config_v2.py` 文件修改系统配置。

### 扩展API

在 `image_downloader_v2.py` 中添加新的图片搜索API。

## 🧪 测试

```bash
# 运行模块测试
python keyword_expansion_v2.py
python image_analyzer_v2.py
python content_classifier.py
python chat_handler.py
```

## 🤝 贡献

欢迎提交Issue和Pull Request！

## 📄 许可证

MIT License