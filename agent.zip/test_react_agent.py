#!/usr/bin/env python3
"""
React智能助手测试脚本
"""

import asyncio
import sys
import os

# 添加当前目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from react_agent import assistant

def test_all_features():
    """测试所有功能"""
    
    print("🤖 React智能助手测试开始...")
    print("=" * 50)
    
    test_cases = [
        {
            "name": "天气查询",
            "input": "北京天气怎么样？",
            "expected_intent": "weather"
        },
        {
            "name": "新闻搜索", 
            "input": "今天有什么科技新闻？",
            "expected_intent": "news"
        },
        {
            "name": "关键词提炼",
            "input": "从'人工智能在医疗领域的应用'中提取关键词",
            "expected_intent": "keyword_extraction"
        },
        {
            "name": "关键词扩展",
            "input": "扩展关键词'机器学习'",
            "expected_intent": "keyword_expansion"
        },
        {
            "name": "图片搜索",
            "input": "搜索关于'猫'的图片",
            "expected_intent": "image_search"
        },
        {
            "name": "关键词分类",
            "input": "对关键词'网络安全'进行分类",
            "expected_intent": "classification"
        },
        {
            "name": "普通聊天",
            "input": "你好，今天过得怎么样？",
            "expected_intent": "chat"
        }
    ]
    
    results = []
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n{i}. 测试{test_case['name']}")
        print(f"输入: {test_case['input']}")
        
        try:
            result = assistant.run(test_case['input'], thread_id=f"test_{i}")
            
            print(f"✅ 成功")
            print(f"意图类型: {result['intent_type']}")
            print(f"响应: {result['response'][:100]}...")
            
            # 验证意图类型
            is_correct = result['intent_type'] == test_case['expected_intent']
            results.append({
                'test': test_case['name'],
                'success': True,
                'correct_intent': is_correct,
                'response': result['response']
            })
            
        except Exception as e:
            print(f"❌ 失败: {str(e)}")
            results.append({
                'test': test_case['name'],
                'success': False,
                'error': str(e)
            })
    
    # 打印总结
    print("\n" + "=" * 50)
    print("📊 测试结果总结")
    print("=" * 50)
    
    successful_tests = sum(1 for r in results if r['success'])
    print(f"总测试数: {len(test_cases)}")
    print(f"成功测试: {successful_tests}")
    print(f"失败测试: {len(test_cases) - successful_tests}")
    
    if successful_tests == len(test_cases):
        print("🎉 所有测试通过！")
    else:
        print("⚠️  部分测试失败，请检查错误信息")
        for result in results:
            if not result['success']:
                print(f"  - {result['test']}: {result.get('error', '未知错误')}")

def interactive_mode():
    """交互模式"""
    print("\n🎯 进入交互模式")
    print("输入 'quit' 或 'exit' 退出")
    print("-" * 30)
    
    while True:
        user_input = input("\n请输入您的问题: ").strip()
        
        if user_input.lower() in ['quit', 'exit', '退出']:
            print("👋 再见！")
            break
        
        if not user_input:
            continue
        
        try:
            print("🔄 正在处理...")
            result = assistant.run(user_input)
            
            print(f"\n🤖 助手回复:")
            print(result['response'])
            
            # 显示额外信息
            if result.get('keywords'):
                print(f"关键词: {', '.join(result['keywords'])}")
            if result.get('downloaded_images'):
                print(f"下载图片: {len(result['downloaded_images'])} 张")
            if result.get('csv_file_path'):
                print(f"CSV报告: {result['csv_file_path']}")
                
        except KeyboardInterrupt:
            print("\n👋 用户中断，再见！")
            break
        except Exception as e:
            print(f"❌ 处理失败: {str(e)}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--interactive":
        interactive_mode()
    else:
        test_all_features()