import os
import io
import requests
from PIL import Image
from concurrent.futures import ThreadPoolExecutor, as_completed


# 获取当前文件的绝对路径（包含文件名）
current_path = os.path.realpath(__file__)

# 获取目录路径
file_dir = os.path.dirname(current_path)


# 配置代理
proxy = {'proxy': {'http': 'http://127.0.0.1:13659'}}


user_agent = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 "
              "Safari/537.36")

headers = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/avif,image/apng,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Referer": "https://www.google.com/",
    "Sec-Ch-Ua": '"Chromium";v="142", "Google Chrome";v="142", "Not=A?Brand";v="99"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Fetch-Dest": "image",
    "Sec-Fetch-Mode": "no-cors",
    "Sec-Fetch-Site": "cross-site",
    "Connection": "keep-alive",
    "User-Agent": user_agent
}


def download_image(url_data):
    """
    图片下载
    """
    file, url = url_data
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()  # 如果请求失败则抛出异常
        if response.status_code != 200 and 'http://' in url:
            temp_url = url.replace('http://', 'https://')
            response = requests.get(temp_url, headers=headers, timeout=10)
            response.raise_for_status()  # 如果请求失败则抛出异常

        if response.status_code == 200:
            # 使用PIL打开图片并转换为PNG格式
            image = Image.open(io.BytesIO(response.content))

            # 保存为PNG格式
            image.save(file, 'PNG')

        print("成功下载:", url, file)
        return True
    except Exception as e:
        print("下载失败:", url, e)
        return False


def save_image(tasks, max_workers=10):
    """
    requests 多线程保存图片
    """
    success_list, failed_list = [], []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_task = {
            executor.submit(download_image, task): task
            for task in tasks
        }

        for future in as_completed(future_to_task):
            file, url = future_to_task[future]
            try:
                download_flag = future.result()
                if download_flag:
                    success_list.append([file, url])
                else:
                    failed_list.append([file, url])
            except Exception as e:
                print(f"任务执行异常: {e}")
                failed_list.append([file, url])

    print(f"\n🎉 requests请求下载完成! 图片总量: {len(tasks)} 张\n"
          f"成功: {len(success_list)}张\n失败: {len(failed_list)} 张")

    return success_list, failed_list


# if __name__ == '__main__':
#     temp_keyword = '四人帮'
#
#     img_url_list = []
#     record_file = os.path.join(file_dir, 'google_img_url3.csv')
#     if os.path.exists(record_file):
#         with open(record_file, "r", encoding="utf-8-sig") as r:
#             read_lines = r.readlines()
#             for each_line in read_lines:
#                 img_url_list.append(each_line.replace('\n', ''))
#
#     file_path = os.path.join(file_dir, temp_keyword)
#
#     # 创建保存图片的目录
#     os.makedirs(file_path, exist_ok=True)
#
#     tasks = [(os.path.join(file_path, f"{index}.png"), url) for index, url in enumerate(img_url_list)]
#
#     failed_urls = save_image(tasks, max_workers=10)  # 保存图片


