"""
基于LangGraph的agent驱动图片爬取工作流
集成关键词扩展、图片下载、内容审核的完整agent系统
"""

import os
from datetime import datetime
from typing import Dict, List, TypedDict, Annotated
from langchain_deepseek import ChatDeepSeek
from langchain_core.messages import HumanMessage, AIMessage
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from keyword_expansion import KeywordExpansion
from image_analyzer import ImageContentAnalyzer
import get_image_url
import requests_download
import playwright_download

class ImageCrawlerState(TypedDict):
    """定义agent状态"""
    topic: str
    keywords: List[str]
    current_keyword: str
    downloaded_images: List[str]
    analysis_results: List[Dict]
    messages: Annotated[List, add_messages]
    iteration: int
    max_iterations: int
    user_intent: str  # 用户意图: "chat", "expand_keywords", "extract_keywords"
    need_expansion: bool  # 是否需要关键词扩展
    need_extraction: bool  # 是否需要关键词提炼

class ImageCrawlerAgent:
    def __init__(self):
        self.keyword_expander = KeywordExpansion()
        self.image_analyzer = ImageContentAnalyzer()
        self.model = ChatDeepSeek(model="deepseek-chat")
        self.date_time = datetime.now().strftime("%Y%m%d%H%M%S")
        self.save_path = os.path.join(os.path.dirname(__file__), "images_result", self.date_time)
        
        # 创建状态图
        self.workflow = self._create_workflow()
        
    def _create_workflow(self) -> StateGraph:
        """创建LangGraph工作流"""
        
        # 定义工作流节点
        workflow = StateGraph(ImageCrawlerState)
        
        # 添加节点
        workflow.add_node("judge_intent", self._judge_intent_node)
        workflow.add_node("chat_mode", self._chat_mode_node)
        workflow.add_node("judge_keyword_expansion", self._judge_keyword_expansion_node)
        workflow.add_node("judge_prompt_extraction", self._judge_prompt_extraction_node)
        workflow.add_node("extract_keywords", self._extract_keywords_node)
        workflow.add_node("expand_keywords", self._expand_keywords_node)
        workflow.add_node("download_images", self._download_images_node)
        workflow.add_node("analyze_images", self._analyze_images_node)
        workflow.add_node("adjust_keywords", self._adjust_keywords_node)
        workflow.add_node("generate_report", self._generate_report_node)
        
        # 添加边：从START到意图判断
        workflow.add_edge(START, "judge_intent")
        
        # 条件边：根据意图判断结果路由
        workflow.add_conditional_edges(
            "judge_intent",
            self._route_by_intent,
            {
                "chat": "chat_mode",
                "keyword": "judge_keyword_expansion",
                "prompt": "judge_prompt_extraction"
            }
        )
        
        # 聊天模式直接结束
        workflow.add_edge("chat_mode", END)
        
        # 关键词路径：判断是否需要扩展
        workflow.add_conditional_edges(
            "judge_keyword_expansion",
            self._route_keyword_expansion,
            {
                "expand": "expand_keywords",
                "direct": "download_images"  # 不需要扩展时直接使用关键词下载
            }
        )
        
        # Prompt路径：判断是否需要提炼
        workflow.add_conditional_edges(
            "judge_prompt_extraction",
            self._route_prompt_extraction,
            {
                "extract": "extract_keywords",
                "chat": "chat_mode"
            }
        )
        
        # 关键词提炼后进入扩展流程
        workflow.add_edge("extract_keywords", "expand_keywords")
        
        # 关键词扩展后判断是否需要下载图片
        workflow.add_conditional_edges(
            "expand_keywords",
            self._should_download_images,
            {
                "download": "download_images",
                "skip": "generate_report"
            }
        )
        workflow.add_edge("download_images", "analyze_images")
        workflow.add_edge("analyze_images", "adjust_keywords")
        
        # 条件边：根据迭代次数决定是否继续
        workflow.add_conditional_edges(
            "adjust_keywords",
            self._should_continue,
            {
                "continue": "download_images",
                "finish": "generate_report"
            }
        )
        workflow.add_edge("generate_report", END)

        workflow = workflow.compile()
        
        return workflow
    
    def _judge_intent_node(self, state: ImageCrawlerState) -> Dict:
        """用户意图判断节点"""
        topic = state["topic"]
        messages = state.get("messages", [])
        
        # 获取最后一条用户消息
        user_input = topic
        if messages:
            for msg in reversed(messages):
                if hasattr(msg, 'content') and isinstance(msg, HumanMessage):
                    user_input = msg.content
                    break
        
        print(f"正在判断用户意图: {user_input}")
        
        # 使用大模型判断用户意图
        intent_result = self.keyword_expander.judge_user_intent(user_input)
        intent_type = intent_result.get("intent_type", "chat")
        
        print(f"用户意图判断结果: {intent_type}, 原因: {intent_result.get('reason', '')}")
        
        return {
            "user_intent": intent_type,
            "messages": [AIMessage(content=f"已识别用户意图: {intent_type}")]
        }
    
    def _route_by_intent(self, state: ImageCrawlerState) -> str:
        """根据用户意图路由"""
        intent = state.get("user_intent", "chat")
        
        if intent == "keyword":
            return "keyword"
        elif intent == "prompt":
            return "prompt"
        else:
            return "chat"
    
    def _judge_keyword_expansion_node(self, state: ImageCrawlerState) -> Dict:
        """判断关键词是否需要扩展"""
        topic = state["topic"]
        
        print(f"正在判断关键词 '{topic}' 是否需要扩展...")
        
        # 使用大模型判断是否需要扩展
        expansion_result = self.keyword_expander.judge_need_expansion(topic)
        need_expansion = expansion_result.get("need_expansion", True)
        
        print(f"扩展判断结果: {'需要扩展' if need_expansion else '不需要扩展'}, 原因: {expansion_result.get('reason', '')}")
        
        # 如果不需要扩展，直接将关键词放入keywords列表
        keywords = []
        if not need_expansion:
            keywords = [topic]
        
        return {
            "need_expansion": need_expansion,
            "keywords": keywords,
            "messages": [AIMessage(content=f"关键词扩展判断: {'需要扩展' if need_expansion else '不需要扩展，直接使用关键词'}")]
        }
    
    def _route_keyword_expansion(self, state: ImageCrawlerState) -> str:
        """根据扩展判断结果路由"""
        if state.get("need_expansion", True):
            return "expand"
        else:
            # 不需要扩展时，直接将关键词放入keywords列表，然后下载图片
            topic = state.get("topic", "")
            return "direct"
    
    def _judge_prompt_extraction_node(self, state: ImageCrawlerState) -> Dict:
        """判断prompt是否需要提炼关键词"""
        topic = state["topic"]
        
        print(f"正在判断描述 '{topic}' 是否需要提炼关键词...")
        
        # 使用大模型判断是否需要提炼
        extraction_result = self.keyword_expander.judge_need_extraction(topic)
        need_extraction = extraction_result.get("need_extraction", True)
        
        print(f"提炼判断结果: {'需要提炼' if need_extraction else '不需要提炼'}, 原因: {extraction_result.get('reason', '')}")
        
        return {
            "need_extraction": need_extraction,
            "messages": [AIMessage(content=f"关键词提炼判断: {'需要提炼' if need_extraction else '不需要提炼'}")]
        }
    
    def _route_prompt_extraction(self, state: ImageCrawlerState) -> str:
        """根据提炼判断结果路由"""
        if state.get("need_extraction", True):
            return "extract"
        else:
            return "chat"
    
    def _extract_keywords_node(self, state: ImageCrawlerState) -> Dict:
        """关键词提炼节点"""
        topic = state["topic"]
        
        print(f"正在从描述中提炼关键词: {topic}")
        
        # 使用关键词扩展器提炼关键词
        extracted = self.keyword_expander.extract_keywords_from_prompt(topic)
        
        # 提取关键词列表
        keywords = [item["keyword"] for item in extracted]
        
        # 如果提炼出关键词，更新topic为第一个关键词（用于后续扩展）
        if keywords:
            topic = keywords[0]
        
        print(f"提炼出的关键词: {', '.join(keywords)}")
        
        return {
            "topic": topic,
            "keywords": keywords,
            "messages": [AIMessage(content=f"已提炼关键词: {', '.join(keywords)}")]
        }
    
    def _chat_mode_node(self, state: ImageCrawlerState) -> Dict:
        """聊天模式节点"""
        messages = state.get("messages", [])
        topic = state["topic"]
        
        # 使用大模型进行聊天回复
        try:
            response = self.model.invoke(messages)
            reply_content = response.content if hasattr(response, 'content') else str(response)
            
            print(f"聊天回复: {reply_content}")
            
            return {
                "messages": [AIMessage(content=reply_content)]
            }
        except Exception as e:
            print(f"聊天模式处理失败: {e}")
            return {
                "messages": [AIMessage(content=f"抱歉，我无法理解您的输入。请提供更明确的关键词或描述。")]
            }
    
    def _expand_keywords_node(self, state: ImageCrawlerState) -> Dict:
        """关键词扩展节点"""
        topic = state["topic"]
        keywords = state.get("keywords", [])
        
        # 如果已经有提炼的关键词，直接使用；否则进行扩展
        if keywords:
            # 对每个关键词进行扩展
            expanded_keywords = []
            for keyword in keywords:
                expanded = self.keyword_expander.get_expanded_keywords_for_topic(keyword)
                expanded_keywords.extend(expanded)
            # 去重
            keywords = list(set(expanded_keywords))
        else:
            # 使用关键词扩展器获取相关关键词
            keywords = self.keyword_expander.get_expanded_keywords_for_topic(topic)
        
        return {
            "keywords": keywords,
            "messages": [AIMessage(content=f"已扩展关键词: {', '.join(keywords)}")],
            "iteration": 0
        }
    
    def _should_download_images(self, state: ImageCrawlerState) -> str:
        """判断是否需要下载图片"""
        keywords = state.get("keywords", [])
        
        # 如果有关键词，则需要下载图片
        if keywords:
            return "download"
        else:
            # 没有关键词，直接跳过下载
            return "skip"
    
    def _download_images_node(self, state: ImageCrawlerState) -> Dict:
        """图片下载节点（作为工具调用）"""
        keywords = state.get("keywords", [])
        downloaded_images = state.get("downloaded_images", [])
        
        for keyword in keywords:
            print(f"正在下载关键词 '{keyword}' 的图片...")
            
            # 获取图片URL
            img_url_list = get_image_url.get_keyword_image(keyword)
            
            if not img_url_list:
                print(f"关键词 '{keyword}' 未找到图片")
                continue
            
            # 创建保存目录
            save_dir = os.path.join(self.save_path, keyword)
            
            os.makedirs(save_dir, exist_ok=True)

            print(f'结果文件存放目录：{save_dir}')
            
            # 准备下载任务
            tasks = [(os.path.join(save_dir, f"{index}.png"), url) for index, url in enumerate(img_url_list)]
            
            # 下载图片
            failed_count = 0
            success_list, failed_list = requests_download.save_image(tasks, max_workers=30)
            if failed_list:
                temp_success_list, temp_failed_list = playwright_download.save_image(failed_list, max_workers=10)
                success_list.extend(temp_success_list)
                failed_count += len(temp_failed_list)
            
            # 记录下载的图片
            downloaded_images.extend([file for file, url in success_list])
            
            print(f"关键词 '{keyword}' 图片下载完成，共: {len(img_url_list)} 张\n成功: {len(success_list)} 张\n失败: {failed_count} 张")
        
        return {
            "downloaded_images": downloaded_images,
            "current_keyword": keywords[0] if keywords else "",
            "messages": [AIMessage(content=f"已下载 {len(downloaded_images)} 张图片")]
        }
    
    def _analyze_images_node(self, state: ImageCrawlerState) -> Dict:
        """图片分析节点（多线程批量分析）"""
        keywords = state.get("keywords", [])
        analysis_results = state.get("analysis_results", [])
        
        for keyword in keywords:
            image_folder = os.path.join(self.save_path, keyword)
            
            if not os.path.exists(image_folder):
                continue
            
            print(f"正在分析关键词 '{keyword}' 的图片...")
            
            # 多线程批量分析图片
            results = self.image_analyzer.batch_analyze_images(image_folder, keyword, max_workers=10)
            
            print(f"正在过滤和清理关键词 '{keyword}' 的图片...")

            # 过滤和清理图片
            filter_results = self.image_analyzer.filter_and_cleanup_images(results)
            
            # 记录分析结果
            analysis_results.append({
                "keyword": keyword,
                "total_images": len(results),
                "kept_images": filter_results["keep_count"],
                "removed_images": filter_results["remove_count"],
                "filter_results": filter_results
            })
            
            print(f"关键词 '{keyword}' 分析完成，保留 {filter_results['keep_count']} 张图片")
        
        return {
            "analysis_results": analysis_results,
            "messages": [AIMessage(content=f"已完成图片分析，共处理 {len(analysis_results)} 个关键词")]
        }
    
    def _adjust_keywords_node(self, state: ImageCrawlerState) -> Dict:
        """关键词调整节点"""
        current_iteration = state["iteration"]
        max_iterations = state["max_iterations"]
        analysis_results = state["analysis_results"]
        
        if current_iteration >= max_iterations - 1:
            return {"iteration": current_iteration + 1}
        
        # 根据分析结果调整关键词
        # 这里简化处理，实际可以根据保留率等指标调整
        keywords = state["keywords"]
        
        # 动态调整关键词（示例逻辑）
        adjusted_keywords = []
        for result in analysis_results:
            if result["kept_images"] > 0:  # 保留有图片的关键词
                adjusted_keywords.append(result["keyword"])
        
        # 如果没有有效关键词，添加原始话题
        if not adjusted_keywords:
            adjusted_keywords = [state["topic"]]
        
        return {
            "keywords": adjusted_keywords,
            "iteration": current_iteration + 1,
            "messages": [AIMessage(content=f"第{current_iteration + 1}轮调整，保留关键词: {', '.join(adjusted_keywords)}")]
        }
    
    def _should_continue(self, state: ImageCrawlerState) -> str:
        """判断是否继续迭代"""
        if state["iteration"] >= state["max_iterations"]:
            return "finish"
        return "continue"
    
    def _generate_report_node(self, state: ImageCrawlerState) -> Dict:
        """生成最终报告节点"""
        topic = state["topic"]
        analysis_results = state["analysis_results"]
        
        # 生成综合报告
        total_images = sum(result["total_images"] for result in analysis_results)
        total_kept = sum(result["kept_images"] for result in analysis_results)
        
        report = f"""
                    # 智能图片爬取系统最终报告

                    ## 搜索话题: {topic}

                    ## 执行统计
                    - 总迭代轮数: {state['iteration']}
                    - 处理关键词数量: {len(analysis_results)}
                    - 总下载图片: {total_images}
                    - 最终保留图片: {total_kept}
                    - 整体保留率: {total_kept/max(total_images, 1)*100:.1f}%

                    ## 各关键词详细统计
                    """
        
        for result in analysis_results:
            report += f"""
                        ### {result['keyword']}
                        - 下载图片: {result['total_images']}
                        - 保留图片: {result['kept_images']}
                        - 删除图片: {result['removed_images']}
                        - 保留率: {result['kept_images']/max(result['total_images'], 1)*100:.1f}%
                        """
        
        # 保存报告
        report_file = os.path.join(self.save_path, f"{topic}_final_report.md")
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)
        
        return {
            "messages": [AIMessage(content=f"任务完成！最终报告已保存到: {report_file}")]
        }
    
    def run(self, topic: str, max_iterations: int = 2) -> Dict:
        """运行图片爬取任务"""
        print(f"开始执行图片爬取任务，话题: {topic}")
        
        # 初始化状态
        initial_state = {
            "topic": topic,
            "keywords": [],
            "current_keyword": "",
            "downloaded_images": [],
            "analysis_results": [],
            "messages": [HumanMessage(content=topic)],
            "iteration": 0,
            "max_iterations": max_iterations,
            "user_intent": "",
            "need_expansion": False,
            "need_extraction": False
        }
        
        # 编译工作流
        app = self.workflow.compile()

        with open('workflow.png', "wb") as f:
            # 将状态图转换为Mermaid格式的PNG并写入文件
            f.write(app.get_graph().draw_mermaid_png())
        
        # 执行工作流
        final_state = app.invoke(initial_state)
        
        return final_state


# if __name__ == "__main__":
#     # 测试agent
#     agent = ImageCrawlerAgent()
#     app = agent.workflow.compile()
    
    # # 测试话题
    # test_topic = "色情"
    # result = agent.run(test_topic, max_iterations=2)
    
    # print(f"\n任务完成！")
    # print(f"最终状态: {result}")


agent = ImageCrawlerAgent()
graph = agent.workflow
