"""
基于LangGraph的React智能助手系统 - 以Agent节点为中心的重构版本
集成天气查询、新闻搜索、关键词处理、图片下载、内容审核、分类等完整功能
"""

import os
import json
import csv
from datetime import datetime
from typing import Dict, List, TypedDict, Annotated, Optional, Any, Literal
from langchain_deepseek import ChatDeepSeek
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.types import Checkpointer
from langgraph.checkpoint.memory import MemorySaver
from langchain_core.tools import tool
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables import RunnableConfig

# 导入现有模块
from keyword_expansion import KeywordExpansion
from image_analyzer import ImageContentAnalyzer
import get_image_url
import requests_download
import playwright_download

# 导入graph.py中的工具
import requests
from dotenv import load_dotenv
from langchain_tavily import TavilySearch
from pydantic import BaseModel, Field

load_dotenv(override=True)

# 定义状态类型
class AssistantState(TypedDict):
    """智能助手状态 - 支持交互式处理"""
    messages: Annotated[List, add_messages]
    user_input: str
    intent_type: str  # "weather", "news", "keyword_extraction", "keyword_expansion", "image_search", "image_analysis", "classification"
    keywords: List[str]
    current_keyword: str
    downloaded_images: List[Dict[str, str]]  # [{"path": "", "url": ""}]
    analysis_results: List[Dict]
    classification_results: List[Dict]
    csv_file_path: str
    final_response: str
    context: Dict[str, Any]  # 存储上下文信息
    
    # 新增交互状态
    interaction_stage: str  # 交互阶段："initial", "keyword_extracted", "keyword_expanded", "images_downloaded", "images_analyzed", "classified"
    user_feedback: str  # 用户反馈："satisfied", "regenerate", "expand", "classify"
    previous_keywords: List[str]  # 之前的关键词，用于重新生成
    risk_categories: List[str]  # 风险分类标签

# 工具定义
class WeatherQuery(BaseModel):
    loc: str = Field(description="The location name of the city")

@tool(args_schema=WeatherQuery)
def get_weather(loc):
    """查询即时天气函数"""
    url = "https://api.openweathermap.org/data/2.5/weather"
    params = {
        "q": loc,
        "appid": os.getenv("OPENWEATHER_API_KEY"),
        "units": "metric",
        "lang": "zh_cn"
    }
    response = requests.get(url, params=params)
    data = response.json()
    return json.dumps(data, ensure_ascii=False)

# 初始化工具
search_tool = TavilySearch(max_results=5, topic="general")

class SmartAssistant:
    """智能助手主类 - 以Agent节点为中心的重构"""
    
    def __init__(self):
        self.model = ChatDeepSeek(model="deepseek-chat")
        self.keyword_expander = KeywordExpansion()
        self.image_analyzer = ImageContentAnalyzer()
        self.memory_saver = MemorySaver()
        
        # 风险分类标签
        self.risk_categories = [
            '暴力与行为伤害', '性相关风险', '犯罪与违法活动', 
            '仇恨、不公与心理伤害', '隐私与个人安全', '虚假信息与不当影响',
            '框架、体制和国家安全', '版权与知识产权', '灾害、紧急与敏感事件'
        ]
        
        # 创建图
        self.graph = self._create_graph()
    
    def _create_graph(self) -> StateGraph:
        """创建以Agent节点为中心的LangGraph工作流"""
        
        workflow = StateGraph(AssistantState)
        
        # 添加Agent节点 - 以agent为中心的处理节点
        workflow.add_node("agent", self._agent_node)
        workflow.add_node("weather_handler", self._handle_weather_query)
        workflow.add_node("news_handler", self._handle_news_query)
        workflow.add_node("keyword_extraction", self._extract_keywords)
        workflow.add_node("keyword_expansion", self._expand_keywords)
        workflow.add_node("image_search", self._search_images)
        workflow.add_node("image_analysis", self._analyze_images)
        workflow.add_node("keyword_classification", self._classify_keywords)
        workflow.add_node("generate_csv", self._generate_csv_report)
        workflow.add_node("chat_handler", self._handle_chat)
        
        # 添加边
        workflow.add_edge(START, "agent")
        
        # 条件边：agent根据意图路由到具体处理节点
        workflow.add_conditional_edges(
            "agent",
            self._route_by_intent,
            {
                "weather": "weather_handler",
                "news": "news_handler",
                "keyword_extraction": "keyword_extraction",
                "keyword_expansion": "keyword_expansion",
                "image_search": "image_search",
                "image_analysis": "image_analysis",
                "classification": "keyword_classification",
                "chat": "chat_handler"
            }
        )
        
        # 交互式处理流程
        workflow.add_conditional_edges(
            "keyword_extraction",
            self._handle_keyword_feedback,
            {
                "expand": "keyword_expansion",
                "regenerate": "keyword_extraction",
                "satisfied": "keyword_expansion",
                "end": END
            }
        )
        
        workflow.add_conditional_edges(
            "keyword_expansion",
            self._handle_expansion_feedback,
            {
                "search": "image_search",
                "regenerate": "keyword_expansion",
                "satisfied": "image_search",
                "end": END
            }
        )
        
        workflow.add_conditional_edges(
            "image_search",
            self._handle_image_feedback,
            {
                "analyze": "image_analysis",
                "regenerate": "image_search",
                "satisfied": "image_analysis",
                "end": END
            }
        )
        
        workflow.add_conditional_edges(
            "image_analysis",
            self._handle_analysis_feedback,
            {
                "classify": "keyword_classification",
                "regenerate": "image_analysis",
                "satisfied": "keyword_classification",
                "end": END
            }
        )
        
        workflow.add_conditional_edges(
            "keyword_classification",
            self._handle_classification_feedback,
            {
                "generate_csv": "generate_csv",
                "regenerate": "keyword_classification",
                "satisfied": "generate_csv",
                "end": END
            }
        )
        
        # 结束边
        workflow.add_edge("weather_handler", END)
        workflow.add_edge("news_handler", END)
        workflow.add_edge("chat_handler", END)
        workflow.add_edge("generate_csv", END)

        # 编译图，添加内存存储
        app = workflow.compile()

        with open('workflow.png', "wb") as f:
            # 将状态图转换为Mermaid格式的PNG并写入文件
            f.write(app.get_graph().draw_mermaid_png())
        
        return app
    
    def _agent_node(self, state: AssistantState) -> Dict:
        """Agent节点 - 以agent为中心的智能决策节点"""
        user_input = state["user_input"]
        interaction_stage = state.get("interaction_stage", "initial")
        
        # 根据交互阶段和当前状态决定下一步操作
        if interaction_stage == "initial":
            # 初始阶段，判断用户意图
            return self._classify_intent(state)
        elif interaction_stage == "keyword_extracted":
            # 关键词已提取，等待用户反馈
            return self._handle_keyword_interaction(state)
        elif interaction_stage == "keyword_expanded":
            # 关键词已扩展，等待用户反馈
            return self._handle_expansion_interaction(state)
        elif interaction_stage == "images_downloaded":
            # 图片已下载，等待用户反馈
            return self._handle_image_interaction(state)
        elif interaction_stage == "images_analyzed":
            # 图片已分析，等待用户反馈
            return self._handle_analysis_interaction(state)
        elif interaction_stage == "classified":
            # 已分类，等待用户反馈
            return self._handle_classification_interaction(state)
        else:
            # 默认处理
            return self._classify_intent(state)
    
    def _classify_intent(self, state: AssistantState) -> Dict:
        """意图分类节点"""
        user_input = state["user_input"]
        
        # 使用大模型判断用户意图
        intent_prompt = f"""
        你是一个智能助手，需要准确判断用户的输入意图。
        
        用户输入：{user_input}
        
        请根据用户输入判断其意图类型：
        1. "weather" - 询问天气信息（如"北京天气如何"）
        2. "news" - 搜索新闻信息（如"今天有什么新闻"）
        3. "keyword_extraction" - 需要从描述中提炼关键词（如"帮我从这段文字中提取关键词"）
        4. "keyword_expansion" - 需要扩展关键词（如"扩展这个关键词"）
        5. "image_search" - 需要搜索并下载图片（如"搜索相关图片"）
        6. "image_analysis" - 需要分析已下载的图片（如"分析这些图片"）
        7. "classification" - 需要对关键词进行分类（如"对这些关键词进行分类"）
        8. "chat" - 普通聊天对话
        
        请只返回意图类型，不要其他内容。
        """
        
        response = self.model.invoke([HumanMessage(content=intent_prompt)])
        intent_type = response.content.strip().lower()
        
        # 验证意图类型
        valid_intents = ["weather", "news", "keyword_extraction", "keyword_expansion", 
                        "image_search", "image_analysis", "classification", "chat"]
        if intent_type not in valid_intents:
            intent_type = "chat"
        
        return {
            "intent_type": intent_type,
            "messages": [AIMessage(content=f"已识别意图: {intent_type}")]
        }
    
    def _route_by_intent(self, state: AssistantState) -> str:
        """根据意图路由"""
        return state.get("intent_type", "chat")
    
    def _handle_weather_query(self, state: AssistantState) -> Dict:
        """处理天气查询"""
        user_input = state["user_input"]
        
        # 提取城市名称
        city_prompt = f"""
        从用户输入中提取城市名称：{user_input}
        只返回城市名称，不要其他内容。
        """
        
        response = self.model.invoke([HumanMessage(content=city_prompt)])
        city = response.content.strip()
        
        if not city:
            return {
                "final_response": "无法识别城市名称，请重新输入",
                "messages": [AIMessage(content="无法识别城市名称")]
            }
        
        # 调用天气工具
        try:
            weather_data = json.loads(get_weather(city))
            if weather_data.get("cod") == 200:
                weather_info = weather_data["weather"][0]["description"]
                temp = weather_data["main"]["temp"]
                humidity = weather_data["main"]["humidity"]
                response_text = f"{city}当前天气：{weather_info}，温度：{temp}°C，湿度：{humidity}%"
            else:
                response_text = f"无法获取{city}的天气信息"
        except Exception as e:
            response_text = f"天气查询失败：{str(e)}"
        
        return {
            "final_response": response_text,
            "messages": [AIMessage(content=response_text)]
        }
    
    def _handle_news_query(self, state: AssistantState) -> Dict:
        """处理新闻查询"""
        user_input = state["user_input"]
        
        try:
            # 使用Tavily搜索新闻
            search_results = search_tool.invoke(user_input)
            
            # 格式化结果
            news_list = []
            if isinstance(search_results, list):
                for result in search_results:
                    if isinstance(result, dict):
                        title = result.get('title', '')
                        content = result.get('content', '')
                        url = result.get('url', '')
                    else:
                        title = str(result)
                        content = ""
                        url = ""
                    
                    news_list.append(f"标题：{title}\n摘要：{content}\n链接：{url}")
            else:
                news_list = [str(search_results)]
            
            response_text = f"为您找到以下相关新闻：\n\n" + "\n\n---\n\n".join(news_list[:3])
            
        except Exception as e:
            response_text = f"新闻搜索失败：{str(e)}"
        
        return {
            "final_response": response_text,
            "messages": [AIMessage(content=response_text)]
        }
    
    def _extract_keywords(self, state: AssistantState) -> Dict:
        """关键词提炼"""
        user_input = state["user_input"]
        
        # 使用关键词扩展器提炼关键词
        extracted = self.keyword_expander.extract_keywords_from_prompt(user_input)
        keywords = [item["keyword"] for item in extracted]
        
        response_text = f"从您的输入中提炼出以下关键词：{', '.join(keywords)}\n\n您可以选择：\n1. 满意这些关键词，继续扩展\n2. 不满意，重新提炼\n3. 结束处理"
        
        return {
            "keywords": keywords,
            "interaction_stage": "keyword_extracted",
            "final_response": response_text,
            "messages": [AIMessage(content=response_text)]
        }
    
    def _expand_keywords(self, state: AssistantState) -> Dict:
        """关键词扩展"""
        keywords = state.get("keywords", [])
        if not keywords:
            keywords = [state["user_input"]]
        
        expanded_keywords = []
        for keyword in keywords:
            expanded = self.keyword_expander.get_expanded_keywords_for_topic(keyword)
            expanded_keywords.extend(expanded)
        
        # 去重
        expanded_keywords = list(set(expanded_keywords))
        
        response_text = f"已扩展关键词：{', '.join(expanded_keywords)}\n\n您可以选择：\n1. 满意这些关键词，继续搜索图片\n2. 不满意，重新扩展\n3. 结束处理"
        
        return {
            "keywords": expanded_keywords,
            "interaction_stage": "keyword_expanded",
            "final_response": response_text,
            "messages": [AIMessage(content=response_text)]
        }
    
    def _search_images(self, state: AssistantState) -> Dict:
        """搜索并下载图片"""
        keywords = state.get("keywords", [])
        if not keywords:
            keywords = [state["user_input"]]
        
        downloaded_images = []
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_path = os.path.join("images_result", f"search_{timestamp}")
        
        for keyword in keywords:
            print(f"正在搜索关键词：{keyword}")
            
            # 获取图片URL
            img_urls = get_image_url.get_keyword_image(keyword)
            if not img_urls:
                continue
            
            # 创建保存目录
            save_dir = os.path.join(base_path, keyword)
            os.makedirs(save_dir, exist_ok=True)
            
            # 准备下载任务
            tasks = [(os.path.join(save_dir, f"{i}.jpg"), url) 
                    for i, url in enumerate(img_urls[:10])]  # 限制下载数量
            
            # 下载图片
            success_list, failed_list = requests_download.save_image(tasks, max_workers=10)
            if failed_list:
                temp_success, _ = playwright_download.save_image(failed_list, max_workers=5)
                success_list.extend(temp_success)
            
            # 记录下载结果
            for file_path, url in success_list:
                downloaded_images.append({
                    "keyword": keyword,
                    "path": file_path,
                    "url": url
                })
        
        response_text = f"已完成图片搜索和下载，共下载 {len(downloaded_images)} 张图片\n\n您可以选择：\n1. 继续分析这些图片\n2. 重新搜索\n3. 结束处理"
        
        return {
            "downloaded_images": downloaded_images,
            "interaction_stage": "images_downloaded",
            "final_response": response_text,
            "messages": [AIMessage(content=response_text)]
        }
    
    def _analyze_images(self, state: AssistantState) -> Dict:
        """分析已下载的图片"""
        downloaded_images = state.get("downloaded_images", [])
        if not downloaded_images:
            return {
                "final_response": "没有可分析的图片",
                "messages": [AIMessage(content="没有可分析的图片")]
            }
        
        analysis_results = []
        
        # 按关键词分组分析
        keyword_groups = {}
        for img in downloaded_images:
            keyword = img["keyword"]
            if keyword not in keyword_groups:
                keyword_groups[keyword] = []
            keyword_groups[keyword].append(img)
        
        for keyword, images in keyword_groups.items():
            image_folder = os.path.dirname(images[0]["path"])
            
            # 批量分析
            results = self.image_analyzer.batch_analyze_images(image_folder, keyword)
            
            # 过滤和清理
            filter_results = self.image_analyzer.filter_and_cleanup_images(results)
            
            analysis_results.append({
                "keyword": keyword,
                "total_images": len(results),
                "kept_images": filter_results["keep_count"],
                "removed_images": filter_results["remove_count"],
                "kept_paths": filter_results["kept"]
            })
        
        response_text = f"图片分析完成，共分析 {len(analysis_results)} 组图片\n\n您可以选择：\n1. 继续对关键词进行分类\n2. 重新分析\n3. 结束处理"
        
        return {
            "analysis_results": analysis_results,
            "interaction_stage": "images_analyzed",
            "final_response": response_text,
            "messages": [AIMessage(content=response_text)]
        }
    
    def _classify_keywords(self, state: AssistantState) -> Dict:
        """关键词分类"""
        keywords = state.get("keywords", [])
        if not keywords:
            keywords = [k["keyword"] for k in state.get("analysis_results", [])]
        
        classification_results = []
        
        for keyword in keywords:
            # 使用大模型分类
            classify_prompt = f"""
            请将关键词"{keyword}"分类到以下风险类别中：
            {', '.join(self.risk_categories)}
            
            请只返回最匹配的类别名称，不要其他内容。
            """
            
            response = self.model.invoke([HumanMessage(content=classify_prompt)])
            category = response.content.strip()
            
            # 验证类别
            if category not in self.risk_categories:
                category = "其他"
            
            classification_results.append({
                "keyword": keyword,
                "category": category
            })
        
        response_text = f"已完成关键词分类，共分类 {len(classification_results)} 个关键词\n\n您可以选择：\n1. 生成CSV报告\n2. 重新分类\n3. 结束处理"
        
        return {
            "classification_results": classification_results,
            "interaction_stage": "classified",
            "final_response": response_text,
            "messages": [AIMessage(content=response_text)]
        }
    
    def _generate_csv_report(self, state: AssistantState) -> Dict:
        """生成CSV报告"""
        downloaded_images = state.get("downloaded_images", [])
        classification_results = state.get("classification_results", [])
        
        if not downloaded_images:
            return {
                "final_response": "没有数据可生成报告",
                "messages": [AIMessage(content="没有数据可生成报告")]
            }
        
        # 创建CSV文件
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_filename = f"classification_report_{timestamp}.csv"
        csv_path = os.path.join("assistant_results", csv_filename)
        os.makedirs("assistant_results", exist_ok=True)
        
        # 准备数据
        csv_data = []
        category_map = {item["keyword"]: item["category"] 
                       for item in classification_results}
        
        for img in downloaded_images:
            keyword = img["keyword"]
            category = category_map.get(keyword, "未分类")
            
            csv_data.append({
                "keyword": keyword,
                "label": category,
                "img_file": img["path"],
                "img_url": img["url"]
            })
        
        # 写入CSV
        with open(csv_path, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['keyword', 'label', 'img_file', 'img_url']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(csv_data)
        
        response_text = f"CSV报告已生成：{csv_path}\n\n报告包含以下字段：\n- keyword: 关键词\n- label: 分类标签\n- img_file: 保存的图片路径\n- img_url: 图片链接\n\n您现在可以下载此CSV文件进行进一步分析。"
        
        return {
            "csv_file_path": csv_path,
            "final_response": response_text,
            "messages": [AIMessage(content=response_text)]
        }
    
    def _handle_chat(self, state: AssistantState) -> Dict:
        """处理普通聊天"""
        user_input = state["user_input"]
        messages = state.get("messages", [])

        content = """
                你是一个乐于助人的智能助手，擅长根据用户的问题选择合适的工具来查询信息并回答。
                请使用简体中文回答，条理清晰、简洁友好。
                """
        
        # 构建聊天提示
        chat_prompt = ChatPromptTemplate.from_messages([
            SystemMessage(content=content),
            MessagesPlaceholder(variable_name="messages"),
            HumanMessage(content=user_input)
        ])
        
        chain = chat_prompt | self.model
        response = chain.invoke({"messages": messages})
        
        return {
            "final_response": response.content,
            "messages": [AIMessage(content=response.content)]
        }
    
    # 交互反馈处理方法
    def _handle_keyword_feedback(self, state: AssistantState) -> str:
        """处理关键词提取后的用户反馈"""
        feedback = state.get("user_feedback", "satisfied").lower()
        if "重新" in feedback or "不满意" in feedback or "regenerate" in feedback:
            return "regenerate"
        elif "满意" in feedback or "继续" in feedback or "expand" in feedback:
            return "expand"
        elif "结束" in feedback or "停止" in feedback or "end" in feedback:
            return "end"
        else:
            return "expand"  # 默认继续
    
    def _handle_expansion_feedback(self, state: AssistantState) -> str:
        """处理关键词扩展后的用户反馈"""
        feedback = state.get("user_feedback", "satisfied").lower()
        if "重新" in feedback or "不满意" in feedback or "regenerate" in feedback:
            return "regenerate"
        elif "满意" in feedback or "继续" in feedback or "search" in feedback:
            return "search"
        elif "结束" in feedback or "停止" in feedback or "end" in feedback:
            return "end"
        else:
            return "search"  # 默认继续
    
    def _handle_image_feedback(self, state: AssistantState) -> str:
        """处理图片下载后的用户反馈"""
        feedback = state.get("user_feedback", "satisfied").lower()
        if "重新" in feedback or "不满意" in feedback or "regenerate" in feedback:
            return "regenerate"
        elif "满意" in feedback or "继续" in feedback or "analyze" in feedback:
            return "analyze"
        elif "结束" in feedback or "停止" in feedback or "end" in feedback:
            return "end"
        else:
            return "analyze"  # 默认继续
    
    def _handle_analysis_feedback(self, state: AssistantState) -> str:
        """处理图片分析后的用户反馈"""
        feedback = state.get("user_feedback", "satisfied").lower()
        if "重新" in feedback or "不满意" in feedback or "regenerate" in feedback:
            return "regenerate"
        elif "满意" in feedback or "继续" in feedback or "classify" in feedback:
            return "classify"
        elif "结束" in feedback or "停止" in feedback or "end" in feedback:
            return "end"
        else:
            return "classify"  # 默认继续
    
    def _handle_classification_feedback(self, state: AssistantState) -> str:
        """处理关键词分类后的用户反馈"""
        feedback = state.get("user_feedback", "satisfied").lower()
        if "重新" in feedback or "不满意" in feedback or "regenerate" in feedback:
            return "regenerate"
        elif "满意" in feedback or "继续" in feedback or "generate_csv" in feedback:
            return "generate_csv"
        elif "结束" in feedback or "停止" in feedback or "end" in feedback:
            return "end"
        else:
            return "generate_csv"  # 默认继续
    
    # 交互处理方法
    def _handle_keyword_interaction(self, state: AssistantState) -> Dict:
        """处理关键词提取后的交互"""
        user_input = state["user_input"]
        keywords = state.get("keywords", [])
        
        # 分析用户反馈
        if "重新" in user_input or "不满意" in user_input:
            # 重新提取关键词
            return self._extract_keywords(state)
        elif "满意" in user_input or "继续" in user_input:
            # 继续扩展关键词
            return {"user_feedback": "satisfied"}
        else:
            # 默认继续
            return {"user_feedback": "satisfied"}
    
    def _handle_expansion_interaction(self, state: AssistantState) -> Dict:
        """处理关键词扩展后的交互"""
        user_input = state["user_input"]
        
        if "重新" in user_input or "不满意" in user_input:
            return self._expand_keywords(state)
        elif "满意" in user_input or "继续" in user_input:
            return {"user_feedback": "satisfied"}
        else:
            return {"user_feedback": "satisfied"}
    
    def _handle_image_interaction(self, state: AssistantState) -> Dict:
        """处理图片下载后的交互"""
        user_input = state["user_input"]
        
        if "重新" in user_input or "不满意" in user_input:
            return self._search_images(state)
        elif "满意" in user_input or "继续" in user_input:
            return {"user_feedback": "satisfied"}
        else:
            return {"user_feedback": "satisfied"}
    
    def _handle_analysis_interaction(self, state: AssistantState) -> Dict:
        """处理图片分析后的交互"""
        user_input = state["user_input"]
        
        if "重新" in user_input or "不满意" in user_input:
            return self._analyze_images(state)
        elif "满意" in user_input or "继续" in user_input:
            return {"user_feedback": "satisfied"}
        else:
            return {"user_feedback": "satisfied"}
    
    def _handle_classification_interaction(self, state: AssistantState) -> Dict:
        """处理关键词分类后的交互"""
        user_input = state["user_input"]
        
        if "重新" in user_input or "不满意" in user_input:
            return self._classify_keywords(state)
        elif "满意" in user_input or "继续" in user_input:
            return {"user_feedback": "satisfied"}
        else:
            return {"user_feedback": "satisfied"}
    
    def run(self, user_input: str, thread_id: str = None) -> Dict[str, Any]:
        """运行智能助手"""
        
        # 初始化状态
        initial_state = {
            "messages": [HumanMessage(content=user_input)],
            "user_input": user_input,
            "intent_type": "",
            "keywords": [],
            "current_keyword": "",
            "downloaded_images": [],
            "analysis_results": [],
            "classification_results": [],
            "csv_file_path": "",
            "final_response": "",
            "context": {},
            "interaction_stage": "initial",
            "user_feedback": "",
            "previous_keywords": [],
            "risk_categories": self.risk_categories
        }
        
        # 配置检查点
        config = {"configurable": {"thread_id": thread_id or "default"}}
        
        # 执行工作流
        result = self.graph.invoke(initial_state, config)
        
        return {
            "response": result.get("final_response", ""),
            "intent_type": result.get("intent_type", ""),
            "keywords": result.get("keywords", []),
            "downloaded_images": result.get("downloaded_images", []),
            "csv_file_path": result.get("csv_file_path", ""),
            "messages": result.get("messages", []),
            "interaction_stage": result.get("interaction_stage", "initial")
        }

# 全局实例
assistant = SmartAssistant()
graph = assistant.graph

# if __name__ == "__main__":
#     # 测试智能助手
#     test_cases = [
#         "北京天气怎么样？",
#         "今天有什么科技新闻？",
#         "从'人工智能在医疗领域的应用'中提取关键词",
#         "扩展关键词'机器学习'",
#         "搜索关于'深度学习'的图片",
#         "对关键词'网络安全'进行分类"
#     ]
    
#     for test_input in test_cases:
#         print(f"\n测试输入：{test_input}")
#         result = assistant.run(test_input)
#         print(f"响应：{result['response']}")
#         print(f"意图类型：{result['intent_type']}")