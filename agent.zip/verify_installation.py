#!/usr/bin/env python3
"""
安装验证脚本
验证React智能助手系统是否安装正确
"""

import sys
import os
from datetime import datetime

def check_dependencies():
    """检查依赖是否安装"""
    print("🔍 检查依赖安装情况...")
    
    required_packages = [
        'langchain',
        'langgraph',
        'langchain_deepseek',
        'langchain_core',
        'langchain_tavily',
        'dashscope',
        'Pillow',
        'requests',
        'playwright',
        'python-dotenv'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
            print(f"✅ {package}")
        except ImportError:
            print(f"❌ {package}")
            missing_packages.append(package)
    
    return len(missing_packages) == 0, missing_packages

def check_environment():
    """检查环境变量"""
    print("\n🔍 检查环境变量...")
    
    from dotenv import load_dotenv
    load_dotenv()
    
    required_vars = ['OPENWEATHER_API_KEY', 'DASHSCOPE_API_KEY']
    missing_vars = []
    
    for var in required_vars:
        value = os.getenv(var)
        if value:
            print(f"✅ {var}: {value[:10]}...")
        else:
            print(f"❌ {var}: 未设置")
            missing_vars.append(var)
    
    return len(missing_vars) == 0, missing_vars

def check_modules():
    """检查模块导入"""
    print("\n🔍 检查模块导入...")
    
    modules_to_check = [
        'react_agent',
        'keyword_expansion',
        'image_analyzer',
        'get_image_url',
        'requests_download',
        'playwright_download'
    ]
    
    failed_modules = []
    
    for module in modules_to_check:
        try:
            __import__(module)
            print(f"✅ {module}")
        except Exception as e:
            print(f"❌ {module}: {str(e)}")
            failed_modules.append(module)
    
    return len(failed_modules) == 0, failed_modules

def test_basic_functionality():
    """测试基本功能"""
    print("\n🔍 测试基本功能...")
    
    try:
        from react_agent import assistant
        
        # 测试关键词扩展
        from keyword_expansion import KeywordExpansion
        expander = KeywordExpansion()
        keywords = expander.get_expanded_keywords_for_topic("测试")
        print(f"✅ 关键词扩展: {len(keywords)} 个关键词")
        
        # 测试图片分析器初始化
        from image_analyzer import ImageContentAnalyzer
        analyzer = ImageContentAnalyzer()
        print("✅ 图片分析器初始化成功")
        
        return True, []
        
    except Exception as e:
        print(f"❌ 基本功能测试失败: {str(e)}")
        return False, [str(e)]

def create_sample_env():
    """创建示例.env文件"""
    env_content = """# API密钥配置
OPENWEATHER_API_KEY=your_openweather_api_key_here
DASHSCOPE_API_KEY=your_dashscope_api_key_here

# 代理配置（可选）
HTTP_PROXY=
HTTPS_PROXY=
"""
    
    env_path = ".env"
    if not os.path.exists(env_path):
        with open(env_path, 'w') as f:
            f.write(env_content)
        print(f"📄 已创建示例.env文件，请配置API密钥")
        return True
    else:
        print("📄 .env文件已存在")
        return False

def main():
    """主验证流程"""
    print("🚀 React智能助手系统安装验证")
    print("=" * 50)
    
    # 创建示例.env文件
    create_sample_env()
    
    # 检查依赖
    deps_ok, missing_deps = check_dependencies()
    
    # 检查环境变量
    env_ok, missing_vars = check_environment()
    
    # 检查模块
    modules_ok, failed_modules = check_modules()
    
    # 测试基本功能
    func_ok, func_errors = test_basic_functionality()
    
    # 总结
    print("\n" + "=" * 50)
    print("📊 验证结果总结")
    print("=" * 50)
    
    all_good = deps_ok and env_ok and modules_ok and func_ok
    
    if all_good:
        print("🎉 系统验证通过！可以开始使用")
        print("\n下一步：")
        print("1. 配置.env文件中的API密钥")
        print("2. 运行: python main.py --react-test")
        print("3. 或运行: python main.py 进入交互模式")
    else:
        print("⚠️  发现问题，请修复后重试")
        
        if missing_deps:
            print(f"\n缺失依赖: {', '.join(missing_deps)}")
            print("安装命令: pip install -r requirements.txt")
        
        if missing_vars:
            print(f"\n缺失环境变量: {', '.join(missing_vars)}")
            print("请编辑.env文件配置API密钥")
        
        if failed_modules:
            print(f"\n模块导入失败: {', '.join(failed_modules)}")
        
        if func_errors:
            print(f"\n功能测试失败: {', '.join(func_errors)}")

if __name__ == "__main__":
    main()