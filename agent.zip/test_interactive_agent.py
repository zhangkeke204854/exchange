#!/usr/bin/env python3
"""
测试交互式智能助手
"""

import os
import sys
from react_agent import assistant

def test_interactive_features():
    """测试交互式功能"""
    print("🤖 测试交互式智能助手")
    print("=" * 50)
    
    # 测试用例
    test_cases = [
        {
            "name": "天气查询",
            "input": "北京天气怎么样？",
            "expected_intent": "weather"
        },
        {
            "name": "新闻搜索", 
            "input": "今天有什么科技新闻？",
            "expected_intent": "news"
        },
        {
            "name": "关键词提取",
            "input": "从'人工智能在医疗领域的应用'中提取关键词",
            "expected_intent": "keyword_extraction"
        },
        {
            "name": "关键词扩展",
            "input": "扩展关键词'机器学习'",
            "expected_intent": "keyword_expansion"
        },
        {
            "name": "图片搜索",
            "input": "搜索关于'深度学习'的图片",
            "expected_intent": "image_search"
        },
        {
            "name": "关键词分类",
            "input": "对关键词'网络安全'进行分类",
            "expected_intent": "classification"
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n{i}. 测试 {test_case['name']}")
        print(f"输入: {test_case['input']}")
        
        try:
            result = assistant.run(test_case['input'])
            print(f"✅ 意图识别: {result['intent_type']}")
            print(f"✅ 响应: {result['response'][:100]}...")
            
            # 验证意图类型
            if result['intent_type'] == test_case['expected_intent']:
                print(f"✅ 意图识别正确")
            else:
                print(f"⚠️  意图识别可能不正确，期望: {test_case['expected_intent']}, 实际: {result['intent_type']}")
                
        except Exception as e:
            print(f"❌ 测试失败: {e}")
    
    print("\n" + "=" * 50)
    print("🎉 测试完成！")

def test_interactive_workflow():
    """测试交互式工作流"""
    print("\n🔄 测试交互式工作流")
    print("=" * 50)
    
    # 模拟交互式对话
    conversation = [
        "帮我从这段文字中提取关键词：人工智能在医疗诊断中的应用",
        "满意，继续扩展",
        "满意这些关键词，搜索相关图片",
        "继续分析这些图片",
        "继续分类这些关键词",
        "生成CSV报告"
    ]
    
    thread_id = "test_interactive_001"
    
    for i, user_input in enumerate(conversation, 1):
        print(f"\n步骤 {i}: {user_input}")
        try:
            result = assistant.run(user_input, thread_id=thread_id)
            print(f"响应: {result['response'][:150]}...")
            print(f"交互阶段: {result.get('interaction_stage', 'unknown')}")
        except Exception as e:
            print(f"错误: {e}")
    
    print("\n" + "=" * 50)
    print("🎉 交互式工作流测试完成！")

if __name__ == "__main__":
    # 确保必要的目录存在
    os.makedirs("images_result", exist_ok=True)
    os.makedirs("assistant_results", exist_ok=True)
    
    # 运行测试
    test_interactive_features()
    test_interactive_workflow()