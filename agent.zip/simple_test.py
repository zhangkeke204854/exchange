#!/usr/bin/env python3
"""
简化测试脚本 - 验证核心功能
"""

import sys
import os

# 添加当前目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_keyword_system():
    """测试关键词系统"""
    print("🧪 测试关键词系统...")
    
    try:
        from keyword_expansion import KeywordExpansion
        
        expander = KeywordExpansion()
        
        # 测试关键词扩展
        keywords = expander.get_expanded_keywords_for_topic("人工智能")
        print(f"✅ 关键词扩展: {keywords}")
        
        # 测试关键词提炼
        extracted = expander.extract_keywords_from_prompt("人工智能在医疗领域的应用")
        print(f"✅ 关键词提炼: {[k['keyword'] for k in extracted]}")
        
        return True
        
    except Exception as e:
        print(f"❌ 关键词系统测试失败: {str(e)}")
        return False

def test_image_system():
    """测试图片系统"""
    print("🖼️  测试图片系统...")
    
    try:
        from image_analyzer import ImageContentAnalyzer
        
        analyzer = ImageContentAnalyzer()
        print("✅ 图片分析器初始化成功")
        
        return True
        
    except Exception as e:
        print(f"❌ 图片系统测试失败: {str(e)}")
        return False

def test_react_agent_basic():
    """测试React Agent基本功能"""
    print("🤖 测试React Agent基本功能...")
    
    try:
        from react_agent import SmartAssistant
        
        assistant = SmartAssistant()
        print("✅ React Agent初始化成功")
        
        # 测试关键词处理
        from keyword_expansion import KeywordExpansion
        expander = KeywordExpansion()
        
        # 测试关键词扩展
        keywords = expander.get_expanded_keywords_for_topic("机器学习")
        print(f"✅ 关键词扩展: {keywords}")
        
        return True
        
    except Exception as e:
        print(f"❌ React Agent测试失败: {str(e)}")
        return False

def main():
    """主测试流程"""
    print("🚀 React智能助手系统简化测试")
    print("=" * 50)
    
    tests = [
        ("关键词系统", test_keyword_system),
        ("图片系统", test_image_system),
        ("React Agent", test_react_agent_basic)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\n{test_name}:")
        success = test_func()
        results.append((test_name, success))
    
    # 总结
    print("\n" + "=" * 50)
    print("📊 测试结果总结")
    print("=" * 50)
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    for test_name, success in results:
        status = "✅ 通过" if success else "❌ 失败"
        print(f"{test_name}: {status}")
    
    print(f"\n总计: {passed}/{total} 测试通过")
    
    if passed == total:
        print("\n🎉 系统核心功能正常！")
        print("\n使用方法:")
        print("1. 配置.env文件中的API密钥")
        print("2. 运行: python main.py")
        print("3. 选择菜单中的'1. React智能助手模式'")
    else:
        print("\n⚠️  部分功能需要修复")

if __name__ == "__main__":
    main()