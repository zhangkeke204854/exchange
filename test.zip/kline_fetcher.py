"""
K线数据获取模块
支持模拟数据生成和真实API接入(预留接口)
"""
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any


class KlineFetcher:
    """K线数据获取器"""
    
    def __init__(self, mode: str = "mock"):
        """
        初始化K线获取器
        mode: 'mock' 模拟数据, 'api' 真实API(需要配置)
        """
        self.mode = mode
        self.cache = {}  # 缓存K线数据
    
    def get_kline_data(
        self, 
        contract_code: str, 
        bars: int = 200,
        timeframe: str = "1d"
    ) -> pd.DataFrame:
        """
        获取K线数据
        
        Args:
            contract_code: 合约代码,如 'RB2505'
            bars: 获取的K线数量
            timeframe: 时间周期, '1d'日线, '1h'小时线等
        
        Returns:
            DataFrame包含: datetime, open, high, low, close, volume
        """
        if self.mode == "mock":
            return self._generate_mock_kline(contract_code, bars, timeframe)
        elif self.mode == "api":
            return self._fetch_from_api(contract_code, bars, timeframe)
        else:
            raise ValueError(f"不支持的模式: {self.mode}")
    
    def _generate_mock_kline(
        self, 
        contract_code: str, 
        bars: int,
        timeframe: str
    ) -> pd.DataFrame:
        """
        生成模拟K线数据
        使用随机游走模型生成类似真实市场的数据
        """
        # 根据合约代码设置基础价格
        base_prices = {
            "RB": 3500,  # 螺纹钢
            "SH": 2800,  # 烧碱
            "HC": 3200,  # 热卷
            "I": 800,    # 铁矿石
        }
        
        # 提取品种代码
        product_code = ''.join([c for c in contract_code if c.isalpha()])
        base_price = base_prices.get(product_code, 3000)
        
        # 生成时间序列
        end_date = datetime.now()
        if timeframe == "1d":
            dates = [end_date - timedelta(days=i) for i in range(bars)]
        elif timeframe == "1h":
            dates = [end_date - timedelta(hours=i) for i in range(bars)]
        else:
            dates = [end_date - timedelta(days=i) for i in range(bars)]
        
        dates.reverse()
        
        # 生成价格数据(随机游走)
        np.random.seed(hash(contract_code) % 2**32)  # 使用合约代码作为种子,保证可重复
        
        returns = np.random.normal(0.0005, 0.015, bars)  # 日收益率
        close_prices = base_price * np.exp(np.cumsum(returns))
        
        # 生成OHLC
        data = []
        for i, (date, close) in enumerate(zip(dates, close_prices)):
            # 生成高低价
            volatility = abs(np.random.normal(0, 0.01))
            high = close * (1 + volatility)
            low = close * (1 - volatility)
            
            # 生成开盘价
            if i == 0:
                open_price = close * 0.998
            else:
                open_price = data[i-1]['close'] * (1 + np.random.normal(0, 0.005))
            
            # 确保OHLC关系正确
            high = max(high, open_price, close)
            low = min(low, open_price, close)
            
            # 生成成交量
            volume = int(np.random.uniform(50000, 200000))
            
            data.append({
                'datetime': date,
                'open': round(open_price, 2),
                'high': round(high, 2),
                'low': round(low, 2),
                'close': round(close, 2),
                'volume': volume
            })
        
        df = pd.DataFrame(data)
        df['datetime'] = pd.to_datetime(df['datetime'])
        
        return df
    
    def _fetch_from_api(
        self, 
        contract_code: str, 
        bars: int,
        timeframe: str
    ) -> pd.DataFrame:
        """
        从真实API获取K线数据
        TODO: 集成真实期货API(CTP、掘金、Tushare等)
        """
        # 预留接口,用户可以在这里集成真实API
        print("警告: 真实API模式未实现,使用模拟数据")
        return self._generate_mock_kline(contract_code, bars, timeframe)
    
    def get_latest_bar(self, contract_code: str) -> Dict[str, Any]:
        """获取最新的一根K线"""
        df = self.get_kline_data(contract_code, bars=1)
        if len(df) > 0:
            return df.iloc[-1].to_dict()
        return {}
    
    def format_kline_for_prompt(
        self, 
        df: pd.DataFrame, 
        recent_bars: int = 20
    ) -> str:
        """
        将K线数据格式化为适合放入prompt的字符串
        只显示最近的N根K线,避免prompt过长
        """
        if df is None or len(df) == 0:
            return "无K线数据"
        
        # 取最近的K线
        recent_df = df.tail(recent_bars)
        
        # 格式化为表格
        lines = ["## 最近K线数据"]
        lines.append(f"总计: {len(df)} 根K线, 显示最近 {len(recent_df)} 根")
        lines.append("")
        lines.append("| 日期 | 开盘 | 最高 | 最低 | 收盘 | 成交量 |")
        lines.append("|------|------|------|------|------|--------|")
        
        for _, row in recent_df.iterrows():
            date_str = row['datetime'].strftime('%Y-%m-%d')
            lines.append(
                f"| {date_str} | {row['open']:.2f} | {row['high']:.2f} | "
                f"{row['low']:.2f} | {row['close']:.2f} | {row['volume']:,} |"
            )
        
        # 添加统计信息
        lines.append("")
        lines.append("### 统计信息")
        lines.append(f"- 最新价: {recent_df.iloc[-1]['close']:.2f}")
        lines.append(f"- 最高价: {recent_df['high'].max():.2f}")
        lines.append(f"- 最低价: {recent_df['low'].min():.2f}")
        lines.append(f"- 平均价: {recent_df['close'].mean():.2f}")
        lines.append(f"- 价格变化: {((recent_df.iloc[-1]['close'] / recent_df.iloc[0]['close'] - 1) * 100):.2f}%")
        
        return "\n".join(lines)


# 全局K线获取器实例
_kline_fetcher = None

def get_kline_fetcher(mode: str = "mock") -> KlineFetcher:
    """获取K线获取器单例"""
    global _kline_fetcher
    if _kline_fetcher is None:
        _kline_fetcher = KlineFetcher(mode=mode)
    return _kline_fetcher


def get_kline_data(contract_code: str, bars: int = 200) -> pd.DataFrame:
    """便捷函数: 获取K线数据"""
    fetcher = get_kline_fetcher()
    return fetcher.get_kline_data(contract_code, bars)


if __name__ == "__main__":
    # 测试K线获取
    print("测试K线数据获取...")
    
    fetcher = KlineFetcher(mode="mock")
    df = fetcher.get_kline_data("RB2505", bars=100)
    
    print(f"\n获取到 {len(df)} 根K线")
    print("\n最近5根K线:")
    print(df.tail())
    
    print("\n格式化后的K线数据:")
    formatted = fetcher.format_kline_for_prompt(df, recent_bars=10)
    print(formatted)
