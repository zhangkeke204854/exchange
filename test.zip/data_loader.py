"""
数据加载模块
负责读取Word文档、Excel文件,并转换为JSON格式供Agent使用
"""

import os
import json
import pandas as pd
from typing import Dict, Any, Optional



def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """加载配置文件"""
    if not config_path:
        config_path = "futures_config.json"
    
    if not os.path.exists(config_path):
        print(f"配置文件 {config_path} 不存在...")
        return None
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"读取配置文件 {config_path} 时出错: {e}")
        return None


def read_txt(file_path: str) -> str:
    """
    读取TXT文本文件并提取内容
    """
    if not os.path.exists(file_path):
        print(f"txt文件 {file_path} 不存在...")
        return None
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            return content
    except Exception as e:
        print(f"读取txt文件 {file_path} 时出错: {e}")
        return None


def read_excel(file_path: str) -> str:
    """
    读取Excel文件并转换为markdown格式
    """
    if not os.path.exists(file_path):
        print(f"Excel文件 {file_path} 不存在...")
        return None
    
    try:
        df = pd.read_excel(file_path)
        df = df.fillna("") # 处理NaN值
        markdown_table = df.to_markdown(index=False)
        file_name = os.path.basename(file_path)
        file_name = os.path.splitext(file_name)[0]
        markdown_table = f"## {file_name}\n\n" + markdown_table
        return markdown_table
    except Exception as e:
        print(f"读取Excel {file_path} 时出错: {e}")
        return None


def load_all_data(config_path: Optional[str] = None, product_name: Optional[str] = None) -> Dict[str, Any]:
    """
    加载指定品种的所有数据
    包括: 配置、全息模型、产业模型、历史数据
    """
    # 加载配置
    config = load_config(config_path)
    if not config:
        return None
    
    # 确定要加载的品种
    if not product_name:
        product_name = config.get("current_product", "螺纹钢")
    
    product_config = config.get("products", {}).get(product_name)
    if not product_config:
        return {
            "error": f"未找到品种 {product_name} 的配置",
            "available_products": list(config.get("products", {}).keys())
        }
    
    # 加载各类数据
    result = {
        "product_name": product_name,
        "product_config": product_config,
        "model_txt_list": [],  # 改为列表，存储多个文档
        "industry_txt_list": [],  # 改为列表，存储多个文档
        "historical_list": []  # 改为列表，存储多个数据文件
    }
    
    # 读取全息模型文档列表
    model_txt_list = product_config.get("model_doc", [])
    # 兼容单个文件的配置
    if isinstance(model_txt_list, str):
        model_txt_list = [model_txt_list]
    
    for model_txt_path in model_txt_list:
        if model_txt_path and os.path.exists(model_txt_path):
            txt_data = read_txt(model_txt_path)
            if txt_data:
                result["model_txt_list"].append(txt_data)
                print(f"✅ 已加载全息模型文档: {model_txt_path}")
        else:
            print(f"⚠️ 全息模型文档不存在: {model_txt_path}")
    
    # 读取产业模型文档列表
    industry_txt_list = product_config.get("industry_doc", [])
    # 兼容单个文件的配置
    if isinstance(industry_txt_list, str):
        industry_txt_list = [industry_txt_list]
    
    for industry_txt_path in industry_txt_list:
        if industry_txt_path and os.path.exists(industry_txt_path):
            txt_data = read_txt(industry_txt_path)
            if txt_data:
                result["industry_txt_list"].append(txt_data)
                print(f"✅ 已加载产业模型文档: {industry_txt_path}")
        else:
            print(f"⚠️ 产业模型文档不存在: {industry_txt_path}")
    
    # 读取历史数据Excel列表
    data_file_list = product_config.get("data_file", [])
    # 兼容单个文件的配置
    if isinstance(data_file_list, str):
        data_file_list = [data_file_list]
    
    for data_file_path in data_file_list:
        if data_file_path and os.path.exists(data_file_path):
            excel_data = read_excel(data_file_path)
            if excel_data:
                result["historical_list"].append(excel_data)
                print(f"✅ 已加载历史数据文件: {data_file_path}")
        else:
            print(f"⚠️ 历史数据文件不存在: {data_file_path}")
    
    return result


if __name__ == "__main__":
    # 测试数据加载
    print("正在加载数据...")
    result = load_all_data("螺纹钢")
    print(result['model_txt_list'])
    print(result['industry_txt_list'])
    print(result['historical_list'])
    