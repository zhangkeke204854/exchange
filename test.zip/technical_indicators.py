"""
技术指标计算工具模块
基于talib和pandas_ta实现常用技术指标
注册为LangChain工具供Agent调用
"""
import numpy as np
import pandas as pd
from typing import List, Dict, Any
from pydantic import BaseModel, Field
from langchain_core.tools import tool

# 尝试导入talib，如果没有安装则使用pandas_ta
try:
    import talib
    HAS_TALIB = True
except ImportError:
    HAS_TALIB = False
    print("警告: talib未安装，将使用pandas作为替代")


# ============ 工具参数模型 ============

class MAInput(BaseModel):
    """移动平均线参数"""
    close_prices: List[float] = Field(description="收盘价序列")
    period: int = Field(default=20, description="周期，默认20")

class EMAInput(BaseModel):
    """指数移动平均线参数"""
    close_prices: List[float] = Field(description="收盘价序列")
    period: int = Field(default=20, description="周期，默认20")

class MACDInput(BaseModel):
    """MACD参数"""
    close_prices: List[float] = Field(description="收盘价序列")
    fast_period: int = Field(default=12, description="快线周期")
    slow_period: int = Field(default=26, description="慢线周期")
    signal_period: int = Field(default=9, description="信号线周期")

class RSIInput(BaseModel):
    """RSI参数"""
    close_prices: List[float] = Field(description="收盘价序列")
    period: int = Field(default=14, description="周期，默认14")

class BOLLInput(BaseModel):
    """布林带参数"""
    close_prices: List[float] = Field(description="收盘价序列")
    period: int = Field(default=20, description="周期，默认20")
    std_dev: float = Field(default=2.0, description="标准差倍数,默认2.0")

class KDJInput(BaseModel):
    """KDJ参数"""
    high_prices: List[float] = Field(description="最高价序列")
    low_prices: List[float] = Field(description="最低价序列")
    close_prices: List[float] = Field(description="收盘价序列")
    k_period: int = Field(default=9, description="K值周期")
    d_period: int = Field(default=3, description="D值周期")

class ATRInput(BaseModel):
    """ATR参数"""
    high_prices: List[float] = Field(description="最高价序列")
    low_prices: List[float] = Field(description="最低价序列")
    close_prices: List[float] = Field(description="收盘价序列")
    period: int = Field(default=14, description="周期,默认14")


# ============ 技术指标计算函数 ============

@tool(args_schema=MAInput)
def calculate_ma(close_prices: List[float], period: int = 20) -> Dict[str, Any]:
    """
    计算移动平均线(MA)
    返回MA值和当前价格与MA的关系
    """
    try:
        close_array = np.array(close_prices, dtype=float)
        
        if HAS_TALIB:
            ma = talib.SMA(close_array, timeperiod=period)
        else:
            ma = pd.Series(close_array).rolling(window=period).mean().values
        
        current_price = close_array[-1]
        current_ma = ma[-1]
        
        return {
            "indicator": "MA",
            "period": period,
            "current_ma": round(float(current_ma), 2) if not np.isnan(current_ma) else None,
            "current_price": round(float(current_price), 2),
            "position": "价格在MA之上" if current_price > current_ma else "价格在MA之下",
            "distance_pct": round(((current_price / current_ma - 1) * 100), 2) if not np.isnan(current_ma) else None,
            "ma_values": [round(float(x), 2) if not np.isnan(x) else None for x in ma[-5:]]
        }
    except Exception as e:
        return {"error": str(e)}


@tool(args_schema=EMAInput)
def calculate_ema(close_prices: List[float], period: int = 20) -> Dict[str, Any]:
    """
    计算指数移动平均线(EMA)
    对近期价格赋予更高权重
    """
    try:
        close_array = np.array(close_prices, dtype=float)
        
        if HAS_TALIB:
            ema = talib.EMA(close_array, timeperiod=period)
        else:
            ema = pd.Series(close_array).ewm(span=period, adjust=False).mean().values
        
        current_price = close_array[-1]
        current_ema = ema[-1]
        
        return {
            "indicator": "EMA",
            "period": period,
            "current_ema": round(float(current_ema), 2),
            "current_price": round(float(current_price), 2),
            "position": "价格在EMA之上" if current_price > current_ema else "价格在EMA之下",
            "distance_pct": round(((current_price / current_ema - 1) * 100), 2)
        }
    except Exception as e:
        return {"error": str(e)}


@tool(args_schema=MACDInput)
def calculate_macd(
    close_prices: List[float], 
    fast_period: int = 12, 
    slow_period: int = 26, 
    signal_period: int = 9
) -> Dict[str, Any]:
    """
    计算MACD指标
    返回MACD线、信号线、柱状图及交易信号
    """
    try:
        close_array = np.array(close_prices, dtype=float)

        if HAS_TALIB:
            macd, signal, hist = talib.MACD(
                close_array, 
                fastperiod=fast_period,
                slowperiod=slow_period,
                signalperiod=signal_period
            )
        else:
            # 使用pandas计算
            ema_fast = pd.Series(close_array).ewm(span=fast_period, adjust=False).mean()
            ema_slow = pd.Series(close_array).ewm(span=slow_period, adjust=False).mean()
            macd = ema_fast - ema_slow
            signal = macd.ewm(span=signal_period, adjust=False).mean()
            hist = macd - signal
            macd, signal, hist = macd.values, signal.values, hist.values
        
        current_macd = macd[-1]
        current_signal = signal[-1]
        current_hist = hist[-1]
        prev_hist = hist[-2] if len(hist) > 1 else 0
        
        # 判断信号
        if current_hist > 0 and prev_hist <= 0:
            trade_signal = "金叉-买入信号"
        elif current_hist < 0 and prev_hist >= 0:
            trade_signal = "死叉-卖出信号"
        elif current_hist > 0:
            trade_signal = "多头趋势"
        else:
            trade_signal = "空头趋势"
        
        return {
            "indicator": "MACD",
            "macd": round(float(current_macd), 4),
            "signal": round(float(current_signal), 4),
            "histogram": round(float(current_hist), 4),
            "trade_signal": trade_signal,
            "histogram_trend": "扩大" if abs(current_hist) > abs(prev_hist) else "收窄"
        }
    except Exception as e:
        return {"error": str(e)}


@tool(args_schema=RSIInput)
def calculate_rsi(close_prices: List[float], period: int = 14) -> Dict[str, Any]:
    """
    计算相对强弱指标(RSI)
    判断超买超卖状态
    """
    try:
        close_array = np.array(close_prices, dtype=float)
        
        if HAS_TALIB:
            rsi = talib.RSI(close_array, timeperiod=period)
        else:
            # 手动计算RSI
            delta = pd.Series(close_array).diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
            rs = gain / loss
            rsi = 100 - (100 / (1 + rs))
            rsi = rsi.values
        
        current_rsi = rsi[-1]
        
        # 判断状态
        if current_rsi > 70:
            status = "超买-考虑卖出"
        elif current_rsi < 30:
            status = "超卖-考虑买入"
        elif current_rsi > 50:
            status = "偏强"
        else:
            status = "偏弱"
        
        return {
            "indicator": "RSI",
            "period": period,
            "current_rsi": round(float(current_rsi), 2),
            "status": status,
            "overbought": current_rsi > 70,
            "oversold": current_rsi < 30
        }
    except Exception as e:
        return {"error": str(e)}


@tool(args_schema=BOLLInput)
def calculate_boll(close_prices: List[float], period: int = 20, std_dev: float = 2.0) -> Dict[str, Any]:
    """
    计算布林带(BOLL)
    判断价格相对位置和波动性
    """
    try:
        close_array = np.array(close_prices, dtype=float)
        
        if HAS_TALIB:
            upper, middle, lower = talib.BBANDS(
                close_array, 
                timeperiod=period,
                nbdevup=std_dev,
                nbdevdn=std_dev
            )
        else:
            middle = pd.Series(close_array).rolling(window=period).mean()
            std = pd.Series(close_array).rolling(window=period).std()
            upper = middle + (std * std_dev)
            lower = middle - (std * std_dev)
            upper, middle, lower = upper.values, middle.values, lower.values
        
        current_price = close_array[-1]
        current_upper = upper[-1]
        current_middle = middle[-1]
        current_lower = lower[-1]
        
        # 计算价格位置
        boll_width = current_upper - current_lower
        price_position = (current_price - current_lower) / boll_width * 100
        
        # 判断信号
        if current_price > current_upper:
            signal = "突破上轨-超买"
        elif current_price < current_lower:
            signal = "跌破下轨-超卖"
        elif price_position > 80:
            signal = "接近上轨-偏强"
        elif price_position < 20:
            signal = "接近下轨-偏弱"
        else:
            signal = "中轨附近-震荡"
        
        return {
            "indicator": "BOLL",
            "period": period,
            "upper": round(float(current_upper), 2),
            "middle": round(float(current_middle), 2),
            "lower": round(float(current_lower), 2),
            "current_price": round(float(current_price), 2),
            "price_position_pct": round(float(price_position), 2),
            "signal": signal,
            "bandwidth": round(float(boll_width), 2)
        }
    except Exception as e:
        return {"error": str(e)}


@tool(args_schema=ATRInput)
def calculate_atr(
    high_prices: List[float],
    low_prices: List[float],
    close_prices: List[float],
    period: int = 14
) -> Dict[str, Any]:
    """
    计算平均真实波幅(ATR)
    衡量市场波动性
    """
    try:
        high_array = np.array(high_prices, dtype=float)
        low_array = np.array(low_prices, dtype=float)
        close_array = np.array(close_prices, dtype=float)
        
        if HAS_TALIB:
            atr = talib.ATR(high_array, low_array, close_array, timeperiod=period)
        else:
            # 手动计算ATR
            high_low = high_array - low_array
            high_close = np.abs(high_array - np.roll(close_array, 1))
            low_close = np.abs(low_array - np.roll(close_array, 1))
            tr = np.maximum(high_low, np.maximum(high_close, low_close))
            atr = pd.Series(tr).rolling(window=period).mean().values
        
        current_atr = atr[-1]
        current_price = close_array[-1]
        atr_pct = (current_atr / current_price) * 100
        
        # 判断波动性
        if atr_pct > 3:
            volatility = "高波动"
        elif atr_pct > 1.5:
            volatility = "中等波动"
        else:
            volatility = "低波动"
        
        return {
            "indicator": "ATR",
            "period": period,
            "current_atr": round(float(current_atr), 2),
            "atr_percentage": round(float(atr_pct), 2),
            "volatility": volatility,
            "current_price": round(float(current_price), 2)
        }
    except Exception as e:
        return {"error": str(e)}


# 导出所有工具
ALL_INDICATOR_TOOLS = [
    calculate_ma,
    calculate_ema,
    calculate_macd,
    calculate_rsi,
    calculate_boll,
    calculate_atr
]


if __name__ == "__main__":
    # 测试技术指标
    print("测试技术指标计算...")
    
    # 生成测试数据
    np.random.seed(42)
    prices = 3500 + np.cumsum(np.random.randn(100) * 20)
    close_prices = prices.tolist()
    high_prices = (prices * 1.01).tolist()
    low_prices = (prices * 0.99).tolist()
    
    print("\n1. MA指标:")
    print(calculate_ma.invoke({"close_prices": close_prices, "period": 20}))
    
    print("\n2. MACD指标:")
    print(calculate_macd.invoke({"close_prices": close_prices}))
    
    print("\n3. RSI指标:")
    print(calculate_rsi.invoke({"close_prices": close_prices, "period": 14}))
    
    print("\n4. BOLL指标:")
    print(calculate_boll.invoke({"close_prices": close_prices, "period": 20}))
    
    print("\n5. ATR指标:")
    print(calculate_atr.invoke({
        "high_prices": high_prices,
        "low_prices": low_prices,
        "close_prices": close_prices,
        "period": 14
    }))
